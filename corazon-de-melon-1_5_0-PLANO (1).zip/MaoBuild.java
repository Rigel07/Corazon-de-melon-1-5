package com.corazondemelon.ai;

import com.corazondemelon.MelonConfig;
import com.corazondemelon.entity.MaoEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.ShapedRecipe;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.StemBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.Tags;
import net.minecraftforge.event.level.BlockEvent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;

/** Construir, cavar, plantar, ganadería, fundir y recetas (1.5.0). Usa los objetos del inventario infinito del Mao. */
public final class MaoBuild {
    private MaoBuild() {}

    private static void say(ServerPlayer p, String t) {
        MaoActions.say(p, t);
    }

    public static void run(ServerPlayer p, MaoEntity mao, String action, String param) {
        if (action == null) return;
        switch (action) {
            case "ANTORCHAS" -> torches(p, mao);
            case "REFUGIO", "TUNEL", "ESCALERA", "PUENTE" -> build(p, mao, action, param);
            case "PLANTAR" -> plant(p, mao);
            case "ABONAR" -> bonemeal(p, mao);
            case "CRIAR" -> breed(p, mao);
            case "ESQUILAR" -> shear(p, mao);
            case "ORDENAR" -> milk(p, mao);
            case "RECOGER" -> pickup(p, mao);
            case "FUNDIR" -> smelt(p, mao, param);
            case "RECETA" -> recipe(p, param);
            default -> { }
        }
    }

    // ------------------------------------------------------------------ permisos y utilidades

    /** Respeta la protección de spawn y los claims de otros mods. */
    static boolean canPlace(ServerLevel level, ServerPlayer p, BlockPos pos) {
        if (!level.mayInteract(p, pos)) return false;
        return !MinecraftForge.EVENT_BUS.post(new BlockEvent.BreakEvent(level, pos, level.getBlockState(pos), p));
    }

    private static boolean buildAllowed(ServerPlayer p) {
        if (!MelonConfig.ALLOW_BUILD.get()) {
            say(p, "Mis manitas tienen prohibido construir y cavar en este mundo.");
            return false;
        }
        return true;
    }

    private static Component name(ItemStack s) {
        return s.getHoverName();
    }

    private static boolean solidBelow(ServerLevel level, BlockPos pos) {
        BlockPos b = pos.below();
        return level.getBlockState(b).isFaceSturdy(level, b, Direction.UP);
    }

    // ------------------------------------------------------------------ antorchas

    static boolean placeTorchAt(ServerLevel level, ServerPlayer p, MaoEntity mao, BlockPos pos) {
        if (!level.getBlockState(pos).isAir() || !solidBelow(level, pos)) return false;
        BlockState ts = Blocks.TORCH.defaultBlockState();
        if (!ts.canSurvive(level, pos) || !canPlace(level, p, pos)) return false;
        ItemStack t = mao.inventory.takeOne(s -> s.is(Items.TORCH));
        if (t == null) return false;
        level.setBlock(pos, ts, 3);
        return true;
    }

    /** Pone antorchas en los sitios oscuros alrededor del centro. @return cuántas puso. */
    static int placeTorches(ServerLevel level, ServerPlayer p, MaoEntity mao, BlockPos center, int radius, int max) {
        List<BlockPos> cands = new ArrayList<>();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int dy = -2; dy <= 2; dy++) {
                    BlockPos pos = center.offset(dx, dy, dz);
                    if (!level.hasChunkAt(pos) || !level.getBlockState(pos).isAir() || !solidBelow(level, pos)) continue;
                    if (level.getMaxLocalRawBrightness(pos) >= 8) continue;
                    cands.add(pos);
                }
            }
        }
        cands.sort(Comparator.comparingDouble(c -> c.distSqr(center)));
        List<BlockPos> placed = new ArrayList<>();
        for (BlockPos c : cands) {
            if (placed.size() >= max) break;
            boolean near = false;
            for (BlockPos q : placed) if (q.distSqr(c) < 36.0D) near = true;
            if (near) continue;
            if (mao.inventory.count(s -> s.is(Items.TORCH)) <= 0) break;
            if (placeTorchAt(level, p, mao, c)) placed.add(c);
        }
        return placed.size();
    }

    private static void torches(ServerPlayer p, MaoEntity mao) {
        if (!buildAllowed(p)) return;
        if (mao.inventory.count(s -> s.is(Items.TORCH)) <= 0) {
            say(p, "No tengo antorchas. Dame carbón y palos y dime «craftea 8 antorchas», o pídeme que las saque de un cofre.");
            return;
        }
        ServerLevel level = p.serverLevel();
        int n = placeTorches(level, p, mao, p.blockPosition(), 10, 12);
        say(p, n > 0 ? "¡Luz! He puesto " + n + " antorcha(s) en los sitios oscuros." : "No veo sitios oscuros donde poner antorchas (o no puedo ponerlas aquí).");
    }

    // ------------------------------------------------------------------ construir

    private static boolean isBuildBlock(ItemStack s) {
        if (!(s.getItem() instanceof BlockItem bi)) return false;
        Block b = bi.getBlock();
        if (b == Blocks.TNT || b instanceof FallingBlock) return false;
        BlockState bs = b.defaultBlockState();
        if (bs.hasBlockEntity()) return false;
        return Block.isShapeFullBlock(bs.getCollisionShape(EmptyBlockGetter.INSTANCE, BlockPos.ZERO));
    }

    /** Qué bloque usar: el que pidas («de piedra») o el que más tenga. null si no hay ninguno. */
    private static Predicate<ItemStack> chooseBlock(MaoEntity mao, String material) {
        if (material != null && !material.isBlank()) {
            MaoItems.Query q = MaoItems.resolve(material);
            if (q != null) {
                final Set<Item> items = q.items();
                if (mao.inventory.count(s -> items.contains(s.getItem()) && isBuildBlock(s)) > 0) return s -> items.contains(s.getItem()) && isBuildBlock(s);
                return null;
            }
        }
        com.corazondemelon.entity.MaoInventory.Entry best = null;
        for (com.corazondemelon.entity.MaoInventory.Entry e : mao.inventory.entries()) {
            if (!isBuildBlock(e.proto)) continue;
            if (best == null || e.count > best.count) best = e;
        }
        if (best == null) return null;
        final Item item = best.proto.getItem();
        return s -> s.getItem() == item;
    }

    private static final class Placer {
        final ServerLevel level;
        final ServerPlayer p;
        final MaoEntity mao;
        final Predicate<ItemStack> test;
        int placed;
        boolean out;

        Placer(ServerLevel level, ServerPlayer p, MaoEntity mao, Predicate<ItemStack> test) {
            this.level = level;
            this.p = p;
            this.mao = mao;
            this.test = test;
        }

        void place(BlockPos pos) {
            if (out || placed >= 400) return;
            BlockState cur = level.getBlockState(pos);
            if (!(cur.isAir() || cur.canBeReplaced()) || level.getBlockEntity(pos) != null) return;
            if (!canPlace(level, p, pos)) return;
            ItemStack st = mao.inventory.takeOne(test);
            if (st == null) {
                out = true;
                return;
            }
            level.setBlock(pos, ((BlockItem) st.getItem()).getBlock().defaultBlockState(), 3);
            placed++;
        }
    }

    private static int number(String param, int def, int max) {
        String head = param == null ? "" : param.split("\\|", -1)[0];
        try {
            if (!head.isBlank()) return Math.max(1, Math.min(max, Integer.parseInt(head.trim())));
        } catch (NumberFormatException ignored) {
            return def;
        }
        return def;
    }

    private static String materialOf(String param) {
        if (param == null) return "";
        String[] a = param.split("\\|", -1);
        return a.length > 1 ? a[1] : "";
    }

    /** Cava un bloque guardando los objetos en el inventario del Mao. @return 1 cavado, 0 ya vacío, -1 no se puede, -2 hay líquido cerca. */
    private static int dig(ServerLevel level, ServerPlayer p, MaoEntity mao, BlockPos pos) {
        BlockState st = level.getBlockState(pos);
        if (st.isAir()) return 0;
        if (!st.getFluidState().isEmpty()) return -2;
        for (Direction d : Direction.values()) {
            if (!level.getFluidState(pos.relative(d)).isEmpty()) return -2;
        }
        if (!MaoActions.breakable(level, p, pos, st)) return -1;
        List<ItemStack> drops = Block.getDrops(st, level, pos, null, mao, ItemStack.EMPTY);
        level.destroyBlock(pos, false, mao);
        for (ItemStack d : drops) mao.inventory.add(d);
        return 1;
    }

    private static void build(ServerPlayer p, MaoEntity mao, String action, String param) {
        if (!buildAllowed(p)) return;
        boolean digs = action.equals("TUNEL") || action.equals("ESCALERA");
        if (digs && !MelonConfig.ALLOW_BREAK.get()) {
            say(p, "Mis manitas tienen prohibido romper cosas en este mundo.");
            return;
        }
        if (MaoSkills.onCooldown(p, "construir", 8)) return;
        ServerLevel level = p.serverLevel();
        BlockPos base = p.blockPosition();
        Direction f = p.getDirection();

        if (digs) {
            int n = number(param, action.equals("TUNEL") ? 12 : 10, action.equals("TUNEL") ? 48 : 24);
            int dug = 0;
            int stopped = 0;
            for (int i = 1; i <= n; i++) {
                BlockPos col = base.relative(f, i);
                int[] ys = action.equals("TUNEL") ? new int[]{0, 1} : new int[]{-i, -i + 1, -i + 2};
                BlockPos feet = action.equals("TUNEL") ? col : col.below(i);
                if (feet.getY() <= level.getMinBuildHeight() + 3) {
                    stopped = 3;
                    break;
                }
                for (int dy : ys) {
                    BlockPos pos = action.equals("TUNEL") ? col.above(dy) : base.relative(f, i).above(dy);
                    int r = dig(level, p, mao, pos);
                    if (r == 1) dug++;
                    if (r < 0) {
                        stopped = r == -2 ? 2 : 1;
                        break;
                    }
                }
                if (stopped != 0) break;
                if (i % 8 == 0 && mao.inventory.count(s -> s.is(Items.TORCH)) > 0) placeTorchAt(level, p, mao, feet);
            }
            level.playSound(null, p.blockPosition(), SoundEvents.STONE_BREAK, SoundSource.PLAYERS, 1.0F, 1.0F);
            String why = stopped == 2 ? " Me he parado: hay agua o lava cerca." : stopped == 1 ? " Me he parado: hay algo que no puedo romper (o está protegido)." : stopped == 3 ? " Me he parado: ¡es muy profundo!" : "";
            say(p, "¡Listo! He cavado " + dug + " bloque(s) hacia donde miras y los llevo en mi inventario." + why);
            return;
        }

        Predicate<ItemStack> test = chooseBlock(mao, materialOf(param));
        if (test == null) {
            say(p, "No tengo bloques para construir. Dame bloques (piedra, tablones...) o dime «coge piedra del cofre».");
            return;
        }
        Placer pl = new Placer(level, p, mao, test);
        if (action.equals("REFUGIO")) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    boolean edge = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                    pl.place(base.offset(dx, -1, dz));
                    boolean door = dx == 2 * f.getStepX() && dz == 2 * f.getStepZ();
                    for (int dy = 0; dy <= 2; dy++) {
                        if (edge && !(door && dy <= 1)) pl.place(base.offset(dx, dy, dz));
                    }
                    pl.place(base.offset(dx, 3, dz));
                }
            }
            placeTorchAt(level, p, mao, base.offset(1, 0, 1));
        } else {
            int n = number(param, 8, 32);
            for (int i = 1; i <= n; i++) pl.place(base.below().relative(f, i));
        }
        level.playSound(null, p.blockPosition(), SoundEvents.STONE_PLACE, SoundSource.PLAYERS, 1.0F, 1.0F);
        say(p, pl.placed == 0 ? "No he podido poner nada (¿faltan bloques o está protegido?)."
                : "¡Hecho! He puesto " + pl.placed + " bloque(s)." + (pl.out ? " Me he quedado sin bloques; dame más y repetimos." : ""));
    }

    // ------------------------------------------------------------------ plantar y abonar

    private static void plant(ServerPlayer p, MaoEntity mao) {
        if (!buildAllowed(p)) return;
        if (mao.inventory.count(s -> s.is(ItemTags.SAPLINGS)) <= 0) {
            say(p, "No tengo plantones de árbol. Dame brotes (o consigue hojas) y vuelve a pedírmelo.");
            return;
        }
        ServerLevel level = p.serverLevel();
        BlockPos o = p.blockPosition();
        List<BlockPos> cands = new ArrayList<>();
        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                for (int dy = -3; dy <= 3; dy++) {
                    BlockPos pos = o.offset(dx, dy, dz);
                    if (level.hasChunkAt(pos) && level.getBlockState(pos).isAir() && level.getBlockState(pos.below()).is(BlockTags.DIRT)) cands.add(pos);
                }
            }
        }
        cands.sort(Comparator.comparingDouble(c -> c.distSqr(o)));
        List<BlockPos> done = new ArrayList<>();
        for (BlockPos c : cands) {
            if (done.size() >= 16) break;
            boolean near = false;
            for (BlockPos q : done) if (q.distSqr(c) < 16.0D) near = true;
            if (near || c.distSqr(o) < 4.0D) continue;
            ItemStack st = mao.inventory.takeOne(s -> s.is(ItemTags.SAPLINGS));
            if (st == null) break;
            if (!(st.getItem() instanceof BlockItem bi)) {
                mao.inventory.add(st);
                break;
            }
            BlockState bs = bi.getBlock().defaultBlockState();
            if (!bs.canSurvive(level, c) || !canPlace(level, p, c)) {
                mao.inventory.add(st);
                continue;
            }
            level.setBlock(c, bs, 3);
            done.add(c);
        }
        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, p.getX(), p.getY() + 1.0, p.getZ(), 12, 1.5, 0.5, 1.5, 0.0);
        say(p, done.isEmpty() ? "No encuentro sitios buenos (tierra o hierba libre) para plantar por aquí."
                : "¡Plantados " + done.size() + " arbolito(s)! Con polvo de hueso crecen más rápido: «abona los cultivos».");
    }

    private static void bonemeal(ServerPlayer p, MaoEntity mao) {
        if (mao.inventory.count(s -> s.is(Items.BONE_MEAL)) <= 0) {
            say(p, "No tengo polvo de hueso. Dame polvo de hueso (o hueso para craftearlo).");
            return;
        }
        ServerLevel level = p.serverLevel();
        BlockPos o = p.blockPosition();
        int used = 0;
        outer:
        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                for (int dy = -3; dy <= 3; dy++) {
                    BlockPos pos = o.offset(dx, dy, dz);
                    for (int tries = 0; tries < 4; tries++) {
                        BlockState st = level.getBlockState(pos);
                        Block b = st.getBlock();
                        boolean target = b instanceof SaplingBlock || b instanceof StemBlock || (b instanceof CropBlock c && !c.isMaxAge(st));
                        if (!target || !level.mayInteract(p, pos)) break;
                        ItemStack bm = mao.inventory.takeOne(s -> s.is(Items.BONE_MEAL));
                        if (bm == null) break outer;
                        if (BoneMealItem.applyBonemeal(bm, level, pos)) {
                            used++;
                            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5, pos.getY() + 0.8, pos.getZ() + 0.5, 4, 0.3, 0.2, 0.3, 0.0);
                        } else {
                            mao.inventory.add(bm);
                            break;
                        }
                        if (used >= 60) break outer;
                    }
                }
            }
        }
        say(p, used > 0 ? "¡Abonado! He gastado " + used + " polvo(s) de hueso y todo crece más." : "No hay cultivos ni brotes que necesiten abono aquí cerca.");
    }

    // ------------------------------------------------------------------ ganadería

    private static void breed(ServerPlayer p, MaoEntity mao) {
        ServerLevel level = p.serverLevel();
        List<Animal> animals = level.getEntitiesOfClass(Animal.class, p.getBoundingBox().inflate(16.0D),
                a -> a.isAlive() && !(a instanceof TamableAnimal) && !(a instanceof AbstractHorse) && a.getAge() == 0 && a.canFallInLove());
        int n = 0;
        for (Animal a : animals) {
            if (n >= 16) break;
            ItemStack food = mao.inventory.takeOne(a::isFood);
            if (food == null) continue;
            a.setInLove(p);
            level.sendParticles(ParticleTypes.HEART, a.getX(), a.getY() + a.getBbHeight() + 0.2, a.getZ(), 4, 0.3, 0.2, 0.3, 0.0);
            n++;
        }
        say(p, n > 0 ? "¡Qué bonito! He dado de comer a " + n + " animal(es) y están enamorados."
                : animals.isEmpty() ? "No veo animales adultos cerca para criar."
                : "No tengo la comida que les gusta (trigo para vacas y ovejas, zanahorias para cerdos, semillas para gallinas...).");
    }

    private static void shear(ServerPlayer p, MaoEntity mao) {
        ServerLevel level = p.serverLevel();
        List<Sheep> sheep = level.getEntitiesOfClass(Sheep.class, p.getBoundingBox().inflate(16.0D), s -> s.isAlive() && s.readyForShearing());
        int n = 0;
        for (Sheep s : sheep) {
            if (n >= 20) break;
            s.shear(SoundSource.PLAYERS);
            n++;
        }
        long got = n > 0 ? collect(level, mao, p.getBoundingBox().inflate(20.0D), 0) : 0;
        say(p, n > 0 ? "¡Zas, zas! He esquilado " + n + " oveja(s) y guardo " + got + " objeto(s) en mi inventario."
                : "No hay ovejas con lana lista cerca.");
    }

    private static void milk(ServerPlayer p, MaoEntity mao) {
        ServerLevel level = p.serverLevel();
        List<Cow> cows = level.getEntitiesOfClass(Cow.class, p.getBoundingBox().inflate(16.0D), c -> c.isAlive() && !c.isBaby());
        int n = 0;
        for (Cow c : cows) {
            if (n >= 16) break;
            ItemStack bucket = mao.inventory.takeOne(s -> s.is(Items.BUCKET));
            if (bucket == null) break;
            mao.inventory.add(new ItemStack(Items.MILK_BUCKET));
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, c.getX(), c.getY() + 1.0, c.getZ(), 3, 0.3, 0.3, 0.3, 0.0);
            n++;
        }
        say(p, n > 0 ? "¡Muuu! He ordeñado " + n + " vaca(s) y tengo " + n + " cubo(s) de leche."
                : cows.isEmpty() ? "No veo vacas adultas cerca." : "No tengo cubos vacíos. Dame cubos y vuelve a pedírmelo.");
    }

    /** Recoge los objetos del suelo en el inventario del Mao. @return cuántos objetos. */
    static long collect(ServerLevel level, MaoEntity mao, net.minecraft.world.phys.AABB box, int minAge) {
        long total = 0;
        int count = 0;
        for (ItemEntity ie : level.getEntitiesOfClass(ItemEntity.class, box, e -> e.isAlive() && !e.getItem().isEmpty())) {
            if (ie.tickCount < minAge) continue;
            if (count++ >= 300) break;
            total += ie.getItem().getCount();
            mao.inventory.add(ie.getItem().copy());
            ie.discard();
        }
        return total;
    }

    private static void pickup(ServerPlayer p, MaoEntity mao) {
        ServerLevel level = p.serverLevel();
        long n = collect(level, mao, p.getBoundingBox().inflate(16.0D), 0);
        say(p, n > 0 ? "¡Recogido! Llevo " + n + " objeto(s) más en mi inventario. Pídemelos con «dame todo»." : "No veo objetos tirados por el suelo.");
    }

    // ------------------------------------------------------------------ fundir y cocinar

    private record Cand(ItemStack proto, long count, SmeltingRecipe recipe) {}

    private static void smelt(ServerPlayer p, MaoEntity mao, String param) {
        ServerLevel level = p.serverLevel();
        RegistryAccess ra = level.registryAccess();
        String q = param == null ? "" : param.trim();
        boolean everything = q.isEmpty() || q.equals("todo");
        MaoItems.Query query = everything ? null : MaoItems.resolve(q);
        if (!everything && query == null) {
            say(p, "No sé qué objeto es «" + q + "».");
            return;
        }
        List<Cand> cands = new ArrayList<>();
        Set<Item> inputs = new HashSet<>();
        for (com.corazondemelon.entity.MaoInventory.Entry e : new ArrayList<>(mao.inventory.entries())) {
            boolean wanted = everything
                    ? (e.proto.isEdible() || e.proto.is(Tags.Items.RAW_MATERIALS) || e.proto.is(Tags.Items.ORES))
                    : query.test(e.proto);
            if (!wanted) continue;
            Optional<SmeltingRecipe> r = level.getRecipeManager().getRecipeFor(RecipeType.SMELTING, new SimpleContainer(e.proto), level);
            if (r.isEmpty()) continue;
            if (everything && ItemStack.isSameItem(r.get().getResultItem(ra), e.proto)) continue;
            cands.add(new Cand(e.proto.copy(), e.count, r.get()));
            inputs.add(e.proto.getItem());
        }
        if (cands.isEmpty()) {
            say(p, everything ? "No llevo nada que se pueda cocinar o fundir." : "Eso no se puede fundir ni cocinar, o no lo llevo.");
            return;
        }
        int pool = 0;
        long done = 0;
        float xp = 0.0F;
        boolean noFuel = false;
        Map<String, ItemStack> madeStack = new LinkedHashMap<>();
        Map<String, Long> made = new LinkedHashMap<>();
        outer:
        for (Cand c : cands) {
            for (long i = 0; i < c.count() && done < 256; i++) {
                int cook = Math.max(1, c.recipe().getCookingTime());
                while (pool < cook) {
                    ItemStack fuel = mao.inventory.takeOne(s -> !inputs.contains(s.getItem()) && ForgeHooks.getBurnTime(s, RecipeType.SMELTING) > 0);
                    if (fuel == null) {
                        noFuel = true;
                        break outer;
                    }
                    pool += ForgeHooks.getBurnTime(fuel, RecipeType.SMELTING);
                    if (fuel.hasCraftingRemainingItem()) mao.inventory.add(fuel.getCraftingRemainingItem());
                }
                ItemStack in = mao.inventory.takeOne(s -> ItemStack.isSameItemSameTags(s, c.proto()));
                if (in == null) break;
                pool -= cook;
                ItemStack out = c.recipe().assemble(new SimpleContainer(c.proto()), ra);
                mao.inventory.add(out);
                xp += c.recipe().getExperience();
                done++;
                String key = out.getHoverName().getString();
                madeStack.putIfAbsent(key, out);
                made.merge(key, (long) out.getCount(), Long::sum);
            }
        }
        if (done == 0) {
            say(p, "No tengo combustible (carbón, madera, palos...) en mi inventario para encender el fuego.");
            return;
        }
        int xpi = (int) xp;
        if (level.random.nextFloat() < xp - xpi) xpi++;
        if (xpi > 0) p.giveExperiencePoints(xpi);
        level.playSound(null, p.blockPosition(), SoundEvents.FURNACE_FIRE_CRACKLE, SoundSource.PLAYERS, 1.0F, 1.0F);
        say(p, "¡Listo! He cocinado " + done + " objeto(s) y lo guardo en mi inventario" + (noFuel ? " (me he quedado sin combustible)" : "") + ":");
        int shown = 0;
        for (Map.Entry<String, Long> e : made.entrySet()) {
            if (shown++ >= 10) break;
            p.sendSystemMessage(Component.literal(" • ").append(name(madeStack.get(e.getKey()))).append(Component.literal(" ×" + e.getValue()))
                    .withStyle(net.minecraft.ChatFormatting.YELLOW));
        }
    }

    // ------------------------------------------------------------------ recetas

    private static MutableComponent ingredients(Ingredient[] ings) {
        Map<Item, Integer> counts = new LinkedHashMap<>();
        Map<Item, Boolean> multi = new LinkedHashMap<>();
        Map<Item, ItemStack> rep = new LinkedHashMap<>();
        for (Ingredient ing : ings) {
            ItemStack[] opts = ing.getItems();
            if (opts.length == 0) continue;
            Item key = opts[0].getItem();
            counts.merge(key, 1, Integer::sum);
            rep.putIfAbsent(key, opts[0]);
            if (opts.length > 1) multi.put(key, true);
        }
        MutableComponent line = Component.literal("Ingredientes: ");
        boolean firstItem = true;
        for (Map.Entry<Item, Integer> e : counts.entrySet()) {
            if (!firstItem) line.append(Component.literal(", "));
            firstItem = false;
            line.append(Component.literal(e.getValue() + "× ")).append(name(rep.get(e.getKey())));
            if (multi.containsKey(e.getKey())) line.append(Component.literal(" (o similar)"));
        }
        return line;
    }

    private static void recipe(ServerPlayer p, String param) {
        MaoItems.Query q = param == null ? null : MaoItems.resolve(param);
        if (q == null) {
            say(p, "No sé de qué objeto me hablas.");
            return;
        }
        ServerLevel level = p.serverLevel();
        RegistryAccess ra = level.registryAccess();
        List<CraftingRecipe> found = new ArrayList<>();
        Set<Item> seen = new HashSet<>();
        for (CraftingRecipe r : level.getRecipeManager().getAllRecipesFor(RecipeType.CRAFTING)) {
            ItemStack out = r.getResultItem(ra);
            if (out.isEmpty() || !q.items().contains(out.getItem())) continue;
            if (seen.add(out.getItem())) found.add(r);
            if (found.size() >= 3) break;
        }
        int shown = 0;
        for (CraftingRecipe r : found) {
            ItemStack out = r.getResultItem(ra);
            String where = "";
            if (r instanceof ShapedRecipe sr) where = sr.getWidth() > 2 || sr.getHeight() > 2 ? " — necesita la mesa de crafteo" : " — vale en tu inventario (2×2)";
            else where = " — sin forma, mezcla los ingredientes";
            p.sendSystemMessage(Component.literal("Para hacer ").append(name(out)).append(Component.literal(" ×" + out.getCount() + where)).withStyle(net.minecraft.ChatFormatting.GOLD));
            p.sendSystemMessage(ingredients(r.getIngredients().toArray(new Ingredient[0])).withStyle(net.minecraft.ChatFormatting.YELLOW));
            shown++;
        }
        for (SmeltingRecipe r : level.getRecipeManager().getAllRecipesFor(RecipeType.SMELTING)) {
            ItemStack out = r.getResultItem(ra);
            if (out.isEmpty() || !q.items().contains(out.getItem())) continue;
            p.sendSystemMessage(Component.literal("Se consigue en el horno: ").append(name(out)).append(Component.literal(" ← "))
                    .append(ingredients(r.getIngredients().toArray(new Ingredient[0]))).withStyle(net.minecraft.ChatFormatting.YELLOW));
            shown++;
            break;
        }
        if (shown == 0) say(p, "No conozco ninguna receta para eso (puede que se consiga de otra forma: cofres, aldeanos, picando...).");
    }
}
