package com.corazondemelon.ai;

import com.corazondemelon.MelonConfig;
import com.corazondemelon.entity.MaoEntity;
import com.corazondemelon.innocence.Innocence;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.ServerStatsCounter;
import net.minecraft.stats.Stats;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Habilidades nuevas de Mao (1.5.0): información, comida, efectos, escudo, mascotas, limpiar monstruos, rayos,
 * tiempo, viajes (cama, muerte, spawn), mapas, reparar, fiesta, diversión, notas y temporizadores.
 * Lo que toca el mundo (construir, plantar, ganadería, fundir...) está en {@link MaoBuild}; lo automático en {@link MaoPerks}.
 */
public final class MaoSkills {
    private static final int F = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final Map<String, Long> CD = new ConcurrentHashMap<>();

    private MaoSkills() {}

    // ------------------------------------------------------------------ utilidades

    static void say(ServerPlayer p, String t) {
        MaoActions.say(p, t);
    }

    static void say(ServerPlayer p, Component c) {
        MaoActions.say(p, c);
    }

    /** @return true si todavía está recargándose (y avisa). Si no, lo apunta y devuelve false. */
    static boolean onCooldown(ServerPlayer p, String key, int seconds) {
        long now = System.currentTimeMillis();
        String k = p.getUUID() + ":" + key;
        Long last = CD.get(k);
        if (last != null && now - last < seconds * 1000L) {
            long left = (seconds * 1000L - (now - last)) / 1000L + 1L;
            say(p, "Todavía me estoy recargando... ¡dame " + left + " segundos!");
            return true;
        }
        CD.put(k, now);
        return false;
    }

    /** @return true (y avisa) si tu Inocencia no llega al nivel pedido. */
    static boolean needLevel(ServerPlayer p, int min, String what) {
        if (!MelonConfig.LEVEL_POWERS.get()) return false;
        int lvl = Innocence.getLevel(p);
        if (lvl >= min) return false;
        say(p, "Todavía no puedo " + what + ": necesito que tu Inocencia sea de nivel " + min + " (ahora tienes " + lvl + ").");
        return true;
    }

    private static String dimLabel(Level lv) {
        String d = lv.dimension().location().toString();
        return switch (d) {
            case "minecraft:overworld" -> "Overworld";
            case "minecraft:the_nether" -> "Nether";
            case "minecraft:the_end" -> "End";
            default -> d;
        };
    }

    private static String facing(ServerPlayer p) {
        return switch (p.getDirection()) {
            case NORTH -> "norte";
            case SOUTH -> "sur";
            case EAST -> "este";
            default -> "oeste";
        };
    }

    private static void hearts(ServerLevel level, double x, double y, double z, int n) {
        level.sendParticles(ParticleTypes.HEART, x, y, z, n, 0.4, 0.3, 0.4, 0.0);
    }

    // ------------------------------------------------------------------ despachador

    public static void run(ServerPlayer p, MaoEntity mao, String action, String param, boolean announce) {
        if (action == null) return;
        switch (action) {
            case "INFO" -> info(p, param);
            case "ESTADISTICAS" -> stats(p);
            case "ALIMENTAR" -> feed(p, mao);
            case "BUFF" -> buff(p, param);
            case "PURIFICAR" -> purify(p);
            case "ESCUDO" -> shield(p);
            case "CURAR_MASCOTAS" -> healPets(p);
            case "REUNIR_MASCOTAS" -> gatherPets(p);
            case "LIMPIAR" -> smite(p, mao);
            case "RAYO" -> lightning(p, mao);
            case "FIESTA" -> party(p, mao);
            case "BAILAR" -> dance(p, mao);
            case "TIEMPO" -> weather(p, param);
            case "CAMA", "MUERTE", "SPAWN", "VOLVER" -> travel(p, mao, action);
            case "MAPA" -> map(p, param);
            case "REPARAR" -> repair(p);
            case "CHISTE", "DATO", "DADO", "MONEDA", "ELEGIR", "ANIMO" -> fun(p, action, param);
            case "PERK" -> MaoPerks.toggle(p, mao, param);
            case "PERKS" -> MaoPerks.list(p, mao);
            case "AYUDA2" -> helpMore(p);
            default -> MaoBuild.run(p, mao, action, param);
        }
    }

    static void helpMore(ServerPlayer p) {
        say(p, "¡Mira todo lo nuevo que sé hacer! (empieza por mi nombre si hay varios Maos)");
        String[] lines = {
                "INFORMACIÓN: «qué hora es» · «dónde estoy» · «en qué bioma estoy» · «va a llover» · «mis estadísticas» · «cómo se hace una pala de hierro»",
                "CUIDARTE: «aliméntame» · «dame velocidad / fuerza / visión nocturna / respirar / salto / suerte» · «protégeme» · «purifícame» · «bendíceme» · «repara mis cosas»",
                "MASCOTAS: «cura a mis mascotas» · «reúne a mis mascotas»",
                "LUCHA: «limpia la zona de monstruos» · «invoca un rayo» (nivel 9)",
                "MUNDO: «pon día» · «pon noche» · «para la lluvia» · «llévame a mi cama» · «llévame a donde morí» · «llévame al spawn» · «vuelve al sitio anterior» · «dame un mapa»",
                "CONSTRUIR (con bloques de mi inventario): «haz un refugio» · «cava un túnel de 20» · «cava una escalera de 15» · «haz un puente de 10» · «pon antorchas»",
                "CAMPO: «planta árboles» · «abona los cultivos» · «cría a los animales» · «esquila las ovejas» · «ordeña las vacas» · «recoge los objetos del suelo»",
                "COCINA: «funde el hierro» · «cocina la carne» · «cocina todo» (uso el combustible de mi inventario)",
                "AUTOMÁTICO: «activa recoger / comida / antorchas / alertas / salvavidas» · «qué habilidades tienes»",
                "RECORDAR: «avísame en 5 minutos para sacar el pan» · «apunta que tengo que ir a la mina» · «mis notas» · «borra las notas»",
                "DIVERSIÓN: «cuéntame un chiste» · «dime un dato curioso» · «tira un dado de 20» · «cara o cruz» · «elige entre A o B» · «haz una fiesta» · «baila» · «ánimo»"
        };
        for (String l : lines) p.sendSystemMessage(Component.literal(" • " + l).withStyle(ChatFormatting.YELLOW));
    }

    // ------------------------------------------------------------------ información

    private static void info(ServerPlayer p, String param) {
        ServerLevel level = p.serverLevel();
        BlockPos pos = p.blockPosition();
        String q = param == null ? "" : param.trim();
        boolean all = q.isEmpty() || q.equals("todo");
        if (all || q.equals("pos")) {
            say(p, "Estás en " + pos.getX() + ", " + pos.getY() + ", " + pos.getZ() + " (" + dimLabel(level) + "), mirando al " + facing(p) + ".");
        }
        if (all || q.equals("bioma")) {
            Optional<ResourceKey<net.minecraft.world.level.biome.Biome>> key = level.getBiome(pos).unwrapKey();
            MutableComponent c = Component.literal("El bioma de aquí es: ");
            if (key.isPresent()) {
                ResourceLocation id = key.get().location();
                c.append(Component.translatable("biome." + id.getNamespace() + "." + id.getPath()));
            } else {
                c.append(Component.literal("desconocido"));
            }
            say(p, c);
        }
        if (all || q.equals("hora") || q.equals("dia")) {
            long total = level.getDayTime();
            long t = total % 24000L;
            int hour = (int) ((t / 1000L + 6L) % 24L);
            int min = (int) ((t % 1000L) * 60L / 1000L);
            String when = t < 12000L ? "de día" : t < 13000L ? "atardeciendo" : t < 23000L ? "de noche" : "amaneciendo";
            say(p, String.format("Son las %02d:%02d (%s). Es el día %d del mundo.", hour, min, when, total / 24000L + 1L));
        }
        if (all || q.equals("clima")) {
            String w = level.isThundering() ? "hay tormenta" : level.isRaining() ? "está lloviendo" : "el cielo está despejado";
            say(p, "Ahora mismo " + w + ".");
        }
        if (all || q.equals("luz")) {
            int light = level.getMaxLocalRawBrightness(pos);
            say(p, "Aquí hay nivel de luz " + light + (light <= 7 ? ": está oscuro, ¡pueden salir monstruos! Pídeme «pon antorchas»." : ": se ve bien."));
        }
    }

    private static int stat(ServerStatsCounter st, String id) {
        return st.getValue(Stats.CUSTOM.get(new ResourceLocation("minecraft", id)));
    }

    private static void stats(ServerPlayer p) {
        ServerStatsCounter st = p.getStats();
        int play = stat(st, "play_time");
        int deaths = stat(st, "deaths");
        int kills = stat(st, "mob_kills");
        int walked = stat(st, "walk_one_cm");
        int bred = stat(st, "animals_bred");
        int traded = stat(st, "traded_with_villager");
        say(p, "Tus estadísticas:");
        String[] lines = {
                "Has jugado " + (play / 72000) + " h " + ((play % 72000) / 1200) + " min",
                "Has caminado " + String.format("%.1f", walked / 100000.0D) + " km",
                "Has derrotado a " + kills + " criaturas y has muerto " + deaths + " veces",
                "Has criado " + bred + " animales y comerciado " + traded + " veces con aldeanos",
                "Inocencia: nivel " + Innocence.getLevel(p) + " (" + Innocence.levelName(Innocence.getLevel(p)) + ")"
        };
        for (String l : lines) p.sendSystemMessage(Component.literal(" • " + l).withStyle(ChatFormatting.YELLOW));
    }

    // ------------------------------------------------------------------ comida, efectos y protección

    /** Saca del inventario de Mao la mejor comida «segura» (sin efectos raros), o null. */
    static ItemStack pickFood(MaoEntity mao) {
        com.corazondemelon.entity.MaoInventory.Entry best = null;
        int bestN = 0;
        for (com.corazondemelon.entity.MaoInventory.Entry e : mao.inventory.entries()) {
            FoodProperties fp = e.proto.getItem().getFoodProperties();
            if (fp == null || !fp.getEffects().isEmpty()) continue;
            if (fp.getNutrition() > bestN) {
                bestN = fp.getNutrition();
                best = e;
            }
        }
        if (best == null) return null;
        final ItemStack proto = best.proto;
        return mao.inventory.takeOne(s -> ItemStack.isSameItemSameTags(s, proto));
    }

    static void eatItem(ServerPlayer p, MaoEntity mao, ItemStack food) {
        FoodProperties fp = food.getItem().getFoodProperties();
        if (fp != null) p.getFoodData().eat(fp.getNutrition(), fp.getSaturationModifier());
        if (food.hasCraftingRemainingItem()) mao.inventory.add(food.getCraftingRemainingItem());
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.GENERIC_EAT, SoundSource.PLAYERS, 0.8F, 1.0F);
        p.serverLevel().sendParticles(ParticleTypes.HAPPY_VILLAGER, p.getX(), p.getY() + 1.5, p.getZ(), 4, 0.3, 0.2, 0.3, 0.0);
    }

    private static void feed(ServerPlayer p, MaoEntity mao) {
        if (p.getFoodData().getFoodLevel() >= 20) {
            say(p, "¡Estás llenito, no necesitas comer!");
            return;
        }
        ItemStack food = pickFood(mao);
        if (food != null) {
            eatItem(p, mao, food);
            say(p, Component.literal("¡Ñam! Te he dado ").append(food.getHoverName()).append(Component.literal(" de mi inventario.")));
            return;
        }
        if (onCooldown(p, "bocadito", 120)) return;
        p.getFoodData().eat(6, 0.6F);
        p.serverLevel().sendParticles(ParticleTypes.HAPPY_VILLAGER, p.getX(), p.getY() + 1.5, p.getZ(), 6, 0.3, 0.2, 0.3, 0.0);
        say(p, "No tengo comida en mi inventario, pero te he hecho un bocadito de melón mágico. ¡Ñam!");
    }

    private record Buff(String[] keys, MobEffect effect, int minLevel, String label, boolean scales) {}

    private static List<Buff> buffs() {
        return List.of(
                new Buff(new String[]{"fuego", "lava"}, MobEffects.FIRE_RESISTANCE, 5, "resistencia al fuego", false),
                new Buff(new String[]{"regeneracion"}, MobEffects.REGENERATION, 5, "regeneración", false),
                new Buff(new String[]{"resistencia"}, MobEffects.DAMAGE_RESISTANCE, 6, "resistencia", true),
                new Buff(new String[]{"velocidad", "rapido", "correr", "corre"}, MobEffects.MOVEMENT_SPEED, 3, "velocidad", true),
                new Buff(new String[]{"salto", "saltar", "salta"}, MobEffects.JUMP, 3, "salto", true),
                new Buff(new String[]{"vision", "noche", "visibilidad"}, MobEffects.NIGHT_VISION, 3, "visión nocturna", false),
                new Buff(new String[]{"prisa"}, MobEffects.DIG_SPEED, 4, "prisa al picar", true),
                new Buff(new String[]{"respirar", "branquias", "agua"}, MobEffects.WATER_BREATHING, 4, "respirar bajo el agua", false),
                new Buff(new String[]{"fuerza", "fuerzas", "poder"}, MobEffects.DAMAGE_BOOST, 5, "fuerza", true),
                new Buff(new String[]{"suerte"}, MobEffects.LUCK, 7, "suerte", false),
                new Buff(new String[]{"plumas", "caida"}, MobEffects.SLOW_FALLING, 4, "caída de pluma", false));
    }

    private static void applyBuff(ServerPlayer p, Buff b, int lvl) {
        int secs = Math.min(600, 150 + lvl * 30);
        int amp = b.scales() && lvl >= 8 ? 1 : 0;
        p.addEffect(new MobEffectInstance(b.effect(), secs * 20, amp));
    }

    private static void buff(ServerPlayer p, String param) {
        String q = param == null ? "" : MaoPlaces.norm(param);
        int lvl = Innocence.getLevel(p);
        boolean gate = MelonConfig.LEVEL_POWERS.get();
        if (q.isEmpty() || q.contains("todo") || q.contains("bendic")) {
            if (needLevel(p, 3, "bendecirte")) return;
            if (onCooldown(p, "bendicion", 90)) return;
            List<String> got = new ArrayList<>();
            for (Buff b : buffs()) {
                if (!List.of("velocidad", "visión nocturna", "regeneración", "fuerza").contains(b.label())) continue;
                if (gate && lvl < b.minLevel()) continue;
                applyBuff(p, b, lvl);
                got.add(b.label());
            }
            hearts(p.serverLevel(), p.getX(), p.getY() + 1.8, p.getZ(), 8);
            say(p, "¡Bendición de melón! Tienes: " + String.join(", ", got) + ".");
            return;
        }
        for (Buff b : buffs()) {
            for (String k : b.keys()) {
                if (!q.contains(k)) continue;
                if (gate && lvl < b.minLevel()) {
                    say(p, "Todavía no sé darte " + b.label() + ": necesito que tu Inocencia sea de nivel " + b.minLevel() + " (ahora tienes " + lvl + ").");
                    return;
                }
                if (onCooldown(p, "buff", 8)) return;
                applyBuff(p, b, lvl);
                p.serverLevel().sendParticles(ParticleTypes.HAPPY_VILLAGER, p.getX(), p.getY() + 1.2, p.getZ(), 8, 0.4, 0.5, 0.4, 0.0);
                say(p, "¡Hecho! Tienes " + b.label() + " durante " + (Math.min(600, 150 + lvl * 30) / 60) + " minutos y medio... más o menos.");
                return;
            }
        }
        say(p, "Puedo darte: velocidad, salto, visión nocturna, prisa, respirar bajo el agua, fuerza, resistencia, regeneración, resistencia al fuego, suerte o caída de pluma.");
    }

    private static void purify(ServerPlayer p) {
        if (needLevel(p, 4, "purificarte")) return;
        int n = 0;
        for (MobEffectInstance ei : new ArrayList<>(p.getActiveEffects())) {
            if (ei.getEffect().getCategory() == MobEffectCategory.HARMFUL) {
                p.removeEffect(ei.getEffect());
                n++;
            }
        }
        p.clearFire();
        hearts(p.serverLevel(), p.getX(), p.getY() + 1.8, p.getZ(), 6);
        say(p, n > 0 ? "¡Fuera lo malo! Te he quitado " + n + " efecto(s) negativo(s)." : "No tienes nada malo que quitar. ¡Estás limpito!");
    }

    private static void shield(ServerPlayer p) {
        if (needLevel(p, 3, "protegerte con un escudo")) return;
        if (onCooldown(p, "escudo", 90)) return;
        int lvl = Innocence.getLevel(p);
        p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 2400, Math.min(3, lvl / 3)));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 600, lvl >= 7 ? 1 : 0));
        p.serverLevel().sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 1.0, p.getZ(), 20, 0.5, 0.8, 0.5, 0.02);
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.2F);
        say(p, "¡Escudo de melón puesto! Tienes corazones dorados y resistencia un ratito.");
    }

    // ------------------------------------------------------------------ mascotas

    private static boolean ownedPet(LivingEntity e, ServerPlayer p) {
        if (e instanceof MaoEntity) return false;
        if (e instanceof TamableAnimal t) return t.isOwnedBy(p);
        if (e instanceof AbstractHorse h) return p.getUUID().equals(h.getOwnerUUID());
        return false;
    }

    private static void healPets(ServerPlayer p) {
        if (needLevel(p, 3, "curar a tus mascotas")) return;
        if (onCooldown(p, "curarmascotas", 20)) return;
        List<LivingEntity> pets = p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(32), e -> e.isAlive() && ownedPet(e, p));
        if (pets.isEmpty()) {
            say(p, "No veo ninguna mascota tuya a 32 bloques.");
            return;
        }
        ServerLevel level = p.serverLevel();
        for (LivingEntity e : pets) {
            e.heal(e.getMaxHealth());
            hearts(level, e.getX(), e.getY() + e.getBbHeight() + 0.3, e.getZ(), 5);
        }
        say(p, "¡Mimitos mágicos! He curado a " + pets.size() + " mascota(s).");
    }

    private static void gatherPets(ServerPlayer p) {
        if (!MelonConfig.ALLOW_TELEPORT.get()) {
            say(p, "Mi magia de teletransporte está desactivada en este mundo.");
            return;
        }
        if (onCooldown(p, "reunirmascotas", 15)) return;
        List<TamableAnimal> pets = p.level().getEntitiesOfClass(TamableAnimal.class, p.getBoundingBox().inflate(96),
                e -> e.isAlive() && !(e instanceof MaoEntity) && e.isOwnedBy(p) && !e.isOrderedToSit() && e.distanceToSqr(p) > 16.0D);
        if (pets.isEmpty()) {
            say(p, "No hay mascotas tuyas lejos (las que están sentadas se quedan donde están).");
            return;
        }
        int i = 0;
        for (TamableAnimal t : pets) {
            double ang = (Math.PI * 2.0D) * (i++) / pets.size();
            t.moveTo(p.getX() + Math.cos(ang) * 2.0D, p.getY(), p.getZ() + Math.sin(ang) * 2.0D, t.getYRot(), t.getXRot());
            t.getNavigation().stop();
            t.fallDistance = 0.0F;
            p.serverLevel().sendParticles(ParticleTypes.PORTAL, t.getX(), t.getY() + 0.5, t.getZ(), 10, 0.3, 0.4, 0.3, 0.1);
        }
        say(p, "¡Todos aquí! He traído a " + pets.size() + " mascota(s) a tu lado.");
    }

    // ------------------------------------------------------------------ lucha

    private static List<Monster> monstersAround(ServerPlayer p, MaoEntity mao, double radius) {
        List<Monster> list = new ArrayList<>(p.level().getEntitiesOfClass(Monster.class, p.getBoundingBox().inflate(radius),
                m -> m.isAlive() && !MaoMods.isFriend(mao, m)));
        list.sort(Comparator.comparingDouble(m -> m.distanceToSqr(p)));
        return list;
    }

    private static void smite(ServerPlayer p, MaoEntity mao) {
        if (needLevel(p, 3, "limpiar de monstruos la zona")) return;
        if (onCooldown(p, "limpiar", 15)) return;
        List<Monster> list = monstersAround(p, mao, 14.0D);
        if (list.isEmpty()) {
            say(p, "No veo ningún monstruo cerca. ¡Qué tranquilidad!");
            return;
        }
        ServerLevel level = p.serverLevel();
        float dmg = 6.0F + Innocence.getLevel(p) * 1.5F;
        int n = 0;
        for (Monster m : list) {
            if (n++ >= 10) break;
            m.hurt(level.damageSources().playerAttack(p), dmg);
            level.sendParticles(ParticleTypes.CRIT, m.getX(), m.getY() + m.getBbHeight() * 0.6D, m.getZ(), 12, 0.3, 0.4, 0.3, 0.2);
        }
        level.playSound(null, p.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0F, 1.2F);
        say(p, "¡Pum! He golpeado a " + Math.min(n, list.size()) + " monstruo(s) con una estrellita sagrada.");
    }

    private static void lightning(ServerPlayer p, MaoEntity mao) {
        if (needLevel(p, 9, "invocar un rayo")) return;
        if (onCooldown(p, "rayo", 20)) return;
        HitResult hit = p.pick(48.0D, 1.0F, false);
        if (!(hit instanceof BlockHitResult bhr) || hit.getType() != HitResult.Type.BLOCK) {
            say(p, "Mira hacia un sitio (un bloque) y dime «invoca un rayo».");
            return;
        }
        ServerLevel level = p.serverLevel();
        BlockPos pos = bhr.getBlockPos().above();
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(Vec3.atBottomCenterOf(pos));
            bolt.setVisualOnly(true);
            level.addFreshEntity(bolt);
        }
        List<Monster> targets = level.getEntitiesOfClass(Monster.class, new AABB(pos).inflate(4.0D), m -> m.isAlive() && !MaoMods.isFriend(mao, m));
        for (Monster m : targets) m.hurt(level.damageSources().playerAttack(p), 25.0F);
        say(p, targets.isEmpty() ? "¡Zas! Un rayo de mentira (no quema nada)." : "¡ZAS! El rayo ha golpeado a " + targets.size() + " monstruo(s).");
    }

    // ------------------------------------------------------------------ fiesta y baile

    private static ItemStack firework(int[] colors, int type) {
        ItemStack rocket = new ItemStack(Items.FIREWORK_ROCKET);
        CompoundTag fw = rocket.getOrCreateTagElement("Fireworks");
        fw.putByte("Flight", (byte) 1);
        ListTag ex = new ListTag();
        CompoundTag e = new CompoundTag();
        e.putByte("Type", (byte) type);
        e.putIntArray("Colors", colors);
        e.putIntArray("FadeColors", new int[]{0xFFFFFF});
        e.putByte("Trail", (byte) 1);
        e.putByte("Flicker", (byte) 1);
        ex.add(e);
        fw.put("Explosions", ex);
        return rocket;
    }

    private static void party(ServerPlayer p, MaoEntity mao) {
        if (onCooldown(p, "fiesta", 30)) return;
        ServerLevel level = p.serverLevel();
        int[][] palettes = {{0xFF69B4, 0xFFC0CB}, {0xFFD700, 0xFFF3A0}, {0x66CCFF, 0x99E0FF}, {0xB57EDC, 0xD8B4FE}, {0x77DD77, 0xC1F0C1}};
        for (int i = 0; i < 6; i++) {
            double ang = (Math.PI * 2.0D) * i / 6.0D;
            FireworkRocketEntity r = new FireworkRocketEntity(level, p.getX() + Math.cos(ang) * 3.0D, p.getY(), p.getZ() + Math.sin(ang) * 3.0D,
                    firework(palettes[i % palettes.length], i % 2 == 0 ? 1 : 4));
            level.addFreshEntity(r);
        }
        hearts(level, p.getX(), p.getY() + 2.0, p.getZ(), 12);
        level.sendParticles(ParticleTypes.NOTE, mao.getX(), mao.getY() + 1.4, mao.getZ(), 10, 0.5, 0.4, 0.5, 1.0);
        level.playSound(null, p.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1.0F, 1.0F);
        say(p, "¡FIESTA DE MELÓN! ¡Hurra!");
    }

    private static void dance(ServerPlayer p, MaoEntity mao) {
        if (onCooldown(p, "baile", 5)) return;
        ServerLevel level = p.serverLevel();
        for (int i = 0; i < 5; i++) {
            level.sendParticles(ParticleTypes.NOTE, mao.getX() + (i - 2) * 0.3D, mao.getY() + 1.3 + i * 0.1D, mao.getZ(), 2, 0.2, 0.2, 0.2, 1.0);
        }
        level.sendParticles(ParticleTypes.HEART, mao.getX(), mao.getY() + 1.2, mao.getZ(), 5, 0.4, 0.3, 0.4, 0.0);
        level.playSound(null, mao.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.NEUTRAL, 1.0F, 0.8F);
        level.playSound(null, mao.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.NEUTRAL, 1.0F, 1.2F);
        level.playSound(null, mao.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.NEUTRAL, 1.0F, 1.6F);
        mao.setYRot(mao.getYRot() + 180.0F);
        say(p, "¡La la la! ♪ ♪ ¡Mira cómo bailo!");
    }

    // ------------------------------------------------------------------ tiempo

    private static void weather(ServerPlayer p, String param) {
        if (!MelonConfig.ALLOW_WORLD_MAGIC.get()) {
            say(p, "Mi magia del tiempo está desactivada en este mundo.");
            return;
        }
        ServerLevel level = p.serverLevel();
        if (level.dimension() != Level.OVERWORLD) {
            say(p, "Aquí no hay día ni lluvia que cambiar. ¡Pídemelo en el Overworld!");
            return;
        }
        String q = param == null ? "" : param;
        boolean rainOn = q.equals("lluvia_on") || q.equals("tormenta_on");
        if (needLevel(p, rainOn ? 8 : 6, "cambiar el tiempo")) return;
        if (onCooldown(p, "tiempo", 60)) return;
        long t = level.getDayTime();
        long tod = t % 24000L;
        switch (q) {
            case "dia" -> {
                if (tod < 12000L) {
                    say(p, "¡Pero si ya es de día!");
                    return;
                }
                level.setDayTime(t - tod + 24000L);
                say(p, "¡Buenos días! Ya ha salido el sol.");
            }
            case "noche" -> {
                if (tod >= 13000L && tod < 23000L) {
                    say(p, "¡Pero si ya es de noche!");
                    return;
                }
                level.setDayTime(t - tod + 13000L);
                say(p, "¡Buenas noches! Han salido las estrellas.");
            }
            case "lluvia_off" -> {
                if (!level.isRaining() && !level.isThundering()) {
                    say(p, "¡Pero si no está lloviendo!");
                    return;
                }
                level.setWeatherParameters(6000, 0, false, false);
                say(p, "Hecho: he apartado las nubes.");
            }
            case "lluvia_on" -> {
                level.setWeatherParameters(0, 6000, true, false);
                say(p, "¡A jugar con la lluvia! Plic, plic.");
            }
            case "tormenta_on" -> {
                level.setWeatherParameters(0, 6000, true, true);
                say(p, "¡Tormenta! Quédate cerquita de mí.");
            }
            default -> say(p, "Puedo poner día, noche, parar la lluvia, hacer llover o una tormenta.");
        }
        level.playSound(null, p.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.0F);
    }

    // ------------------------------------------------------------------ viajes

    private static boolean isFree(ServerLevel level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        return s.getCollisionShape(level, pos).isEmpty() && s.getFluidState().isEmpty();
    }

    private static BlockPos safeSpot(ServerLevel level, BlockPos pos) {
        for (int dy = 0; dy <= 10; dy++) {
            BlockPos q = pos.above(dy);
            if (isFree(level, q) && isFree(level, q.above())) return q;
        }
        return pos.above();
    }

    static void teleportPlayer(ServerPlayer p, MaoEntity mao, ServerLevel dest, BlockPos target, String message) {
        BlockPos safe = safeSpot(dest, target);
        CompoundTag back = new CompoundTag();
        back.putString("dim", p.level().dimension().location().toString());
        back.putInt("x", p.getBlockX());
        back.putInt("y", p.getBlockY());
        back.putInt("z", p.getBlockZ());
        p.getPersistentData().put("cdm_back", back);

        ServerLevel from = p.serverLevel();
        from.sendParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1.0, p.getZ(), 30, 0.4, 0.8, 0.4, 0.2);
        from.playSound(null, p.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.0F);
        p.teleportTo(dest, safe.getX() + 0.5, safe.getY(), safe.getZ() + 0.5, p.getYRot(), p.getXRot());
        p.fallDistance = 0.0F;
        dest.sendParticles(ParticleTypes.PORTAL, safe.getX() + 0.5, safe.getY() + 1.0, safe.getZ() + 0.5, 30, 0.4, 0.8, 0.4, 0.2);
        dest.playSound(null, safe, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.0F);
        if (mao != null && mao.isAlive() && !mao.isOrderedToSit()) {
            mao.warpTo(dest, safe.getX() + 1.5, safe.getY() + 1.0, safe.getZ() + 0.5);
        }
        say(p, message);
    }

    private static void travel(ServerPlayer p, MaoEntity mao, String action) {
        if (!MelonConfig.ALLOW_TELEPORT.get()) {
            say(p, "Mi magia de teletransporte está desactivada en este mundo.");
            return;
        }
        if (onCooldown(p, "viaje", 5)) return;
        switch (action) {
            case "CAMA" -> {
                BlockPos bed = p.getRespawnPosition();
                if (bed == null) {
                    say(p, "No tienes ninguna cama (ni ancla de reaparición) guardada. ¡Duerme en una cama primero!");
                    return;
                }
                ServerLevel d = p.server.getLevel(p.getRespawnDimension());
                if (d == null) {
                    say(p, "No consigo encontrar esa dimensión...");
                    return;
                }
                teleportPlayer(p, mao, d, bed, "¡Allá vamos! Te llevo a tu cama. (Para volver: «vuelve al sitio anterior»).");
            }
            case "MUERTE" -> {
                Optional<GlobalPos> loc = p.getLastDeathLocation();
                if (loc.isEmpty()) {
                    say(p, "No recuerdo que hayas muerto todavía. ¡Genial!");
                    return;
                }
                ServerLevel d = p.server.getLevel(loc.get().dimension());
                if (d == null) {
                    say(p, "No consigo encontrar esa dimensión...");
                    return;
                }
                teleportPlayer(p, mao, d, loc.get().pos(), "¡Allá vamos! Te llevo a donde moriste por última vez. ¡Ve a por tus cosas!");
            }
            case "SPAWN" -> {
                ServerLevel ow = p.server.overworld();
                BlockPos top = ow.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, ow.getSharedSpawnPos());
                teleportPlayer(p, mao, ow, top, "¡Allá vamos! Te llevo al punto de inicio del mundo.");
            }
            default -> {
                CompoundTag back = p.getPersistentData().getCompound("cdm_back");
                if (!back.contains("dim")) {
                    say(p, "Todavía no te he teletransportado a ninguna parte, no sé a dónde volver.");
                    return;
                }
                ResourceLocation id = ResourceLocation.tryParse(back.getString("dim"));
                ServerLevel d = id == null ? null : p.server.getLevel(ResourceKey.create(Registries.DIMENSION, id));
                if (d == null) {
                    say(p, "No consigo encontrar esa dimensión...");
                    return;
                }
                teleportPlayer(p, mao, d, new BlockPos(back.getInt("x"), back.getInt("y"), back.getInt("z")), "¡Vuelta atrás! Te he llevado al sitio de antes.");
            }
        }
    }

    // ------------------------------------------------------------------ mapa y reparar

    private static void map(ServerPlayer p, String param) {
        if (onCooldown(p, "mapa", 60)) return;
        ServerLevel level = p.serverLevel();
        String q = param == null ? "" : param;
        byte scale = (byte) (q.contains("grande") ? 3 : q.contains("pequeno") ? 0 : 1);
        ItemStack map = MapItem.create(level, p.getBlockX(), p.getBlockZ(), scale, true, true);
        MapItem.renderBiomePreviewMap(level, map);
        MaoActions.giveOrDrop(p, map);
        say(p, "¡Toma un mapa de la zona! Lo he dibujado con mis ojitos.");
    }

    private static void repair(ServerPlayer p) {
        if (needLevel(p, 4, "reparar tus cosas")) return;
        if (onCooldown(p, "reparar", 300)) return;
        int lvl = Innocence.getLevel(p);
        double pct = Math.min(0.45D, 0.10D + 0.035D * lvl);
        List<ItemStack> all = new ArrayList<>();
        all.addAll(p.getInventory().items);
        all.addAll(p.getInventory().armor);
        all.addAll(p.getInventory().offhand);
        int n = 0;
        for (ItemStack s : all) {
            if (s.isEmpty() || !s.isDamageableItem() || !s.isDamaged()) continue;
            int heal = Math.max(1, (int) (s.getMaxDamage() * pct));
            s.setDamageValue(Math.max(0, s.getDamageValue() - heal));
            n++;
        }
        if (n == 0) {
            say(p, "No tienes nada estropeado. ¡Todo nuevecito!");
            CD.remove(p.getUUID() + ":reparar");
            return;
        }
        p.serverLevel().sendParticles(ParticleTypes.HAPPY_VILLAGER, p.getX(), p.getY() + 1.2, p.getZ(), 10, 0.5, 0.6, 0.5, 0.0);
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 0.6F, 1.4F);
        say(p, "¡Arreglado! He reparado un " + Math.round(pct * 100) + " % de " + n + " objeto(s). Puedo volver a hacerlo en 5 minutos.");
    }

    // ------------------------------------------------------------------ diversión

    private static final String[] JOKES = {
            "¿Qué le dice un creeper a otro? «Qué ssssuerte verte».",
            "¿Por qué el esqueleto no fue a la fiesta? Porque no tenía con quién... ¡ni cuerpo para bailar!",
            "¿Cuál es el animal más antiguo? La cebra, porque está en blanco y negro.",
            "¿Qué hace un enderman en la biblioteca? Mirar fijamente los libros... ¡y no se los puedes quitar!",
            "¿Qué le dijo una vaca a otra? «¡Muuuy buenas!»",
            "¿Por qué los zombis no tienen amigos? Porque siempre se quedan con la boca abierta.",
            "¿Qué hace una abeja en el gimnasio? ¡Zum-ba!",
            "¿Cómo se llama un diamante que cuenta chistes? ¡Un diamante en bruto con mucha gracia!",
            "¿Qué le dijo el pico al bloque de piedra? «Tranquilo, solo quiero picarte... un poquito».",
            "¿Por qué las gallinas no usan ordenador? Porque ya tienen el pico... ¡y no les caben las patas en el teclado!",
            "¿Qué es verde, cuadrado y muy tímido? Un creeper que no quiere explotar en público.",
            "¿Cómo se despiden los aldeanos? «Hmmm... hmmm».",
            "¿Qué le dice un bloque de tierra a otro? «Qué pasa, colega, ¡estás hecho un cubo!»"
    };

    private static final String[] FACTS = {
            "Los creepers nacieron de un error: el creador quería hacer un cerdo y se equivocó con las medidas del modelo.",
            "Los gatos asustan a los creepers y a los phantoms. ¡Un gatito en casa es mejor que una puerta de hierro!",
            "Los axolotls se hacen los muertos cuando están muy heridos, y se curan más deprisa.",
            "Puedes ir en cerdo si le pones una silla y lo guías con una caña con zanahoria.",
            "Los piglins no te atacan si llevas alguna pieza de armadura de oro.",
            "Un enderman no te puede mirar mal si llevas una calabaza tallada en la cabeza.",
            "Las abejas mueren después de picar. ¡Mejor no las enfades!",
            "Los lobos domesticados se sientan cuando les haces clic derecho, y te siguen cuando se lo vuelves a pedir.",
            "El Warden no tiene ojos: te encuentra por el sonido y las vibraciones. ¡Camina agachado!",
            "Una vaca champiñón se puede esquilar para obtener champiñones y se convierte en una vaca normal.",
            "Las tortugas siempre vuelven a la playa donde nacieron para poner sus huevos.",
            "Si duermes en una cama, tu punto de reaparición se queda allí. ¡Yo te puedo llevar con «llévame a mi cama»!",
            "Los zorros pueden llevar objetos en la boca, y a veces te traen un regalito."
    };

    private static final String[] CHEERS = {
            "Eres mucho más fuerte de lo que crees, y yo siempre estoy a tu lado. ¡Ánimo!",
            "Un paso pequeño también es un paso. ¡Vas genial!",
            "Hasta el mejor constructor empezó poniendo un solo bloque. Tú puedes.",
            "Hoy ya has hecho cosas bonitas, aunque no te des cuenta. ¡Estoy orgullosísimo!",
            "Si algo sale mal, lo reconstruimos juntos. ¡Sin prisa!",
            "Tienes un corazón enorme, y eso se nota hasta en el color de tus corazones.",
            "Respira hondo, bebe agua y estírate un poquito. ¡Luego seguimos con energía!"
    };

    private static String pick(String[] a) {
        return a[(int) (Math.random() * a.length)];
    }

    private static void fun(ServerPlayer p, String action, String param) {
        switch (action) {
            case "CHISTE" -> say(p, pick(JOKES));
            case "DATO" -> say(p, pick(FACTS));
            case "DADO" -> {
                int sides = 6;
                try {
                    if (param != null && !param.isBlank()) sides = Math.max(2, Math.min(1000, Integer.parseInt(param.trim())));
                } catch (NumberFormatException ignored) {
                    sides = 6;
                }
                say(p, "He tirado un dado de " + sides + " caras... ¡y ha salido el " + (1 + (int) (Math.random() * sides)) + "!");
            }
            case "MONEDA" -> say(p, "¡Al aire! Ha salido... " + (Math.random() < 0.5D ? "¡CARA!" : "¡CRUZ!"));
            case "ELEGIR" -> {
                String[] opts = (param == null ? "" : param).split("\\s+o\\s+");
                List<String> clean = new ArrayList<>();
                for (String o : opts) if (!o.isBlank()) clean.add(o.trim());
                if (clean.size() < 2) {
                    say(p, "Dime las opciones así: «elige entre pizza o hamburguesa».");
                } else {
                    say(p, "Mmm... ¡yo elijo «" + clean.get((int) (Math.random() * clean.size())) + "»!");
                }
            }
            default -> {
                say(p, pick(CHEERS));
                hearts(p.serverLevel(), p.getX(), p.getY() + 1.9, p.getZ(), 8);
                p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
            }
        }
    }

    // ------------------------------------------------------------------ notas y temporizadores (con el texto original)

    private static final Pattern TIMER = Pattern.compile("^(?:(?:oye|por\\s+favor)[,\\s]+)*(?:av[ií]same|recu[eé]rdame|despi[eé]rtame|ponme\\s+(?:un|una)\\s+(?:temporizador|recordatorio|aviso|alarma))\\s+"
            + "(?:dentro\\s+de\\s+|en\\s+)(\\d{1,4}|un|una)\\s*(segundos?|segs?|minutos?|mins?|horas?|h)\\b[\\s,]*(?:para\\s+|de\\s+|que\\s+)?(.*)$", F);
    private static final Pattern NOTE_ADD = Pattern.compile("^(?:(?:oye|por\\s+favor)[,\\s]+)*(?:ap[uú]ntame\\s+que|an[oó]tame\\s+que|apunta\\s+que|anota\\s+que|toma\\s+nota\\s+(?:de\\s+que|de|que)|"
            + "nota\\s*[:,]|recu[eé]rdame\\s+que|recuerda\\s+que)\\s+(.+)$", F);
    private static final Pattern NOTE_LIST = Pattern.compile("^(?:(?:oye|por\\s+favor)[,\\s]+)*(?:mis\\s+(?:notas|apuntes|recordatorios)|(?:lee|l[eé]eme|mu[eé]strame|ens[eé][nñ]ame|dime|ver|revisa)\\s+(?:mis\\s+|las\\s+|tus\\s+)?(?:notas|apuntes|recordatorios)|"
            + "qu[eé]\\s+(?:tengo|hay)\\s+(?:apuntado|anotado)|notas)\\s*[.!?]*$", F);
    private static final Pattern NOTE_DEL_ALL = Pattern.compile("^(?:(?:oye|por\\s+favor)[,\\s]+)*(?:borra|elimina|quita|olvida|vac[ií]a)\\s+(?:todas\\s+)?(?:las\\s+|mis\\s+|tus\\s+)?(?:notas|apuntes|recordatorios)\\s*[.!?]*$", F);
    private static final Pattern NOTE_DEL_ONE = Pattern.compile("^(?:(?:oye|por\\s+favor)[,\\s]+)*(?:borra|elimina|quita|olvida)\\s+(?:la\\s+)?nota\\s+(?:n[uú]mero\\s+)?(\\d{1,2})\\s*[.!?]*$", F);
    private static final Pattern TIMER_CANCEL = Pattern.compile("^(?:(?:oye|por\\s+favor)[,\\s]+)*(?:cancela|borra|quita|elimina)\\s+(?:todos\\s+)?(?:los\\s+|mis\\s+)?(?:temporizadores|avisos|alarmas)\\s*[.!?]*$", F);

    /** Notas y avisos: necesitan el texto original (mayúsculas y tildes). @return true si lo ha tratado. */
    public static boolean handleRaw(ServerPlayer p, MaoEntity mao, String message) {
        String text = message.trim();
        Matcher m = TIMER.matcher(text);
        if (m.matches()) {
            addTimer(p, mao, m.group(1), m.group(2), m.group(3).trim());
            return true;
        }
        m = NOTE_ADD.matcher(text);
        if (m.matches()) {
            addNote(p, m.group(1).trim());
            return true;
        }
        if (NOTE_LIST.matcher(text).matches()) {
            listNotes(p);
            return true;
        }
        if (NOTE_DEL_ALL.matcher(text).matches()) {
            p.getPersistentData().put("cdm_notes", new ListTag());
            say(p, "Vale, he borrado todas tus notas.");
            return true;
        }
        m = NOTE_DEL_ONE.matcher(text);
        if (m.matches()) {
            ListTag l = p.getPersistentData().getList("cdm_notes", Tag.TAG_STRING);
            int i = Integer.parseInt(m.group(1));
            if (i < 1 || i > l.size()) {
                say(p, "No tengo la nota número " + i + ". Dime «mis notas» para verlas.");
            } else {
                l.remove(i - 1);
                p.getPersistentData().put("cdm_notes", l);
                say(p, "Borrada la nota " + i + ".");
            }
            return true;
        }
        if (TIMER_CANCEL.matcher(text).matches()) {
            int n = 0;
            for (MaoEntity o : MaoRoster.owned(p, false)) {
                n += o.getPersistentData().getList("cdm_timers", Tag.TAG_COMPOUND).size();
                o.getPersistentData().put("cdm_timers", new ListTag());
            }
            say(p, n == 0 ? "No tenía ningún aviso puesto." : "Cancelados " + n + " aviso(s).");
            return true;
        }
        return false;
    }

    private static void addNote(ServerPlayer p, String note) {
        ListTag l = p.getPersistentData().getList("cdm_notes", Tag.TAG_STRING);
        if (l.size() >= 30) {
            say(p, "¡Mi libreta está llena (30 notas)! Borra alguna con «borra la nota 1».");
            return;
        }
        String n = note.length() > 140 ? note.substring(0, 140) : note;
        l.add(StringTag.valueOf(n));
        p.getPersistentData().put("cdm_notes", l);
        say(p, "¡Apuntado! (nota " + l.size() + ")");
    }

    private static void listNotes(ServerPlayer p) {
        ListTag l = p.getPersistentData().getList("cdm_notes", Tag.TAG_STRING);
        if (l.isEmpty()) {
            say(p, "No tienes ninguna nota. Prueba: «apunta que tengo que ir a la mina».");
            return;
        }
        say(p, "Tus notas:");
        for (int i = 0; i < l.size(); i++) {
            p.sendSystemMessage(Component.literal(" " + (i + 1) + ". " + l.getString(i)).withStyle(ChatFormatting.YELLOW));
        }
    }

    private static void addTimer(ServerPlayer p, MaoEntity mao, String amount, String unit, String what) {
        long n = amount.equalsIgnoreCase("un") || amount.equalsIgnoreCase("una") ? 1L : Long.parseLong(amount);
        String u = unit.toLowerCase();
        long secs = u.startsWith("seg") ? n : u.startsWith("min") ? n * 60L : n * 3600L;
        if (secs < 1L || secs > 86400L) {
            say(p, "Solo puedo avisarte entre 1 segundo y 24 horas.");
            return;
        }
        ListTag l = mao.getPersistentData().getList("cdm_timers", Tag.TAG_COMPOUND);
        if (l.size() >= 8) {
            say(p, "Ya tengo 8 avisos puestos. Espera a que suene alguno o dime «cancela los avisos».");
            return;
        }
        CompoundTag t = new CompoundTag();
        t.putLong("t", mao.level().getGameTime() + secs * 20L);
        t.putString("m", what.isEmpty() ? "¡Ha pasado el tiempo!" : what);
        l.add(t);
        mao.getPersistentData().put("cdm_timers", l);
        String span = secs >= 3600L ? (secs / 3600L) + " h " + ((secs % 3600L) / 60L) + " min" : secs >= 60L ? (secs / 60L) + " min " + (secs % 60L) + " s" : secs + " s";
        say(p, "¡Vale! Te aviso dentro de " + span + (what.isEmpty() ? "." : " (" + what + ")."));
    }

    /** Se llama cada segundo desde cada Mao: hace sonar los avisos que toquen. */
    public static void tickTimers(MaoEntity mao, ServerPlayer owner, long now) {
        ListTag l = mao.getPersistentData().getList("cdm_timers", Tag.TAG_COMPOUND);
        if (l.isEmpty()) return;
        ListTag keep = new ListTag();
        boolean fired = false;
        for (int i = 0; i < l.size(); i++) {
            CompoundTag t = l.getCompound(i);
            if (now >= t.getLong("t")) {
                MaoActions.setSpeaker(mao);
                say(owner, "¡Aviso! " + t.getString("m"));
                owner.serverLevel().playSound(null, owner.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.5F);
                fired = true;
            } else {
                keep.add(t);
            }
        }
        if (fired) mao.getPersistentData().put("cdm_timers", keep);
    }
}
