package com.corazondemelon.ai;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Entiende en español las órdenes de las habilidades nuevas (1.5.0): información, comida, efectos, mascotas, tiempo,
 * viajes, construir, plantar, ganadería, fundir, recetas, diversión, habilidades automáticas...
 * Es Java puro (no usa nada de Minecraft) y recibe el texto ya normalizado: minúsculas, sin tildes ni signos.
 */
public final class MaoSkillParse {
    public record Result(String action, String param) {}

    private MaoSkillParse() {}

    private static Pattern p(String re) {
        return Pattern.compile(re);
    }

    private static final Pattern START = p("^(?:hora|dia|clima|tiempo|coordenadas|posicion|bioma|estadisticas|aliment\\w*|bendic\\w*|bendice\\w*|purific\\w*|limpi\\w*|ilumin\\w*|"
            + "activ\\w*|desactiv\\w*|apaga|enciende|conecta|chiste|dato|cuenta\\w*|tira|lanza|echa|elige|escoge|decide|cara|invoca\\w*|reune\\w*|junta|repara\\w*|arregla\\w*|"
            + "restaura\\w*|funde\\w*|fundir|cocin\\w*|hornea\\w*|asa|asar|planta\\w*|abona\\w*|fertiliz\\w*|cria\\w*|esquila\\w*|trasquila\\w*|ordena\\w*|recoge\\w*|recolecta\\w*|aspira\\w*|"
            + "baila\\w*|canta\\w*|fiesta|celebra\\w*|fuegos|cohetes|mapa|receta|como|cuanto|avisame|apunta\\w*|anota\\w*|notas|mis|animame|animo|ponme|dale|escudo|rayo|"
            + "amanezca|anochezca|llueva|llover|pon|haz|hazme|crea|creame|construye\\w*|monta|levanta|cava|excava|abre|perfora|baja|protegeme|cubreme|defiendeme|"
            + "ataca|mata|extermina|acaba|derrota|castiga|vuelve|regresa|volvamos|devuelveme|deshaz|llevame|teletransportame|dime|dame|dadme|concedeme|regalame|"
            + "ayuda|comandos|que|donde|en|va|esta|deja|quita|trasquila|cura\\w*|sana\\w*|revive\\w*|salta|spawn|cama|casita|refugio|tunel|escalera|puente|"
            + "necesito|despiertame|recuerdame|ponte|mira|usa|echale|sube)\\b");

    /** @return true si el texto podría ser una de las órdenes nuevas (para que funcionen al instante aunque la IA esté activada). */
    public static boolean looksLike(String core) {
        return START.matcher(core).find();
    }

    private static boolean has(List<String> tokens, String... words) {
        for (String w : words) if (tokens.contains(w)) return true;
        return false;
    }

    private static boolean find(String core, String re) {
        return Pattern.compile(re).matcher(core).find();
    }

    private static String firstNumber(String s) {
        Matcher m = Pattern.compile("\\b(\\d{1,3})\\b").matcher(s);
        return m.find() ? m.group(1) : "";
    }

    private static final Set<String> NOISE = Set.of("el", "la", "los", "las", "un", "una", "unos", "unas", "de", "del", "mi", "mis", "tu", "tus",
            "por", "favor", "porfa", "me", "te", "al", "a", "en", "con", "para", "que", "lo", "y");

    private static String clean(String raw) {
        StringBuilder sb = new StringBuilder();
        for (String w : raw.trim().split("\\s+")) {
            if (w.isEmpty() || NOISE.contains(w)) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(w);
        }
        return sb.toString();
    }

    private static final Pattern BUFF_KEY = p("\\b(?:velocidad|rapido|correr|corre|salto|saltar|salta|vision\\s+nocturna|ver\\s+(?:de\\s+)?noche|visibilidad|prisa|"
            + "respirar|branquias|fuerza|fuerzas|resistencia|suerte|regeneracion|plumas|caida|fuego|lava|poder)\\b");
    private static final Set<String> PET_WORDS = Set.of("mascota", "mascotas", "lobo", "lobos", "gato", "gatos", "perro", "perros", "loro", "loros", "animales");
    private static final Set<String> FARM_ANIMALS = Set.of("animales", "vacas", "ovejas", "cerdos", "gallinas", "conejos", "animal", "vaca", "oveja", "cerdo", "gallina");
    private static final Pattern MONSTERS = p("\\b(?:monstruos?|mobs?|bichos|enemigos?|hostiles|zombis?|zombies?|esqueletos?|creepers?|aranas?|brujas?)\\b");

    /**
     * @param core texto normalizado (sin muletillas iniciales)
     * @param isItem dice si un texto es el nombre de un objeto de Minecraft (para las recetas)
     */
    public static Result parse(String core, Predicate<String> isItem) {
        if (core == null || core.isEmpty()) return null;
        List<String> tokens = Arrays.asList(core.split(" "));
        String first = tokens.get(0);
        Matcher m;

        // ---- ayuda ampliada
        if (core.matches("^(?:ayuda|comandos|habilidades)\\s+(?:2|dos|mas|extra|nuevo|nuevos|nuevas|habilidades|poderes)\\b.*")
                || core.matches("^(?:que\\s+)?mas\\s+(?:sabes|puedes)\\b.*") || core.matches("^(?:que\\s+)?otras\\s+cosas\\s+(?:sabes|puedes).*")) {
            return new Result("AYUDA2", null);
        }

        // ---- habilidades automáticas: «activa recoger», «desactiva las alertas», «qué habilidades tienes»
        if (core.matches("^(?:mis\\s+)?(?:habilidades|automatismos|modos\\s+automaticos)(?:\\s+(?:activas|activadas))?$")
                || core.matches("^(?:que\\s+)?(?:habilidades|automatismos)\\s+(?:tienes|tengo|hay|activas|activadas).*")) {
            return new Result("PERKS", null);
        }
        m = Pattern.compile("^(activa\\w*|enciende|conecta|desactiva\\w*|apaga|quita|para)\\s+(?:el\\s+|la\\s+|los\\s+|las\\s+|modo\\s+)?(.+)$").matcher(core);
        if (m.find()) {
            String key = perkKey(m.group(2));
            if (key != null) {
                boolean on = m.group(1).startsWith("activ") || m.group(1).equals("enciende") || m.group(1).equals("conecta");
                return new Result("PERK", (on ? "on" : "off") + "|" + key);
            }
        }

        // ---- información
        if (core.matches("^hora\\b.*") || core.matches(".*\\bque\\s+hora\\b.*")) return new Result("INFO", "hora");
        if (core.matches("^dia\\s+es\\b.*") || core.matches(".*\\bque\\s+dia\\s+(?:es|estamos)\\b.*") || core.matches("^cuantos\\s+dias\\b.*")) return new Result("INFO", "dia");
        if (core.matches("^(?:va\\s+a\\s+llover|esta\\s+lloviendo|llueve|clima|tiempo\\s+(?:hace|va\\s+a\\s+hacer)|como\\s+esta\\s+el\\s+(?:tiempo|clima)).*")
                || core.matches(".*\\bque\\s+tiempo\\s+(?:hace|hara)\\b.*")) return new Result("INFO", "clima");
        if (find(core, "\\b(?:coordenadas|donde\\s+estoy|mi\\s+posicion)\\b")) return new Result("INFO", "pos");
        if (find(core, "\\bbioma\\b")) return new Result("INFO", "bioma");
        if (find(core, "\\b(?:nivel\\s+de\\s+luz|esta\\s+oscuro|hay\\s+luz)\\b")) return new Result("INFO", "luz");
        if (core.matches("^(?:mis\\s+)?estadisticas\\b.*") || find(core, "\\bcuanto\\s+(?:tiempo\\s+)?(?:llevo\\s+jugando|he\\s+jugado)\\b")
                || find(core, "\\bcuantas\\s+veces\\s+he\\s+muerto\\b")) return new Result("ESTADISTICAS", null);

        // ---- notas y avisos se tratan con el texto original (ver MaoSkills.handleRaw)

        // ---- ganadería (antes que «alimenta»)
        if (first.startsWith("cria") || first.startsWith("reproduc") || first.startsWith("aparea")
                || (find(core, "^(?:alimenta\\w*|da\\s+de\\s+comer|dales?\\s+de\\s+comer|dame\\s+de\\s+comer\\s+a)\\b") && tokens.stream().anyMatch(FARM_ANIMALS::contains))
                || find(core, "^haz\\s+que\\s+(?:los\\s+)?animales\\s+se\\s+(?:reproduzcan|crien)")) {
            return new Result("CRIAR", null);
        }
        if (first.startsWith("esquila") || first.startsWith("trasquila") || find(core, "^corta\\s+(?:la\\s+)?lana\\b")) return new Result("ESQUILAR", null);
        if (find(core, "^(?:ordena\\w*)\\s+(?:a\\s+)?(?:las\\s+|todas\\s+las\\s+)?vacas?\\b") || find(core, "^(?:saca|consigue)\\s+(?:la\\s+)?leche\\b")) return new Result("ORDENAR", null);

        // ---- mascotas
        if (tokens.stream().anyMatch(PET_WORDS::contains)) {
            if (first.startsWith("cura") || first.startsWith("sana") || first.startsWith("bendic") || first.startsWith("revive")) return new Result("CURAR_MASCOTAS", null);
            if (first.startsWith("reune") || first.equals("junta") || first.startsWith("trae") || first.startsWith("llama") || first.startsWith("teletransport")
                    || first.equals("tp") || first.equals("ven") || first.startsWith("acerca")) return new Result("REUNIR_MASCOTAS", null);
        }

        // ---- comer
        if (find(core, "^(?:aliment\\w*|dame\\s+(?:de\\s+)?comer|dame\\s+(?:algo\\s+de\\s+)?comida|tengo\\s+hambre|estoy\\s+hambrient\\w*|dame\\s+un\\s+bocadito)\\b")
                && !tokens.stream().anyMatch(FARM_ANIMALS::contains) && !has(tokens, "cofre", "cofres")) {
            return new Result("ALIMENTAR", null);
        }

        // ---- efectos y protección
        if (find(core, "^(?:protegeme|cubreme|defiendeme|escudo|ponme\\s+un\\s+escudo|dame\\s+un\\s+escudo|dame\\s+escudo)\\b")) return new Result("ESCUDO", null);
        if (find(core, "^(?:purific\\w*|desintoxic\\w*|limpiame|quitame\\s+(?:los\\s+)?(?:efectos|veneno)|curame\\s+(?:el\\s+)?veneno)\\b")) return new Result("PURIFICAR", null);
        if (find(core, "^(?:bendiceme|bendicion|bendice|bendecidme)\\b")) return new Result("BUFF", "todo");
        m = Pattern.compile("^(?:dame|ponme|dale|dadme|concedeme|regalame|echame)\\s+(.+)$").matcher(core);
        if (m.find() && BUFF_KEY.matcher(m.group(1)).find()) return new Result("BUFF", m.group(1).trim());

        // ---- limpiar monstruos y rayos
        if ((find(core, "^(?:limpia\\w*|ataca\\w*|mata\\w*|elimina\\w*|extermina\\w*|destruye\\w*|acaba\\s+con|derrota\\w*|castiga\\w*|barre)\\b") && MONSTERS.matcher(core).find())
                || find(core, "^(?:limpia|limpiad)\\s+(?:la\\s+)?(?:zona|area|alrededores)\\b")) {
            return new Result("LIMPIAR", null);
        }
        if (find(core, "^(?:invoca\\w*|lanza\\w*|tira\\w*|manda\\w*|usa)\\s+(?:un\\s+|el\\s+)?(?:rayo|trueno|relampago)\\b") || first.equals("rayo") || first.equals("castiga")) return new Result("RAYO", null);

        // ---- fiesta y baile
        if (find(core, "^(?:haz\\s+(?:una\\s+)?fiesta|fiesta|celebra\\w*|lanza\\s+fuegos|fuegos\\s+artificiales|haz\\s+fuegos|tira\\s+(?:unos\\s+)?cohetes|cohetes|haz\\s+fuegos\\s+artificiales)\\b")) return new Result("FIESTA", null);
        if (find(core, "^(?:baila\\w*|bailemos|canta\\w*|haz\\s+un\\s+baile|salta\\s+de\\s+alegria)\\b")) return new Result("BAILAR", null);

        // ---- tiempo (día, noche, lluvia)
        if (find(core, "^(?:pon|haz|cambia\\s+a|hazlo)\\s+(?:de\\s+|que\\s+sea\\s+de\\s+|que\\s+sea\\s+)?dia\\b") || find(core, "^amanezca\\b") || find(core, "^pon\\s+el\\s+sol\\b")
                || find(core, "^haz\\s+que\\s+(?:sea\\s+)?(?:de\\s+)?dia\\b")) return new Result("TIEMPO", "dia");
        if (find(core, "^(?:pon|haz|cambia\\s+a|hazlo)\\s+(?:de\\s+|que\\s+sea\\s+de\\s+|que\\s+sea\\s+)?noche\\b") || find(core, "^anochezca\\b")
                || find(core, "^haz\\s+que\\s+(?:sea\\s+)?(?:de\\s+)?noche\\b")) return new Result("TIEMPO", "noche");
        if (find(core, "^(?:para|quita|detiene|apaga|acaba\\s+con|deten)\\s+(?:la\\s+)?(?:lluvia|tormenta)\\b") || find(core, "^(?:pare|deje|deja)\\s+de\\s+llover\\b")
                || find(core, "^salga\\s+el\\s+sol\\b") || find(core, "^haz\\s+que\\s+(?:pare|deje)\\s+de\\s+llover\\b") || find(core, "^(?:despeja|despejalo)\\b")) {
            return new Result("TIEMPO", "lluvia_off");
        }
        if (find(core, "^(?:pon|invoca|haz)\\s+(?:una\\s+)?tormenta\\b")) return new Result("TIEMPO", "tormenta_on");
        if (find(core, "^(?:llueva|llover|haz\\s+llover|pon\\s+(?:la\\s+)?lluvia|invoca\\s+(?:la\\s+)?lluvia)\\b")) return new Result("TIEMPO", "lluvia_on");

        // ---- viajes
        if (find(core, "^(?:llevame|teletransportame|tp|vamos|volvamos|ir)\\s+(?:a\\s+|al\\s+|hasta\\s+)?(?:mi\\s+|la\\s+)?(?:cama|ancla\\s+de\\s+reaparicion)\\b")
                || core.equals("cama") || core.equals("mi cama")) return new Result("CAMA", null);
        if (find(core, "\\b(?:donde\\s+(?:mori|he\\s+muerto|me\\s+mataron)|sitio\\s+(?:de\\s+)?mi\\s+muerte|mi\\s+(?:ultima\\s+)?muerte|ultima\\s+muerte)\\b")
                && has(tokens, "llevame", "teletransportame", "tp", "vamos", "volvamos", "ir", "llevarme", "regresa", "vuelve")) return new Result("MUERTE", null);
        if (find(core, "^(?:llevame|teletransportame|tp|vamos|volvamos|ir)\\s+(?:a\\s+|al\\s+|hasta\\s+)?(?:el\\s+)?(?:spawn|punto\\s+de\\s+aparicion|inicio\\s+del\\s+mundo|sitio\\s+de\\s+inicio)\\b")) return new Result("SPAWN", null);
        if (find(core, "^(?:vuelve|llevame|volvamos|regresa|devuelveme)\\s+(?:al\\s+)?(?:sitio\\s+)?(?:anterior|de\\s+antes|de\\s+donde\\s+venia|atras)\\b")
                || find(core, "^deshaz\\s+(?:el\\s+)?teletransporte\\b") || find(core, "^devuelveme\\s+(?:atras|alli)\\b")) return new Result("VOLVER", null);

        // ---- mapa
        if ((first.equals("mapa") || has(tokens, "dame", "hazme", "crea", "creame", "necesito", "dadme")) && has(tokens, "mapa")) {
            return new Result("MAPA", core.contains("grande") ? "grande" : core.contains("pequeno") ? "pequeno" : null);
        }

        // ---- recetas: «cómo se hace una pala de hierro»
        m = Pattern.compile("^(?:como\\s+se\\s+(?:hace|haces|fabrica|craftea|elabora|construye)|como\\s+(?:hago|fabrico|crafteo|se\\s+hacen)|receta\\s+(?:de|del|para)|"
                + "cual\\s+es\\s+la\\s+receta\\s+(?:de|del)|ensename\\s+la\\s+receta\\s+(?:de|del)|que\\s+necesito\\s+para\\s+(?:hacer|fabricar|craftear))\\s+(.+)$").matcher(core);
        if (m.find() && isItem != null && isItem.test(m.group(1))) return new Result("RECETA", m.group(1).trim());
        m = Pattern.compile("^para\\s+(?:hacer|fabricar|craftear)\\s+(.+)$").matcher(core);     // «qué necesito para hacer una mesa» (sin el «qué necesito»)
        if (m.find() && isItem != null && isItem.test(m.group(1))) return new Result("RECETA", m.group(1).trim());

        // ---- fundir y cocinar
        m = Pattern.compile("^(?:funde\\w*|fundir|cocin\\w*|hornea\\w*|asa|asar)\\b\\s*(.*)$").matcher(core);
        if (m.find()) {
            String rest = m.group(1).split("\\s+con\\s+")[0];
            return new Result("FUNDIR", rest.matches(".*\\btodo\\b.*") ? "todo" : clean(rest));
        }

        // ---- luz
        if (find(core, "^(?:pon\\w*|coloca\\w*|planta|enciende)\\s+(?:unas\\s+|algunas\\s+|las\\s+)?(?:antorchas?|luces|luz)\\b") || find(core, "^ilumin\\w*\\b") || find(core, "^pon\\s+luz\\b")) {
            return new Result("ANTORCHAS", null);
        }

        // ---- construir y cavar
        m = Pattern.compile("^(?:haz|hazme|crea|creame|construye\\w*|monta|levanta)\\s+(?:un\\s+|una\\s+)?(?:refugio|casita|casa\\s+rapida|caseta|chocita|cabana|cobertizo)\\b(.*)$").matcher(core);
        if (m.find()) return new Result("REFUGIO", "|" + material(m.group(1)));
        m = Pattern.compile("^(?:cava|excava|haz|hazme|abre|perfora)\\s+(?:un\\s+)?tunel\\b(.*)$").matcher(core);
        if (m.find()) return new Result("TUNEL", firstNumber(m.group(1)) + "|" + material(m.group(1)));
        m = Pattern.compile("^(?:cava|excava|haz|hazme|abre|baja|construye)\\s+(?:cavando\\s+)?(?:una\\s+)?escalera\\b(.*)$").matcher(core);
        if (m.find()) return new Result("ESCALERA", firstNumber(m.group(1)) + "|");
        if (find(core, "^baja\\s+cavando\\b")) return new Result("ESCALERA", firstNumber(core) + "|");
        m = Pattern.compile("^(?:haz|hazme|construye\\w*|crea|creame|pon|monta)\\s+(?:un\\s+)?puente\\b(.*)$").matcher(core);
        if (m.find()) return new Result("PUENTE", firstNumber(m.group(1)) + "|" + material(m.group(1)));

        // ---- plantar y abonar
        if (find(core, "^(?:planta\\w*|siembr\\w*|sembr\\w*|repobl\\w*|reforest\\w*)\\b.*\\b(?:arbol\\w*|plantones?|brotes?|bosque)\\b")) return new Result("PLANTAR", null);
        if (find(core, "^(?:abona\\w*|fertiliz\\w*|echa\\s+(?:polvo\\s+de\\s+)?hueso\\w*|usa\\s+(?:el\\s+)?(?:polvo\\s+de\\s+hueso|abono)|haz\\s+crecer\\w*)\\b")) return new Result("ABONAR", null);

        // ---- objetos del suelo
        if (find(core, "^(?:recoge\\w*|recolecta\\w*|aspira\\w*|junta|agarra)\\s+(?:todo\\s+)?(?:los\\s+|las\\s+|lo\\s+)?(?:objetos|cosas|items|drops|botin|loot|suelo|todo|tirad\\w*)\\b")
                && !has(tokens, "cofre", "cofres", "barril", "baul", "ender", "cultivos", "cosecha")) {
            return new Result("RECOGER", null);
        }

        // ---- reparar
        if (find(core, "^(?:repara\\w*|arregla\\w*|restaura\\w*)\\s*(?:mis\\s+|las\\s+|los\\s+|me\\s+)?(?:cosas|herramientas|armadura|objetos|items|equipo|pico|espada|todo|hacha|pala)?\\b")
                && !core.contains("bloque")) return new Result("REPARAR", null);

        // ---- diversión
        if (find(core, "^(?:cuentame\\s+un\\s+chiste|dime\\s+un\\s+chiste|cuenta\\s+un\\s+chiste|chiste|un\\s+chiste)\\b")) return new Result("CHISTE", null);
        if (find(core, "^(?:dime|cuentame|dame)\\s+(?:un\\s+|una\\s+)?(?:dato|curiosidad|truco)\\b") || find(core, "^dato\\s+curioso\\b") || find(core, "^cuentame\\s+algo\\s+(?:curioso|interesante)\\b")) return new Result("DATO", null);
        if (find(core, "^(?:tira|lanza|echa)\\s+(?:un\\s+)?dado\\b")) return new Result("DADO", firstNumber(core));
        if (find(core, "^(?:tira|lanza|echa)\\s+(?:una\\s+)?moneda\\b") || find(core, "^cara\\s+o\\s+cruz\\b")) return new Result("MONEDA", null);
        m = Pattern.compile("^(?:elige|escoge|decide)\\s+(?:entre\\s+)?(.+\\s+o\\s+.+)$").matcher(core);
        if (m.find()) return new Result("ELEGIR", m.group(1).trim());
        if (find(core, "^(?:animame|animo|dame\\s+animos?|dime\\s+algo\\s+(?:bonito|lindo|bueno)|dime\\s+un\\s+piropo|hazme\\s+sonreir|piropo)\\b")) return new Result("ANIMO", null);

        return null;
    }

    private static String material(String rest) {
        Matcher m = Pattern.compile("\\bde\\s+(?!\\d)([a-z ]+)$").matcher(rest.trim());
        if (!m.find()) return "";
        String mat = clean(m.group(1));
        return mat.length() > 30 ? mat.substring(0, 30) : mat;
    }

    private static String perkKey(String raw) {
        String s = raw.trim();
        if (find(s, "\\b(?:recog\\w*|aspira\\w*|iman|recolec\\w*|botin)\\b")) return "recoger";
        if (find(s, "\\b(?:comida|aliment\\w*|hambre|comer)\\b")) return "comida";
        if (find(s, "\\b(?:antorchas?|luces|luz|ilumin\\w*)\\b")) return "antorchas";
        if (find(s, "\\b(?:alertas?|avisos?|vigil\\w*|centinela|peligros?)\\b")) return "alertas";
        if (find(s, "\\b(?:salvavidas|seguro|proteccion|airbag|paracaidas|salvavida)\\b")) return "salvavidas";
        return null;
    }
}
