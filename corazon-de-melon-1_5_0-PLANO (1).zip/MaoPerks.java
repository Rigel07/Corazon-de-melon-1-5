package com.corazondemelon.ai;

import com.corazondemelon.CorazonDeMelon;
import com.corazondemelon.MelonConfig;
import com.corazondemelon.entity.MaoEntity;
import com.corazondemelon.innocence.Innocence;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

/**
 * Habilidades que un Mao hace SOLO mientras está cerca de ti (a menos de 48 bloques): recoger objetos, darte de comer,
 * poner antorchas, avisarte de peligros y salvarte (caídas, fuego, ahogarte). Se activan con «activa recoger», etc.
 */
@Mod.EventBusSubscriber(modid = CorazonDeMelon.MOD_ID)
public final class MaoPerks {
    private static final String KEY = "cdm_perks";
    private static final String[][] PERKS = {
            {"recoger", "2", "recoge los objetos tirados (lejos de ti) y los guarda en mi inventario infinito"},
            {"comida", "3", "te doy de comer de mi inventario cuando tienes hambre"},
            {"antorchas", "3", "pongo antorchas (de mi inventario) donde estás si está oscuro"},
            {"alertas", "3", "te aviso de monstruos cercanos, creepers, la noche, poca vida, hambre y herramientas a punto de romperse"},
            {"salvavidas", "5", "te salvo de caídas, del fuego/lava y de ahogarte"}
    };

    private MaoPerks() {}

    static boolean has(MaoEntity mao, String perk) {
        return mao.getPersistentData().getCompound(KEY).getBoolean(perk);
    }

    private static void say(ServerPlayer p, MaoEntity mao, String t) {
        MaoActions.setSpeaker(mao);
        MaoActions.say(p, t);
    }

    static void toggle(ServerPlayer p, MaoEntity mao, String param) {
        if (!MelonConfig.ALLOW_PERKS.get()) {
            say(p, mao, "Mis habilidades automáticas están desactivadas en este mundo.");
            return;
        }
        String[] a = param == null ? new String[0] : param.split("\\|");
        if (a.length < 2) return;
        boolean on = a[0].equals("on");
        for (String[] perk : PERKS) {
            if (!perk[0].equals(a[1])) continue;
            int min = Integer.parseInt(perk[1]);
            if (on && MelonConfig.LEVEL_POWERS.get() && Innocence.getLevel(p) < min) {
                say(p, mao, "Todavía no sé hacer eso solito: necesito que tu Inocencia sea de nivel " + min + ".");
                return;
            }
            CompoundTag t = mao.getPersistentData().getCompound(KEY);
            t.putBoolean(perk[0], on);
            mao.getPersistentData().put(KEY, t);
            say(p, mao, on ? "¡Activado «" + perk[0] + "»! Ahora " + perk[2] + "." : "Vale, he apagado «" + perk[0] + "».");
            return;
        }
    }

    static void list(ServerPlayer p, MaoEntity mao) {
        say(p, mao, "Mis habilidades automáticas (se activan con «activa recoger», se apagan con «desactiva recoger»):");
        for (String[] perk : PERKS) {
            p.sendSystemMessage(Component.literal(" • " + (has(mao, perk[0]) ? "[SÍ] " : "[no] ") + perk[0] + " (nivel " + perk[1] + "): " + perk[2])
                    .withStyle(has(mao, perk[0]) ? ChatFormatting.GREEN : ChatFormatting.GRAY));
        }
    }

    private static boolean ready(MaoEntity m, String key, long now, long gap) {
        CompoundTag t = m.getPersistentData();
        long last = t.getLong("cdm_cd_" + key);
        if (last != 0L && now >= last && now - last < gap) return false;
        t.putLong("cdm_cd_" + key, now);
        return true;
    }

    private static boolean usable(MaoEntity mao, ServerPlayer owner, String perk) {
        return has(mao, perk) && (!MelonConfig.LEVEL_POWERS.get() || Innocence.getLevel(owner) >= Integer.parseInt(levelOf(perk)));
    }

    private static String levelOf(String perk) {
        for (String[] p : PERKS) if (p[0].equals(perk)) return p[1];
        return "1";
    }

    /** Se llama una vez por segundo desde cada Mao domesticado. */
    public static void tick(MaoEntity mao, ServerLevel level, long now) {
        if (!(mao.getOwner() instanceof ServerPlayer owner)) return;
        MaoSkills.tickTimers(mao, owner, now);
        if (!MelonConfig.ALLOW_PERKS.get() || !owner.isAlive() || owner.level() != level || mao.distanceToSqr(owner) > 2304.0D) return;
        CompoundTag cfg = mao.getPersistentData().getCompound(KEY);
        if (cfg.isEmpty()) return;

        if (usable(mao, owner, "recoger") && ready(mao, "recoger", now, 40L)) {
            AABB box = mao.getBoundingBox().inflate(8.0D);
            long n = 0L;
            for (net.minecraft.world.entity.item.ItemEntity ie : level.getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class, box,
                    e -> e.isAlive() && e.tickCount > 30 && e.distanceToSqr(owner) > 9.0D)) {
                if (n >= 200L) break;
                n += ie.getItem().getCount();
                mao.inventory.add(ie.getItem().copy());
                ie.discard();
            }
        }

        if (usable(mao, owner, "comida") && owner.getFoodData().getFoodLevel() <= 12 && ready(mao, "comida", now, 100L)) {
            ItemStack food = MaoSkills.pickFood(mao);
            if (food != null) {
                MaoSkills.eatItem(owner, mao, food);
                say(owner, mao, "¡Ñam! Tenías hambre, así que te he dado de comer.");
            }
        }

        if (usable(mao, owner, "antorchas") && level.getMaxLocalRawBrightness(owner.blockPosition()) < 7 && ready(mao, "antorchas", now, 160L)
                && MelonConfig.ALLOW_BUILD.get() && mao.inventory.count(s -> s.is(Items.TORCH)) > 0) {
            MaoBuild.placeTorches(level, owner, mao, owner.blockPosition(), 3, 1);
        }

        if (usable(mao, owner, "salvavidas")) {
            if ((owner.isOnFire() || owner.isInLava()) && !owner.hasEffect(MobEffects.FIRE_RESISTANCE) && ready(mao, "fuego", now, 400L)) {
                owner.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 1200, 0));
                owner.clearFire();
                say(owner, mao, "¡Fuego! Te he dado resistencia al fuego un minuto.");
            }
            if (owner.getAirSupply() < 80 && owner.isUnderWater() && !owner.hasEffect(MobEffects.WATER_BREATHING) && ready(mao, "aire", now, 400L)) {
                owner.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 1200, 0));
                say(owner, mao, "¡Te ahogabas! Te he dado aire para respirar bajo el agua un minuto.");
            }
        }

        if (usable(mao, owner, "alertas")) alerts(mao, level, owner, now);
    }

    private static void alerts(MaoEntity mao, ServerLevel level, ServerPlayer owner, long now) {
        if (ready(mao, "al_monstruos", now, 600L)) {
            List<Monster> ms = level.getEntitiesOfClass(Monster.class, owner.getBoundingBox().inflate(14.0D), m -> m.isAlive() && !MaoMods.isFriend(mao, m));
            if (!ms.isEmpty()) {
                Monster near = ms.get(0);
                for (Monster m : ms) if (m.distanceToSqr(owner) < near.distanceToSqr(owner)) near = m;
                String dir = MaoActions.direction((int) (near.getX() - owner.getX()), (int) (near.getZ() - owner.getZ()));
                int dist = (int) Math.round(Math.sqrt(near.distanceToSqr(owner)));
                MutableComponent c = Component.literal(near instanceof Creeper ? "¡Cuidado, un creeper a " + dist + " bloques al " + dir + "!"
                        : "¡Cuidado! Hay " + ms.size() + " monstruo(s) cerca; el más cercano está a " + dist + " bloques al " + dir + ".");
                MaoActions.setSpeaker(mao);
                MaoActions.say(owner, c);
                for (Monster m : ms) m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0, false, false));
            } else {
                CompoundTag t = mao.getPersistentData();
                t.putLong("cdm_cd_al_monstruos", now - 560L);     // sin monstruos: vuelve a mirar pronto
            }
        }
        long tod = level.getDayTime() % 24000L;
        if (level.dimension() == Level.OVERWORLD && tod >= 12800L && tod < 13300L && ready(mao, "al_noche", now, 1800L)) {
            say(owner, mao, "¡Está anocheciendo! Pronto saldrán monstruos: busca refugio o ilumina la zona.");
        }
        if (owner.getFoodData().getFoodLevel() <= 6 && ready(mao, "al_hambre", now, 2400L)) {
            say(owner, mao, "¡Tienes mucha hambre! Come algo, por favor.");
        }
        if (owner.getHealth() <= 6.0F && ready(mao, "al_vida", now, 600L)) {
            say(owner, mao, "¡Te queda muy poquita vida! Ten cuidado.");
        }
        ItemStack held = owner.getMainHandItem();
        if (!held.isEmpty() && held.isDamageableItem() && held.getMaxDamage() - held.getDamageValue() <= Math.max(5, held.getMaxDamage() / 12)
                && ready(mao, "al_herr", now, 600L)) {
            MaoActions.setSpeaker(mao);
            MaoActions.say(owner, Component.literal("¡Ojo! Tu ").append(held.getHoverName()).append(Component.literal(" está a punto de romperse. Pídeme «repara mis cosas».")));
        }
    }

    /** Con el salvavidas, los Maos cercanos amortiguan tus caídas. */
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer p) || !MelonConfig.ALLOW_PERKS.get() || event.getDistance() <= 3.0F) return;
        for (MaoEntity m : MaoRoster.owned(p, false)) {
            if (m.level() == p.level() && m.distanceToSqr(p) <= 2304.0D && usable(m, p, "salvavidas")) {
                event.setDamageMultiplier(0.0F);
                p.serverLevel().sendParticles(net.minecraft.core.particles.ParticleTypes.CLOUD, p.getX(), p.getY() + 0.2, p.getZ(), 10, 0.4, 0.1, 0.4, 0.05);
                say(p, m, "¡Hop! Te he agarrado para que no te hagas daño.");
                return;
            }
        }
    }
}
