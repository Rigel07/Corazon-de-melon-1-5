package com.corazondemelon.ai;

import com.corazondemelon.MelonConfig;
import com.corazondemelon.entity.MaoEntity;
import com.corazondemelon.event.MaoBlessings;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Lo nuevo de los Maos (1.4.0): nombres y colores, inventario infinito, cofres, crafteo,
 * proteger zonas y picar / explorar por su cuenta buscando material.
 */
public final class MaoWork {
    private static final int F = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final Pattern SELF = Pattern.compile("^(?:ll[aá]mate|te\\s+llamas|te\\s+llamar[aá]s|ponte\\s+(?:de\\s+)?nombre|c[aá]mbiate\\s+(?:el\\s+)?nombre\\s+(?:a|por)"
            + "|tu\\s+nombre\\s+(?:es|ser[aá])|te\\s+voy\\s+a\\s+llamar|ahora\\s+te\\s+llamas)\\s+(.+)$", F);
    private static final Pattern OTHER = Pattern.compile("^(?:renombra|bautiza|ll[aá]ma(?:le)?)\\s+(?:a\\s+)?(?:al\\s+|la\\s+)?(.+?)\\s+(?:como|por|de\\s+nombre)\\s+(.+)$", F);
    private static final Pattern OTHER2 = Pattern.compile("^c[aá]mbiale\\s+(?:el\\s+)?nombre\\s+(?:a|al)\\s+(.+?)\\s+(?:a|por)\\s+(.+)$", F);
    private static final Pattern PONLE = Pattern.compile("^(?:ponle|ponles)\\s+(?:de\\s+nombre\\s+|el\\s+nombre\\s+)?(?:color\\s+)?(.+?)\\s+(?:a|al)\\s+(.+)$", F);

    private MaoWork() {}

    private static void say(ServerPlayer p, String t) {
        MaoActions.say(p, t);
    }

    public static void run(ServerPlayer p, MaoEntity mao, String action, String param, boolean announce) {
        if (action == null) return;
        switch (action) {
            case "RENOMBRAR" -> rename(p, mao, param);
            case "COLOR" -> color(p, mao, param);
            case "GUARDIA" -> guard(p, mao, param);
            case "MINAR" -> startJob(p, mao, param, MaoEntity.Mode.MINE);
            case "EXPLORAR" -> startJob(p, mao, param, MaoEntity.Mode.EXPLORE);
            case "INVENTARIO" -> showInventory(p, mao, param);
            case "ENTREGAR" -> giveItems(p, mao, param);
            case "COFRES" -> chestLook(p, param);
            case "COGER_COFRE" -> chestTake(p, mao, param);
            case "METER_COFRE" -> chestPut(p, mao, param);
            case "CRAFTEAR" -> craft(p, mao, param, false);
            case "COGER_CRAFT" -> takeAndCraft(p, mao, param);
            case "ESTADO" -> status(p, mao);
            case "AYUDA" -> help(p);
            case "REPRESENTANTE" -> makeRep(p, mao);
            case "MAOS" -> listMaos(p);
            default -> MaoSkills.run(p, mao, action, param, announce);
        }
    }

    // ------------------------------------------------------------------ nombres y colores

    /** Cambios de nombre / color que necesitan el texto original (con mayúsculas). @return true si lo ha tratado. */
    public static boolean handleNaming(ServerPlayer p, MaoEntity mao, String message) {
        String text = message.trim().replaceAll("[.!¡?¿]+$", "").trim();
        Matcher m = SELF.matcher(text);
        if (m.find()) {
            rename(p, mao, m.group(1));
            return true;
        }
        for (Pattern pt : new Pattern[]{OTHER, OTHER2}) {
            m = pt.matcher(text);
            if (m.find()) {
                MaoEntity other = MaoRoster.byName(p, m.group(1));
                if (other == null) {
                    say(p, "No tengo ningún Mao llamado «" + m.group(1).trim() + "».");
                } else {
                    rename(p, other, m.group(2));
                }
                return true;
            }
        }
        m = PONLE.matcher(text);
        if (m.find()) {
            String first = m.group(1).trim();
            MaoEntity other = MaoRoster.byName(p, m.group(2));
            if (other == null) {
                // «ponle azul al Mao» sin nombre claro: si es un color y hay un solo candidato, no lo adivinamos
                if (colorKey(first) != null || !first.isEmpty()) say(p, "No tengo ningún Mao llamado «" + m.group(2).trim() + "».");
                return true;
            }
            if (colorKey(first) != null) color(p, other, first);
            else rename(p, other, first);
            return true;
        }
        return false;
    }

    static String colorKey(String raw) {
        String n = MaoPlaces.norm(raw);
        for (String w : n.split(" ")) {
            switch (w) {
                case "rosa", "rosado", "rosita" -> {
                    return "rosa";
                }
                case "verde" -> {
                    return "verde";
                }
                case "azul" -> {
                    return "azul";
                }
                case "violeta", "morado", "lila", "purpura" -> {
                    return "violeta";
                }
                case "original", "normal", "natural", "dorado", "amarillo", "rubio", "blanco" -> {
                    return "original";
                }
                default -> { }
            }
        }
        return null;
    }

    static void rename(ServerPlayer p, MaoEntity mao, String raw) {
        String n = raw == null ? "" : raw.trim().replaceAll("^[\"«“'¡]+|[\"»”'!]+$", "").trim();
        if (mao.isRepresentative()) {
            say(p, "Yo soy tu Mao representante y siempre me llamo Mao. Los otros Maos tienen nombres divertidos: cámbiaselos con «/Pipo llámate Luna».");
            return;
        }
        String nn = MaoPlaces.norm(n);
        if (nn.equals("mao") || nn.matches("mao \\d+")) {
            say(p, "Ese nombre es solo para el Mao representante. Elige otro, por ejemplo «llámate Luna».");
            return;
        }
        if (n.isEmpty() || n.length() > 24) {
            say(p, "Dime un nombre de hasta 24 letras, por ejemplo «llámate Luna».");
            return;
        }
        String key = MaoPlaces.norm(n);
        if (key.equals("mao") || key.equals("todos") || key.equals("maos")) {
            say(p, "Ese nombre está reservado, ¡elige otro!");
            return;
        }
        for (MaoEntity o : MaoRoster.owned(p)) {
            if (o != mao && MaoPlaces.norm(MaoRoster.nameOf(o)).equals(key)) {
                say(p, "Ya hay un Mao llamado «" + MaoRoster.nameOf(o) + "», elige otro nombre para no confundirnos.");
                return;
            }
        }
        mao.setCustomName(Component.literal(n));
        mao.setCustomNameVisible(true);
        MaoActions.setSpeaker(mao);
        sparkle(mao, ParticleTypes.HEART);
        say(p, "¡Me encanta! Desde ahora me llamo " + n + ".");
    }

    static void color(ServerPlayer p, MaoEntity mao, String param) {
        String key = colorKey(param == null ? "" : param);
        if (key == null) {
            say(p, "Puedo ser rosa, verde, azul, violeta o volver a mi color original. Dime por ejemplo «ponte rosa».");
            return;
        }
        int idx = 0;
        for (int i = 0; i < MaoEntity.COLOR_KEYS.length; i++) if (MaoEntity.COLOR_KEYS[i].equals(key)) idx = i;
        mao.setColor(idx);
        sparkle(mao, ParticleTypes.HAPPY_VILLAGER);
        say(p, idx == 0 ? "¡Vuelvo a mi color de siempre!" : "¡Ahora soy " + key + "! ¿Te gusta?");
    }

    private static void sparkle(MaoEntity mao, net.minecraft.core.particles.SimpleParticleType type) {
        if (mao.level() instanceof ServerLevel level) {
            level.sendParticles(type, mao.getX(), mao.getY() + 1.0, mao.getZ(), 8, 0.4, 0.4, 0.4, 0.02);
        }
    }

    // ------------------------------------------------------------------ estado, ayuda y lista

    static void status(ServerPlayer p, MaoEntity mao) {
        int lvl = Innocence_level(p);
        StringBuilder sb = new StringBuilder();
        sb.append(MaoRoster.nameOf(mao)).append(mao.isRepresentative() ? " (representante)" : "").append(" · color ")
                .append(MaoEntity.COLOR_KEYS[mao.getColor()]).append(" · ");
        sb.append(switch (mao.getMode()) {
            case FOLLOW -> mao.isOrderedToSit() ? "esperando quieto" : "contigo";
            case GUARD -> "protegiendo una zona";
            case MINE -> "picando «" + mao.getJobTarget() + "»";
            case EXPLORE -> "explorando buscando «" + mao.getJobTarget() + "»";
        });
        say(p, sb.toString());
        say(p, "Nivel de Inocencia " + lvl + ": daño " + (3 + (MelonConfig.LEVEL_POWERS.get() ? (int) MaoEntity.damageBonus(lvl) : 0))
                + (MelonConfig.LEVEL_POWERS.get() ? ". " + powers(lvl) : "."));
        say(p, "Llevo " + mao.inventory.total() + " objetos de " + mao.inventory.entries().size() + " tipos en mi inventario infinito.");
    }

    private static int Innocence_level(ServerPlayer p) {
        return com.corazondemelon.innocence.Innocence.getLevel(p);
    }

    static String powers(int lvl) {
        List<String> l = new ArrayList<>();
        if (lvl >= 5) l.add("frena a los enemigos al golpear");
        if (lvl >= 7) l.add("los debilita y los marca");
        if (lvl >= 9) l.add("daño sagrado contra no-muertos");
        if (lvl >= 10) l.add("te cura al golpear");
        int extra = MaoBlessings.extraHealth(lvl);
        if (extra > 0) l.add("+" + (extra / 2) + " corazones extra para ti");
        if (lvl >= 7) l.add("regeneración pasiva");
        if (lvl >= 9) l.add("inmunidad a todas las desventajas");
        else if (lvl >= 8) l.add("inmunidad a veneno, wither, hambre y náuseas");
        if (lvl >= 10) l.add("puede revivirte (cada " + MelonConfig.REVIVE_COOLDOWN_MIN.get() + " min)");
        return l.isEmpty() ? "Sube tu Inocencia para desbloquear poderes." : "Poderes: " + String.join(", ", l) + ".";
    }

    static void makeRep(ServerPlayer p, MaoEntity mao) {
        if (mao.isRepresentative()) {
            say(p, "¡Ya soy tu Mao representante!");
            return;
        }
        MaoRoster.setRepresentative(p, mao);
        MaoActions.setSpeaker(mao);
        say(p, "¡Ahora soy tu Mao representante! Me llamo Mao y te seguiré a todas partes. El anterior se llama ahora como su número (cámbiale el nombre cuando quieras).");
    }

    static void listMaos(ServerPlayer p) {
        List<MaoEntity> all = MaoRoster.owned(p);
        if (all.isEmpty()) {
            say(p, "Ahora mismo no encuentro ningún Mao tuyo cargado.");
            return;
        }
        say(p, "Tus Maos (a mí me llamas «Mao, ...»; a los demás con barra y su nombre, p. ej. «/Pipo ven». «Mao, ven aquí» llama a todos):");
        for (MaoEntity m : all) {
            String where = m.level() != p.level() ? "otra dimensión" : "a " + Math.round(Math.sqrt(m.distanceToSqr(p))) + " bloques";
            String doing = switch (m.getMode()) {
                case FOLLOW -> m.isOrderedToSit() ? "quieto" : "te sigue";
                case GUARD -> "protege una zona";
                case MINE -> "pica " + m.getJobTarget();
                case EXPLORE -> "explora por " + m.getJobTarget();
            };
            p.sendSystemMessage(Component.literal(" • " + (m.isRepresentative() ? "★ " : "") + MaoRoster.nameOf(m) + " — " + doing
                    + " (" + where + ", color " + MaoEntity.COLOR_KEYS[m.getColor()] + ")").withStyle(ChatFormatting.YELLOW));
        }
    }

    static void help(ServerPlayer p) {
        say(p, "Esto es lo nuevo que sé hacer (empieza por mi nombre: «Mao, ...», por el de otro Mao con barra: «/Pipo ...», o «Todos, ...»):");
        String[] lines = {
                "«llámate Luna» · «ponte rosa / verde / azul / violeta»",
                "«protege esta zona» · «vigila la casa radio 20» · «sígueme» para volver",
                "«ve a picar diamante» · «ve a buscar madera» (exploro lo ya descubierto)",
                "«qué llevas» · «dame todo» · «dame 10 de hierro»",
                "«revisa los cofres» · «coge hierro del cofre» · «guarda la piedra en el cofre»",
                "«craftea una pala de hierro» · «coge 3 palos del cofre y craftea una pala de hierro»",
                "«cómo estás» (estado y poderes) · «mis maos»",
                "¡Y mucho más! Escribe «ayuda 2» para ver las habilidades nuevas (cocinar, construir, plantar, efectos, tiempo, avisos...)",
                "NUEVO 1.5: cofres: «guarda todo en el cofre de arriba / abajo del todo / de la derecha / de la izquierda» (también «el segundo de la izquierda»)",
                "NUEVO 1.5: «Mao, ven aquí» llama a todos · a los demás Maos se les habla con barra y su nombre: «/Pipo ven»"
        };
        for (String l : lines) p.sendSystemMessage(Component.literal(" • " + l).withStyle(ChatFormatting.YELLOW));
    }

    // ------------------------------------------------------------------ inventario infinito

    private static MutableComponent line(ItemStack stack, long n) {
        return Component.literal(" • ").append(stack.getHoverName()).append(Component.literal(" ×" + n));
    }

    static void showInventory(ServerPlayer p, MaoEntity mao, String param) {
        if (mao.inventory.isEmpty()) {
            say(p, "Mi inventario está vacío. Pídeme que pique, explore o coja cosas de los cofres.");
            return;
        }
        MaoItems.Query q = null;
        if (param != null && !param.isBlank()) {
            q = MaoItems.resolve(MaoItems.parseAmount(param).rest());
            if (q == null) {
                say(p, "No sé qué objeto es «" + param + "».");
                return;
            }
        }
        List<com.corazondemelon.entity.MaoInventory.Entry> list = new ArrayList<>(mao.inventory.entries());
        list.sort(Comparator.comparingLong((com.corazondemelon.entity.MaoInventory.Entry e) -> e.count).reversed());
        say(p, q == null ? "Esto llevo en mi inventario infinito:" : "Esto llevo de eso:");
        int shown = 0;
        long hidden = 0;
        for (var e : list) {
            if (q != null && !q.test(e.proto)) continue;
            if (shown++ >= 30) {
                hidden++;
                continue;
            }
            p.sendSystemMessage(line(e.proto, e.count).withStyle(ChatFormatting.YELLOW));
        }
        if (shown == 0) say(p, "De eso no llevo nada.");
        if (hidden > 0) p.sendSystemMessage(Component.literal(" … y " + hidden + " tipos más.").withStyle(ChatFormatting.GRAY));
    }

    static void giveItems(ServerPlayer p, MaoEntity mao, String param) {
        MaoItems.Amount a = MaoItems.parseAmount(param == null ? "" : param);
        Predicate<ItemStack> test;
        if (a.rest().isBlank()) {
            test = s -> true;
        } else {
            MaoItems.Query q = MaoItems.resolve(a.rest());
            if (q == null) {
                say(p, "No sé qué objeto es «" + a.rest() + "».");
                return;
            }
            test = q::test;
        }
        long max = a.n() > 0 ? a.n() : Long.MAX_VALUE;
        List<ItemStack> out = mao.inventory.take(test, max);
        if (out.isEmpty()) {
            say(p, "No tengo eso en mi inventario.");
            return;
        }
        Map<String, long[]> sum = new LinkedHashMap<>();
        Map<String, ItemStack> names = new LinkedHashMap<>();
        for (ItemStack s : out) {
            String k = s.getHoverName().getString();
            sum.computeIfAbsent(k, x -> new long[1])[0] += s.getCount();
            names.putIfAbsent(k, s);
            MaoActions.giveOrDrop(p, s);
        }
        say(p, "¡Toma! Te he dado:");
        int shown = 0;
        for (var e : sum.entrySet()) {
            if (shown++ >= 20) break;
            p.sendSystemMessage(line(names.get(e.getKey()), e.getValue()[0]).withStyle(ChatFormatting.YELLOW));
        }
    }

    // ------------------------------------------------------------------ cofres

    private static Container containerAt(ServerPlayer p, ServerLevel level, BlockPos pos, boolean looked) {
        BlockEntity be = level.getBlockEntity(pos);
        if (!(be instanceof Container)) return null;
        BlockState st = level.getBlockState(pos);
        Block b = st.getBlock();
        ResourceLocation id = ForgeRegistries.BLOCKS.getKey(b);
        String path = id == null ? "" : id.getPath();
        if (path.contains("ender")) return null;
        boolean chesty = b instanceof ChestBlock || b instanceof BarrelBlock || b instanceof ShulkerBoxBlock
                || path.contains("chest") || path.contains("barrel") || path.contains("crate") || path.contains("box") || path.contains("drawer");
        if (!chesty && !looked) return null;
        if (!level.mayInteract(p, pos)) return null;
        if (be instanceof BaseContainerBlockEntity bc && !bc.canOpen(p)) return null;
        if (b instanceof ChestBlock cb) {
            ChestType t = st.getValue(ChestBlock.TYPE);
            if (t == ChestType.RIGHT && !looked) return null;      // el cofre doble se cuenta una sola vez
            return ChestBlock.getContainer(cb, st, level, pos, true);
        }
        return (Container) be;
    }

    /** Cofres cercanos (o el que miras, o tu cofre de ender si lo dices). */
    private static List<Container> containers(ServerPlayer p, String phrase) {
        List<Container> out = new ArrayList<>();
        String n = MaoPlaces.norm(phrase == null ? "" : phrase);
        if (n.contains("ender")) {
            out.add(p.getEnderChestInventory());
            return out;
        }
        ServerLevel level = p.serverLevel();
        if (n.contains("miro") || n.contains("mirando") || n.contains("este cofre") || n.contains("ese cofre")) {
            HitResult hit = p.pick(24.0D, 1.0F, false);
            if (hit instanceof BlockHitResult bhr && hit.getType() == HitResult.Type.BLOCK) {
                Container c = containerAt(p, level, bhr.getBlockPos(), true);
                if (c != null) out.add(c);
            }
            return out;
        }
        int r = MelonConfig.CHEST_RADIUS.get();
        BlockPos o = p.blockPosition();
        List<BlockEntity> found = new ArrayList<>();
        for (int cx = (o.getX() - r) >> 4; cx <= (o.getX() + r) >> 4; cx++) {
            for (int cz = (o.getZ() - r) >> 4; cz <= (o.getZ() + r) >> 4; cz++) {
                LevelChunk ch = level.getChunkSource().getChunkNow(cx, cz);
                if (ch == null) continue;
                for (BlockEntity be : new ArrayList<>(ch.getBlockEntities().values())) {
                    BlockPos bp = be.getBlockPos();
                    if (Math.abs(bp.getX() - o.getX()) > r || Math.abs(bp.getY() - o.getY()) > r || Math.abs(bp.getZ() - o.getZ()) > r) continue;
                    found.add(be);
                }
            }
        }
        found.sort(Comparator.comparingDouble(be -> be.getBlockPos().distSqr(o)));
        List<BlockPos> poss = new ArrayList<>();
        for (BlockEntity be : found) {
            Container c = containerAt(p, level, be.getBlockPos(), false);
            if (c != null) {
                out.add(c);
                poss.add(be.getBlockPos());
            }
        }
        return pickBySelector(p, phrase == null ? "" : phrase, poss, out);
    }

    /**
     * Elige UN cofre cuando dices cuál: «el de arriba (del todo)», «el de abajo», «el de la derecha / izquierda» (según hacia dónde mires),
     * «el de delante / detrás» o «el segundo de la izquierda». Si no dices nada, se usan todos los cercanos.
     */
    private static List<Container> pickBySelector(ServerPlayer p, String raw, List<BlockPos> poss, List<Container> cs) {
        boolean top = raw.contains("@arriba"), bottom = raw.contains("@abajo"), right = raw.contains("@derecha"), left = raw.contains("@izquierda");
        boolean front = raw.contains("@frente"), back = raw.contains("@atras");
        int ord = 0;
        Matcher om = Pattern.compile("@n(\\d)").matcher(raw);
        if (om.find()) ord = Integer.parseInt(om.group(1));
        if (cs.isEmpty() || !(top || bottom || right || left || front || back || ord > 0)) return cs;

        Direction d = p.getDirection();
        int fx = d.getStepX(), fz = d.getStepZ();
        int rx = -fz, rz = fx;                       // tu derecha, mirando hacia d
        int n = cs.size();
        double[] y = new double[n], side = new double[n], fwd = new double[n], dist = new double[n];
        for (int i = 0; i < n; i++) {
            BlockPos b = poss.get(i);
            double dx = b.getX() + 0.5 - p.getX(), dz = b.getZ() + 0.5 - p.getZ();
            y[i] = b.getY();
            side[i] = dx * rx + dz * rz;
            fwd[i] = dx * fx + dz * fz;
            dist[i] = dx * dx + dz * dz + (b.getY() - p.getY()) * (b.getY() - p.getY());
        }
        List<Integer> cand = new ArrayList<>();
        for (int i = 0; i < n; i++) cand.add(i);

        if (ord > 0) {
            final double[] key = top ? negate(y) : bottom ? y : right ? negate(side) : left ? side : front ? negate(fwd) : back ? fwd : dist;
            cand.sort(Comparator.<Integer>comparingDouble(i -> key[i]).thenComparingDouble(i -> dist[i]));
            if (ord > cand.size()) {
                say(p, "Solo veo " + cand.size() + (cand.size() == 1 ? " cofre" : " cofres") + " por aquí, no hay un número " + ord + ".");
                return new ArrayList<>();
            }
            return new ArrayList<>(List.of(cs.get(cand.get(ord - 1))));
        }
        if (top || bottom) cand = extreme(cand, y, top, 0.4);
        if (right || left) cand = extreme(cand, side, right, 0.6);
        if (front || back) cand = extreme(cand, fwd, front, 0.6);
        int best = cand.get(0);
        for (int i : cand) if (dist[i] < dist[best]) best = i;
        return new ArrayList<>(List.of(cs.get(best)));
    }

    private static double[] negate(double[] a) {
        double[] r = new double[a.length];
        for (int i = 0; i < a.length; i++) r[i] = -a[i];
        return r;
    }

    /** De los candidatos, los que están en el extremo (máximo o mínimo) de esa medida. */
    private static List<Integer> extreme(List<Integer> cand, double[] v, boolean max, double tol) {
        double e = max ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY;
        for (int i : cand) e = max ? Math.max(e, v[i]) : Math.min(e, v[i]);
        List<Integer> out = new ArrayList<>();
        for (int i : cand) if (Math.abs(v[i] - e) <= tol) out.add(i);
        return out.isEmpty() ? cand : out;
    }

    private static boolean chestsAllowed(ServerPlayer p) {
        if (!MelonConfig.ALLOW_CHESTS.get()) {
            say(p, "En este mundo no tengo permiso para tocar los cofres.");
            return false;
        }
        return true;
    }

    private static String stripChestWords(String s) {
        return s == null ? "" : s.replaceAll("@\\w+", " ").replaceAll("(?i)\\b(?:cofres?|barriles?|baul(?:es)?|ender|que\\s+miro|mirando)\\b", " ").replaceAll("\\s+", " ").trim();
    }

    static void chestLook(ServerPlayer p, String param) {
        if (!chestsAllowed(p)) return;
        List<Container> cs = containers(p, param);
        if (cs.isEmpty()) {
            say(p, "No veo ningún cofre a menos de " + MelonConfig.CHEST_RADIUS.get() + " bloques de ti.");
            return;
        }
        MaoItems.Query q = null;
        String phrase = stripChestWords(param);
        MaoItems.Amount a = MaoItems.parseAmount(phrase);
        if (!a.rest().isBlank()) {
            q = MaoItems.resolve(a.rest());
            if (q == null) {
                say(p, "No sé qué objeto es «" + a.rest() + "».");
                return;
            }
        }
        Map<net.minecraft.world.item.Item, long[]> counts = new LinkedHashMap<>();
        Map<net.minecraft.world.item.Item, ItemStack> protos = new LinkedHashMap<>();
        for (Container c : cs) {
            for (int i = 0; i < c.getContainerSize(); i++) {
                ItemStack s = c.getItem(i);
                if (s.isEmpty() || (q != null && !q.test(s))) continue;
                counts.computeIfAbsent(s.getItem(), x -> new long[1])[0] += s.getCount();
                protos.putIfAbsent(s.getItem(), s);
            }
        }
        if (counts.isEmpty()) {
            say(p, q == null ? "He mirado " + cs.size() + " cofre(s) y están vacíos." : "He mirado " + cs.size() + " cofre(s) y no hay de eso.");
            return;
        }
        List<Map.Entry<net.minecraft.world.item.Item, long[]>> list = new ArrayList<>(counts.entrySet());
        list.sort((x, y) -> Long.compare(y.getValue()[0], x.getValue()[0]));
        say(p, "He mirado " + cs.size() + " cofre(s). Hay:");
        int shown = 0;
        for (var e : list) {
            if (shown++ >= 25) break;
            p.sendSystemMessage(line(protos.get(e.getKey()), e.getValue()[0]).withStyle(ChatFormatting.YELLOW));
        }
        if (list.size() > 25) p.sendSystemMessage(Component.literal(" … y " + (list.size() - 25) + " tipos más.").withStyle(ChatFormatting.GRAY));
    }

    /** Saca objetos de los cofres a su inventario. @return cuántos cogió. */
    static long chestTake(ServerPlayer p, MaoEntity mao, String param) {
        if (!chestsAllowed(p)) return 0;
        List<Container> cs = containers(p, param);
        if (cs.isEmpty()) {
            say(p, "No veo ningún cofre cerca.");
            return 0;
        }
        MaoItems.Amount a = MaoItems.parseAmount(stripChestWords(param));
        MaoItems.Query q = null;
        if (!a.rest().isBlank()) {
            q = MaoItems.resolve(a.rest());
            if (q == null) {
                say(p, "No sé qué objeto es «" + a.rest() + "».");
                return 0;
            }
        } else if (!a.all()) {
            say(p, "¿Qué cojo del cofre? Dime por ejemplo «coge 3 palos del cofre» o «coge todo».");
            return 0;
        }
        long left = a.n() > 0 ? a.n() : Long.MAX_VALUE;
        long total = 0;
        Map<String, long[]> sum = new LinkedHashMap<>();
        Map<String, ItemStack> names = new LinkedHashMap<>();
        for (Container c : cs) {
            boolean changed = false;
            for (int i = 0; i < c.getContainerSize() && left > 0; i++) {
                ItemStack s = c.getItem(i);
                if (s.isEmpty() || (q != null && !q.test(s))) continue;
                int n = (int) Math.min(left, s.getCount());
                ItemStack taken = c.removeItem(i, n);
                if (taken.isEmpty()) continue;
                changed = true;
                left -= taken.getCount();
                total += taken.getCount();
                String k = taken.getHoverName().getString();
                sum.computeIfAbsent(k, x -> new long[1])[0] += taken.getCount();
                names.putIfAbsent(k, taken);
                mao.inventory.add(taken);
            }
            if (changed) c.setChanged();
        }
        if (total == 0) {
            say(p, "No he encontrado eso en los cofres.");
            return 0;
        }
        say(p, "¡Cogido! Lo guardo en mi inventario:");
        int shown = 0;
        for (var e : sum.entrySet()) {
            if (shown++ >= 15) break;
            p.sendSystemMessage(line(names.get(e.getKey()), e.getValue()[0]).withStyle(ChatFormatting.YELLOW));
        }
        return total;
    }

    private static ItemStack insert(Container c, ItemStack in) {
        ItemStack s = in.copy();
        int cap = c.getMaxStackSize();
        for (int i = 0; i < c.getContainerSize() && !s.isEmpty(); i++) {
            ItemStack t = c.getItem(i);
            int limit = Math.min(t.getMaxStackSize(), cap);
            if (!t.isEmpty() && ItemStack.isSameItemSameTags(t, s) && t.getCount() < limit && c.canPlaceItem(i, s)) {
                int mv = Math.min(s.getCount(), limit - t.getCount());
                t.grow(mv);
                s.shrink(mv);
            }
        }
        for (int i = 0; i < c.getContainerSize() && !s.isEmpty(); i++) {
            if (c.getItem(i).isEmpty() && c.canPlaceItem(i, s)) {
                int mv = Math.min(s.getCount(), Math.min(s.getMaxStackSize(), cap));
                ItemStack put = s.copy();
                put.setCount(mv);
                c.setItem(i, put);
                s.shrink(mv);
            }
        }
        c.setChanged();
        return s;
    }

    static void chestPut(ServerPlayer p, MaoEntity mao, String param) {
        if (!chestsAllowed(p)) return;
        List<Container> cs = containers(p, param);
        if (cs.isEmpty()) {
            say(p, "No veo ningún cofre cerca.");
            return;
        }
        MaoItems.Amount a = MaoItems.parseAmount(stripChestWords(param));
        Predicate<ItemStack> test;
        if (a.rest().isBlank()) {
            if (!a.all()) {
                say(p, "¿Qué guardo? Dime por ejemplo «guarda la piedra en el cofre» o «guarda todo».");
                return;
            }
            test = s -> true;
        } else {
            MaoItems.Query q = MaoItems.resolve(a.rest());
            if (q == null) {
                say(p, "No sé qué objeto es «" + a.rest() + "».");
                return;
            }
            test = q::test;
        }
        List<ItemStack> out = mao.inventory.take(test, a.n() > 0 ? a.n() : Long.MAX_VALUE);
        if (out.isEmpty()) {
            say(p, "No tengo eso en mi inventario.");
            return;
        }
        long stored = 0;
        for (ItemStack s : out) {
            ItemStack rest = s;
            for (Container c : cs) {
                if (rest.isEmpty()) break;
                rest = insert(c, rest);
            }
            stored += s.getCount() - rest.getCount();
            if (!rest.isEmpty()) mao.inventory.add(rest);
        }
        say(p, stored > 0 ? "¡Guardado! He metido " + stored + " objetos en los cofres." : "Los cofres están llenos, no he podido guardar nada.");
    }

    // ------------------------------------------------------------------ crafteo

    private record Undo(Container c, int slot, ItemStack original) {}

    private static ItemStack takeFromChests(List<Container> chests, Ingredient ing, List<Undo> undo) {
        for (Container c : chests) {
            for (int i = 0; i < c.getContainerSize(); i++) {
                ItemStack s = c.getItem(i);
                if (s.isEmpty() || !ing.test(s)) continue;
                undo.add(new Undo(c, i, s.copy()));
                ItemStack one = s.copy();
                one.setCount(1);
                c.removeItem(i, 1);
                c.setChanged();
                return one;
            }
        }
        return null;
    }

    private static boolean craftOnce(MaoEntity mao, CraftingRecipe recipe, List<Container> chests, RegistryAccess ra) {
        List<ItemStack> fromMao = new ArrayList<>();
        List<Undo> undo = new ArrayList<>();
        List<ItemStack> used = new ArrayList<>();
        for (Ingredient ing : recipe.getIngredients()) {
            if (ing.isEmpty()) continue;
            ItemStack got = mao.inventory.takeOne(ing);
            if (got != null) {
                fromMao.add(got.copy());
            } else {
                got = takeFromChests(chests, ing, undo);
            }
            if (got == null) {
                for (ItemStack s : fromMao) mao.inventory.add(s);
                for (int i = undo.size() - 1; i >= 0; i--) {
                    Undo u = undo.get(i);
                    u.c().setItem(u.slot(), u.original());
                    u.c().setChanged();
                }
                return false;
            }
            used.add(got);
        }
        for (ItemStack u : used) {
            if (u.hasCraftingRemainingItem()) mao.inventory.add(u.getCraftingRemainingItem());
        }
        mao.inventory.add(recipe.getResultItem(ra).copy());
        return true;
    }

    static void craft(ServerPlayer p, MaoEntity mao, String param, boolean forceChests) {
        String phrase = param == null ? "" : param;
        boolean useChests = forceChests || MaoPlaces.norm(phrase).contains("cofre");
        MaoItems.Amount a = MaoItems.parseAmount(stripChestWords(phrase));
        if (a.rest().isBlank()) {
            say(p, "¿Qué quieres que craftee? Dime por ejemplo «craftea una pala de hierro».");
            return;
        }
        MaoItems.Query q = MaoItems.resolve(a.rest());
        if (q == null) {
            say(p, "No sé qué objeto es «" + a.rest() + "».");
            return;
        }
        ServerLevel level = p.serverLevel();
        RegistryAccess ra = level.registryAccess();
        List<CraftingRecipe> recipes = new ArrayList<>();
        for (CraftingRecipe r : level.getRecipeManager().getAllRecipesFor(RecipeType.CRAFTING)) {
            if (r.isSpecial()) continue;
            ItemStack res = r.getResultItem(ra);
            if (!res.isEmpty() && q.test(res)) recipes.add(r);
        }
        if (recipes.isEmpty()) {
            say(p, "No sé fabricar eso con una mesa de crafteo.");
            return;
        }
        recipes.sort(Comparator.comparingInt(r -> r.getIngredients().size()));
        List<Container> chests = useChests && MelonConfig.ALLOW_CHESTS.get() ? containers(p, "") : new ArrayList<>();

        long target = a.all() ? 2000 : Math.max(1, a.n());
        long made = 0;
        CraftingRecipe used = null;
        ItemStack sample = ItemStack.EMPTY;
        while (made < target) {
            CraftingRecipe done = null;
            List<CraftingRecipe> tryList = used != null ? List.of(used) : recipes;
            for (CraftingRecipe r : tryList) {
                if (craftOnce(mao, r, chests, ra)) {
                    done = r;
                    break;
                }
            }
            if (done == null) break;
            used = done;
            sample = done.getResultItem(ra);
            made += sample.getCount();
        }
        if (made == 0) {
            CraftingRecipe r = recipes.get(0);
            Map<String, ItemStack> need = new LinkedHashMap<>();
            Map<String, Integer> cnt = new LinkedHashMap<>();
            for (Ingredient ing : r.getIngredients()) {
                if (ing.isEmpty() || ing.getItems().length == 0) continue;
                ItemStack s = ing.getItems()[0];
                String k = s.getHoverName().getString();
                need.putIfAbsent(k, s);
                cnt.merge(k, 1, Integer::sum);
            }
            say(p, "No tengo los materiales para fabricar eso. Necesito:");
            for (var e : need.entrySet()) {
                p.sendSystemMessage(line(e.getValue(), cnt.get(e.getKey())).withStyle(ChatFormatting.YELLOW));
            }
            if (!useChests) say(p, "Si están en un cofre, dime «coge … del cofre y craftea …».");
            return;
        }
        say(p, "¡Crafteado! He fabricado:");
        p.sendSystemMessage(line(sample, made).withStyle(ChatFormatting.YELLOW));
        sparkle(mao, ParticleTypes.HAPPY_VILLAGER);
    }

    static void takeAndCraft(ServerPlayer p, MaoEntity mao, String param) {
        String[] parts = (param == null ? "" : param).split("\\|", 2);
        if (parts.length < 2) {
            say(p, "Dime qué coger y qué craftear: «coge 3 palos del cofre y craftea una pala de hierro».");
            return;
        }
        chestTake(p, mao, parts[0]);
        craft(p, mao, parts[1], true);
    }

    // ------------------------------------------------------------------ proteger una zona

    private static ServerLevel levelByDim(MinecraftServer server, String dim) {
        ResourceLocation id = ResourceLocation.tryParse(dim == null ? "" : dim);
        return id == null ? null : server.getLevel(ResourceKey.create(Registries.DIMENSION, id));
    }

    static void guard(ServerPlayer p, MaoEntity mao, String param) {
        if (mao.isRepresentative()) {
            say(p, "Yo soy tu Mao representante: siempre voy contigo. Pídeselo a otro Mao, por ejemplo «/Pipo protege esta zona».");
            return;
        }
        String[] parts = (param == null ? "" : param).split("\\|", -1);
        String place = parts.length > 0 ? parts[0].trim() : "";
        int radius = 16;
        if (parts.length > 1 && parts[1].trim().matches("\\d{1,3}")) radius = Integer.parseInt(parts[1].trim());
        BlockPos anchor;
        String dim;
        String label;
        if (place.isEmpty()) {
            anchor = p.blockPosition();
            dim = p.level().dimension().location().toString();
            label = "esta zona";
        } else {
            MaoPlaces.Place pl = MaoPlaces.get(p, place);
            if (pl == null) {
                List<MaoPlaces.Place> list = MaoPlaces.list(p);
                String names = list.isEmpty() ? "ninguno todavía" : String.join(", ", list.stream().map(MaoPlaces.Place::name).toList());
                say(p, "No conozco ningún sitio llamado «" + MaoPlaces.cleanName(place) + "». Dime «protege esta zona» o un sitio guardado: " + names + ".");
                return;
            }
            anchor = new BlockPos(pl.x(), pl.y(), pl.z());
            dim = pl.dim();
            label = "«" + pl.name() + "»";
        }
        mao.startGuard(anchor, dim, radius);
        ServerLevel dest = levelByDim(p.server, dim);
        if (dest != null && (mao.level() != dest || mao.distanceToSqr(anchor.getX() + 0.5, anchor.getY() + 0.5, anchor.getZ() + 0.5) > 48.0 * 48.0)) {
            mao.warpTo(dest, anchor.getX() + 0.5, anchor.getY() + 1.0, anchor.getZ() + 0.5);
        }
        say(p, "¡Vale! Me quedo protegiendo " + label + " (radio " + mao.getZoneRadius() + "). Si viene un monstruo, ¡me lo como! Dime «sígueme» cuando quieras que vuelva contigo.");
    }

    private static boolean free(ServerLevel level, BlockPos pos) {
        return level.isLoaded(pos) && level.getBlockState(pos).getCollisionShape(level, pos).isEmpty();
    }

    private static void tickGuard(MaoEntity mao, ServerLevel level) {
        BlockPos a = mao.getAnchor();
        if (a == null) {
            mao.returnToFollow();
            return;
        }
        if (!level.dimension().location().toString().equals(mao.getAnchorDim())) {
            ServerLevel dest = levelByDim(level.getServer(), mao.getAnchorDim());
            if (dest == null) mao.returnToFollow();
            else mao.warpTo(dest, a.getX() + 0.5, a.getY() + 1.0, a.getZ() + 0.5);
            return;
        }
        int r = mao.getZoneRadius();
        double d2 = mao.distanceToSqr(a.getX() + 0.5, a.getY() + 0.5, a.getZ() + 0.5);
        if (d2 > (r + 12.0) * (r + 12.0)) {
            if (d2 > 80.0 * 80.0) mao.warpTo(level, a.getX() + 0.5, a.getY() + 1.0, a.getZ() + 0.5);
            else if (mao.tickCount % 20 == 0) mao.getNavigation().moveTo(a.getX() + 0.5, a.getY() + 1.0, a.getZ() + 0.5, 1.2D);
            return;
        }
        if (mao.getNavigation().isDone() && mao.getRandom().nextInt(40) == 0) {
            for (int i = 0; i < 6; i++) {
                int x = a.getX() + mao.getRandom().nextInt(2 * r + 1) - r;
                int z = a.getZ() + mao.getRandom().nextInt(2 * r + 1) - r;
                int y = a.getY() + mao.getRandom().nextInt(7) - 2;
                BlockPos c = new BlockPos(x, y, z);
                if (free(level, c) && free(level, c.above())) {
                    mao.getNavigation().moveTo(x + 0.5, y, z + 0.5, 1.0D);
                    break;
                }
            }
        }
    }

    // ------------------------------------------------------------------ picar y explorar por su cuenta

    static void startJob(ServerPlayer p, MaoEntity mao, String param, MaoEntity.Mode mode) {
        if (mao.isRepresentative()) {
            say(p, "Yo soy tu Mao representante: siempre voy contigo. Pídeselo a otro Mao, por ejemplo «/Pipo ve a picar hierro».");
            return;
        }
        if (!MelonConfig.ALLOW_BREAK.get() || !MelonConfig.ALLOW_AUTOWORK.get()) {
            say(p, "En este mundo mis manitas no pueden trabajar por su cuenta.");
            return;
        }
        MaoItems.Amount a = MaoItems.parseAmount(param == null ? "" : param);
        String target = a.rest().replaceAll("\\b(?:bloques?|de|del|los|las|el|la|un|una|unos|unas|y)\\b", " ").replaceAll("\\s+", " ").trim();
        if (target.isEmpty()) {
            say(p, "¿Qué busco? Dime por ejemplo «ve a picar hierro» o «ve a buscar madera».");
            return;
        }
        mao.startJob(mode, target, a.n());
        String how = mode == MaoEntity.Mode.MINE
                ? "Voy a picar «" + target + "» cerca de aquí, lentamente (cavo túneles si hace falta)."
                : "Voy a explorar lo ya descubierto buscando «" + target + "» (solo lo que está a la vista, sin cavar).";
        say(p, "¡Vale! " + how + (a.n() > 0 ? " Pararé al conseguir " + a.n() + "." : "") + " Lo guardo todo en mi inventario y te aviso al terminar.");
    }

    private static void finish(MaoEntity mao, ServerPlayer owner, String msg) {
        MaoActions.setSpeaker(mao);
        MaoActions.say(owner, msg);
        mao.returnToFollow();
    }

    public static void tickJob(MaoEntity mao) {
        if (!(mao.level() instanceof ServerLevel level)) return;
        ServerPlayer owner = mao.ownerPlayer();
        if (owner == null) return;
        switch (mao.getMode()) {
            case GUARD -> tickGuard(mao, level);
            case MINE, EXPLORE -> tickGather(mao, level, owner);
            default -> { }
        }
    }

    private static boolean adjacentFluid(ServerLevel level, BlockPos pos) {
        for (Direction d : Direction.values()) {
            BlockPos n = pos.relative(d);
            if (level.isLoaded(n) && !level.getFluidState(n).isEmpty()) return true;
        }
        return false;
    }

    private static boolean exposed(ServerLevel level, BlockPos pos) {
        for (Direction d : Direction.values()) {
            BlockPos n = pos.relative(d);
            if (!level.isLoaded(n)) continue;
            if (!level.getBlockState(n).isCollisionShapeFullBlock(level, n)) return true;
        }
        return false;
    }

    private static BlockPos findTarget(MaoEntity mao, ServerLevel level, boolean dig, Predicate<BlockState> test) {
        BlockPos o = mao.blockPosition();
        BlockPos center = dig && mao.getAnchor() != null ? mao.getAnchor() : o;
        int rxz = dig ? MelonConfig.WORK_RADIUS.get() : MelonConfig.EXPLORE_RADIUS.get();
        int ry = dig ? rxz : Math.min(rxz, 64);
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int cx = (center.getX() - rxz) >> 4; cx <= (center.getX() + rxz) >> 4; cx++) {
            for (int cz = (center.getZ() - rxz) >> 4; cz <= (center.getZ() + rxz) >> 4; cz++) {
                LevelChunk ch = level.getChunkSource().getChunkNow(cx, cz);
                if (ch == null) continue;
                LevelChunkSection[] secs = ch.getSections();
                for (int i = 0; i < secs.length; i++) {
                    LevelChunkSection sec = secs[i];
                    if (sec == null || sec.hasOnlyAir() || !sec.maybeHas(test)) continue;
                    int baseY = (ch.getMinSection() + i) << 4;
                    if (baseY + 15 < center.getY() - ry || baseY > center.getY() + ry) continue;
                    for (int x = 0; x < 16; x++) {
                        for (int y = 0; y < 16; y++) {
                            for (int z = 0; z < 16; z++) {
                                BlockState st = sec.getBlockState(x, y, z);
                                if (st.isAir() || !test.test(st)) continue;
                                BlockPos pos = new BlockPos((cx << 4) + x, baseY + y, (cz << 4) + z);
                                if (Math.abs(pos.getX() - center.getX()) > rxz || Math.abs(pos.getZ() - center.getZ()) > rxz
                                        || Math.abs(pos.getY() - center.getY()) > ry) continue;
                                if (mao.blacklist.contains(pos) || st.getDestroySpeed(level, pos) < 0.0F) continue;
                                if (!dig && !exposed(level, pos)) continue;
                                double d = o.distSqr(pos);
                                if (d < bestD) {
                                    bestD = d;
                                    best = pos;
                                }
                            }
                        }
                    }
                }
            }
        }
        return best;
    }

    private static boolean mineBlock(MaoEntity mao, ServerLevel level, ServerPlayer owner, BlockPos pos, BlockState st) {
        if (!MaoActions.breakable(level, owner, pos, st)) return false;
        if (adjacentFluid(level, pos)) return false;
        List<ItemStack> drops = Block.getDrops(st, level, pos, null, mao, ItemStack.EMPTY);
        level.destroyBlock(pos, false, mao);
        for (ItemStack d : drops) mao.inventory.add(d);
        return true;
    }

    private static BlockPos standNear(ServerLevel level, BlockPos target, BlockPos from) {
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (Direction d : Direction.values()) {
            BlockPos n = target.relative(d);
            if (!free(level, n)) continue;
            double dist = from.distSqr(n);
            if (dist < bestD) {
                bestD = dist;
                best = n;
            }
        }
        return best;
    }

    private static void digToward(MaoEntity mao, ServerLevel level, ServerPlayer owner, BlockPos target, long now) {
        BlockPos cur = mao.blockPosition();
        int dx = target.getX() - cur.getX();
        int dy = target.getY() - cur.getY();
        int dz = target.getZ() - cur.getZ();
        Direction dir;
        if (Math.abs(dx) >= Math.abs(dy) && Math.abs(dx) >= Math.abs(dz)) dir = dx > 0 ? Direction.EAST : Direction.WEST;
        else if (Math.abs(dz) >= Math.abs(dy)) dir = dz > 0 ? Direction.SOUTH : Direction.NORTH;
        else dir = dy > 0 ? Direction.UP : Direction.DOWN;
        BlockPos step = cur.relative(dir);
        if (!level.isLoaded(step)) {
            mao.blacklist.add(target);
            mao.jobPos = null;
            return;
        }
        BlockState st = level.getBlockState(step);
        if (!st.getCollisionShape(level, step).isEmpty()) {
            if (now < mao.nextWork) return;
            if (!mineBlock(mao, level, owner, step, st)) {
                mao.blacklist.add(target);
                mao.jobPos = null;
                return;
            }
            mao.nextWork = now + MelonConfig.WORK_SECONDS.get() * 20L;
        } else if (mao.tickCount % 6 == 0) {
            mao.getNavigation().stop();
            mao.setPos(step.getX() + 0.5, step.getY(), step.getZ() + 0.5);
        }
    }

    private static void tickGather(MaoEntity mao, ServerLevel level, ServerPlayer owner) {
        if (!MelonConfig.ALLOW_BREAK.get() || !MelonConfig.ALLOW_AUTOWORK.get()) {
            finish(mao, owner, "Ya no me dejan trabajar por mi cuenta en este mundo, vuelvo contigo.");
            return;
        }
        boolean dig = mao.getMode() == MaoEntity.Mode.MINE;
        String name = mao.getJobTarget();
        Predicate<BlockState> test = MaoActions.matcher(name);
        long now = level.getGameTime();
        BlockPos target = mao.jobPos;
        if (target != null && (!level.isLoaded(target) || mao.blacklist.contains(target) || !test.test(level.getBlockState(target)))) {
            target = null;
            mao.jobPos = null;
        }
        if (target == null) {
            if (now < mao.nextScan) return;
            target = findTarget(mao, level, dig, test);
            if (target == null) {
                mao.nextScan = now + 80L;
                if (++mao.noTargetScans >= 2) {
                    finish(mao, owner, mao.getJobGot() > 0
                            ? "Ya no encuentro más «" + name + "» por aquí. He conseguido " + mao.getJobGot() + " bloques; todo está en mi inventario («dame lo que tengas»). Vuelvo contigo."
                            : "No encuentro «" + name + "» " + (dig ? "a menos de " + MelonConfig.WORK_RADIUS.get() + " bloques" : "en lo ya explorado")
                            + ". Vuelvo contigo.");
                }
                return;
            }
            mao.jobPos = target;
            mao.noTargetScans = 0;
            mao.stuck = 0;
        }
        Vec3 c = Vec3.atCenterOf(target);
        mao.getLookControl().setLookAt(c.x, c.y, c.z);
        double dist = mao.position().add(0, mao.getBbHeight() / 2.0, 0).distanceTo(c);
        if (dist <= 3.0D) {
            if (now >= mao.nextWork) {
                mao.nextWork = now + MelonConfig.WORK_SECONDS.get() * 20L;
                BlockState st = level.getBlockState(target);
                if (mineBlock(mao, level, owner, target, st)) {
                    mao.addJobGot(1);
                    mao.jobPos = null;
                    mao.stuck = 0;
                    if (mao.getJobAmount() > 0 && mao.getJobGot() >= mao.getJobAmount()) {
                        finish(mao, owner, "¡Terminé! He conseguido " + mao.getJobGot() + " bloques de «" + name
                                + "». Lo tengo en mi inventario: dime «dame lo que tengas». Vuelvo contigo.");
                    }
                } else {
                    mao.blacklist.add(target);
                    mao.jobPos = null;
                }
            }
            return;
        }
        if (++mao.stuck > 20 * 60) {
            mao.blacklist.add(target);
            mao.jobPos = null;
            mao.stuck = 0;
            return;
        }
        if (dig) {
            digToward(mao, level, owner, target, now);
        } else if (mao.getNavigation().isDone() || mao.tickCount % 40 == 0) {
            BlockPos stand = standNear(level, target, mao.blockPosition());
            boolean ok = stand != null && mao.getNavigation().moveTo(stand.getX() + 0.5, stand.getY() + 0.5, stand.getZ() + 0.5, 1.1D);
            if (!ok) {
                mao.blacklist.add(target);
                mao.jobPos = null;
            }
        }
    }
}
