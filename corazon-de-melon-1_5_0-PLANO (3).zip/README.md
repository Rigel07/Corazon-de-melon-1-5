# Corazón de Melon

Mod de **Minecraft Forge 1.20.1** (Forge 47.3.0+, Java 17).

Encuentra **corazones mágicos**, sube tu nivel de **Inocencia** (de *Bruto* a *Santo*) y los mobs te tratarán cada vez con más cariño.
Conoce a **Mao**, un pequeño ángel inmortal que puede ser tu compañero y asistente (con IA opcional): encuentra minerales y estructuras, guarda lugares y te teletransporta, rompe bloques y cultiva.

## Cómo conseguir el .jar (GitHub)

1. Crea un repositorio en GitHub y sube todo este proyecto (`git init`, `git add .`, `git commit`, `git push`).
2. GitHub Actions compilará el mod automáticamente (pestaña **Actions** → último *Build* → artefacto `corazon-de-melon` → contiene el `.jar`).
3. Para publicar una *release* con el `.jar` adjunto: `git tag v1.0.0 && git push origin v1.0.0`.
4. Mete el `.jar` en la carpeta `mods/` de Minecraft Forge 1.20.1 (cliente y servidor).

### Compilar en tu PC
Necesitas JDK 17 y Gradle 8.x: `gradle wrapper` (una vez) y luego `./gradlew build`. El `.jar` queda en `build/libs/`.

## Corazones mágicos

| Corazón | Color | Inocencia | Rareza |
|---|---|---|---|
| Corazón mágico | Rosa | +1 | Común |
| Corazón mágico azul | Azul | +3 | Poco común |
| Corazón mágico dorado | Dorado | +8 | Raro |
| Corazón mágico violeta | Violeta | +20 | Épico |

- Aparecen **tirados en el suelo del Overworld** cerca de los jugadores, con un brillo para poder localizarlos (configurable).
- También pueden aparecer en **cofres** de estructuras (30 % de los cofres de vanilla).
- Al **recogerlos del suelo** se absorben al instante. Los que salen de cofres se absorben con **clic derecho**.
- **Buenas acciones** también suben la barra: cosechar cultivos maduros (+0.12), comerciar con aldeanos (+0.4), criar animales (+0.3), domesticar (+1.5).

## Niveles de Inocencia

La barra aparece unos segundos al ganar experiencia, o mientras mantienes **I** (configurable en Controles). Cada nivel cuesta más que el anterior.

| Nv | Nombre | XP total |
|---|---|---|
| 1 | Bruto | 0 |
| 2 | Salvaje | 8 |
| 3 | Arisco | 25 |
| 4 | Tranquilo | 55 |
| 5 | Amable | 105 |
| 6 | Gentil | 180 |
| 7 | Bondadoso | 290 |
| 8 | Puro | 450 |
| 9 | Angelical | 700 |
| 10 | Santo | 1100 |

Efectos:

- **Nv 5+**: los mobs hostiles que te persiguen pueden retirarse (probabilidad creciente; si los atacas, no se calman). Los animales pasivos te regalan objetos y efectos (vaca → cuero + regeneración, abeja → panal + velocidad, etc.).
- **Nv 3+**: puedes domesticar a Mao (los Maos salvajes ya no huyen de ti).
- **Nv 7+**: aura de Suerte (Suerte II en nivel 10).
- **Nv 8+**: lobos, gatos, loros y caballos salvajes **se domestican solos** (los lobos sueltan un hueso) y los hostiles calmados **te defienden** de otros hostiles durante unos segundos. Los aldeanos te dan esmeraldas con *Héroe de la aldea*.
- **Nv 9+**: los hostiles calmados a veces te dejan un objeto (pólvora, hueso, hilo...).
- Los jefes (Wither, Ender Dragon) y el Warden son inmunes a la calma.

## Mao, el pequeño ángel

- **Varios Maos salvajes** viven repartidos por el Overworld (aparecen con el mundo y, de día, cerca de los jugadores; hasta 4 salvajes alrededor de cada jugador, configurable con `maoMaxNearby`).
- Si tu Inocencia es **menor de 3** (Bruto/Salvaje) huye de ti. Desde el **nivel 3** se acerca y puedes **domesticarlo con una zanahoria dorada** (no siempre sale a la primera; más Inocencia = más probabilidad). Si tienes 6+ te regala objetos. Huevo de aparición en el creativo.
- **Inmortal** una vez domesticado: ignora todo el daño (fuego, lava, caídas, ahogamiento, mobs, tu propio golpe...). Si cae al vacío vuelve contigo. Solo un `/kill` de un admin puede eliminarlo.
- Domesticado: te sigue, te defiende, te cura cuando estás por debajo del 50 % de vida. **Clic derecho (mano vacía)** lo sienta o lo hace seguirte. Una zanahoria dorada lo cura.

### Mao, tu asistente (escribe en el chat `Mao, <mensaje>` o `/mao <mensaje>`)

Estas órdenes funcionan **al instante y sin clave de IA**:

| Dile... | Qué hace |
|---|---|
| `Mao, quédate` / `quieto` / `espera` | Se queda quieto |
| `Mao, sígueme` / `vamos` | Vuelve a seguirte |
| `Mao, ven` | Se teletransporta a tu lado |
| `Mao, dime los minerales cercanos` | Lista de minerales alrededor (32 bloques) con cantidad, dirección y coordenadas |
| `Mao, ¿hay diamantes cerca?` / `busca hierro` | Busca solo ese mineral |
| `Mao, ¿qué estructuras hay cerca?` | Aldeas, templos, minas, fortalezas... **ya generadas** cerca de ti |
| `Mao, rompe la piedra` / `pica el hierro` / `tala los árboles` | Rompe hasta 32 bloques de ese tipo (radio 16) y te trae los objetos |
| `Mao, rompe ese bloque` | Rompe el bloque al que miras |
| `Mao, cultiva` / `cosecha` | Cosecha los cultivos maduros (radio 10), los replanta y siembra tierra vacía con tus semillas |
| `Mao, guarda este sitio como mi casa` | Recuerda el lugar (hasta 40; también la dimensión) |
| `Mao, llévame a casa` / `teletranspórtame a casa` | Te teletransporta a ese sitio (y Mao viene contigo si no lo has sentado) |
| `Mao, ¿qué lugares tengo?` / `¿dónde está mi casa?` | Lista de sitios guardados |
| `Mao, olvida el sitio casa` | Borra un sitio |
| `Mao, cúrame` | Te cura un poco |

Además, Mao **te avisa solo** cuando ve una estructura nueva cerca (`announceStructures`).
Con la IA configurada, puedes pedirlo con tus propias palabras ("oye Mao, ¿me guardas esto como la mina de hierro?") y también charlar con él, pedirle consejos de Minecraft, etc.
Si Mao está lejos o en otra dimensión, también te oye: `Mao, ven` lo trae.

Cosas que Mao **no** rompe: bedrock, cofres, hornos y demás bloques con inventario, spawners ni líquidos. Respeta la protección de spawn y los claims de otros mods. Se puede desactivar romper y teletransportar en el `.toml` (`allowBreakBlocks`, `allowTeleport`).

### Mao y los otros mods (nuevo en 1.3.0)

Mao reconoce lo que traen los demás mods **sin necesitar ninguna librería extra**: lee los registros de Forge, así que funciona con cualquier mod instalado.

| Dile... | Qué hace |
|---|---|
| `Mao, qué mods tengo` | Lista los mods instalados (los amigos salen con ♥ y una nota) |
| `Mao, qué mobs hay cerca` | Lista las criaturas cercanas, primero las de otros mods, con su mod y a cuántos bloques están |
| `Mao, qué es esto` | Identifica lo que miras (criatura o bloque) o lo que llevas en la mano, y de qué mod es. Di «lo que llevo en la mano» para priorizar el objeto |
| `Mao, abraza a la flowy` | Va a abrazar a un amigo cercano (lo cura un poco) |
| `Mao, dime los minerales` | Ahora también muestra de qué mod es cada mineral; ya encontraba los de otros mods |

Con IA activada, Mao conoce los nombres de los mods instalados y qué amigos tiene cerca, y puede usar estas mismas acciones por su cuenta.

**Convivencia (automática):**
- Mao **no ataca** a sus amigos: criaturas de la lista `friendEntities` (por defecto todas las de **Flowys** y **Nutrias**), mascotas domesticadas por su mismo dueño y otros Maos.
- Si algo ataca a un amigo, Mao lo **defiende**.
- Cada 1-2 minutos, si hay un amigo a menos de 8 bloques, Mao va a **abrazarlo**: corazoncitos, lo cura un poco y, como mucho cada 3 minutos, +0,5 de Inocencia para ti.
- Un Mao salvaje con amigos cerca a veces regala **flores** (de Minecraft o de cualquier mod que use la etiqueta de flores).
- Las estructuras de otros mods que no conoce las anuncia con el nombre del mod.

**Ajustes** (`config/corazondemelon-common.toml`, sección `[mods]`): `recognizeMods` (apaga todo), `friendEntities` (`"modid:*"` o `"modid:criatura"`), `protectFriends`, `hugFriends`.
Para añadir las criaturas de otro mod como amigas, por ejemplo: `friendEntities = ["flowys:*", "nutriamod:*", "othermod:*"]`.

### Configurar la IA (dentro del juego)

1. Pulsa la tecla **K** (o ve a **Mods → Corazón de Melon → Config**).
2. Elige el proveedor (Groq, xAI, Anthropic, Ollama o Personalizado), pega tu clave de API con **Ctrl+V** y pulsa **Guardar**.
3. Si el nombre del modelo ya no existe, cámbialo por uno de la lista de tu proveedor.

Funciona al momento, sin reiniciar. Solo vale en tu mundo o LAN; en un servidor dedicado edita `config/corazondemelon-common.toml`.
También puedes usar la variable de entorno `MAO_API_KEY`. **No subas tu clave a GitHub.**

Sin clave, Mao entiende todas las órdenes de la tabla de arriba, pero no charla.

## Los Maos 1.4.0: equipo de Maos

Todo se pide por el chat, empezando por el nombre del Mao: `Mao 2, ...`, `Luna, ...` o `Todos, ...` (también con `/mao <mensaje>`). Sin clave de IA funciona igual.

**Varios Maos y nombres**
- El primer Mao que domestiques es el **Mao representante**: se llama siempre «Mao», **te sigue a todas partes sí o sí** y no se puede sentar ni mandar a trabajar.
- Los demás se llaman «Mao 2», «Mao 3»... y puedes cambiarles el nombre: `Mao 2, llámate Luna` · `ponle Luna al Mao 2` · `renombra Mao 2 como Luna` (también vale una etiqueta de nombre). Cada Mao habla con su nombre en el chat.
- `mis maos` los lista (dónde están y qué hacen).

**Teletransporte con los que te siguen**: los Maos que te siguen (y siempre el representante) se teletransportan contigo a cualquier distancia o dimensión (`/tp`, portales, perlas, etc.).

**Colores**: `ponte rosa` · `ponte verde` · `ponte azul` · `ponte violeta` · `vuelve a tu color`. Ej.: `Luna, ponte azul` o `ponle verde al Mao 2`.

**Proteger una zona**: `Mao 2, protege esta zona` · `vigila la casa radio 20` · `deambula por la mina`. Se queda dando vueltas por la zona y ataca a los monstruos que se acerquen. `sígueme` o `ven` para que vuelva. (Solo está activo mientras el trozo de mundo esté cargado.)

**Inventario infinito**: cada Mao tiene el suyo. `qué llevas` · `cuántos diamantes tienes` · `dame todo` · `dame 10 de hierro`.

**Cofres** (los que hay a menos de `chestRadius` bloques de ti, el que miras, o tu cofre de ender):
- `revisa los cofres` · `busca hierro en los cofres`
- `coge 3 palos del cofre` · `coge todo del cofre` · `guarda la piedra en el cofre`

**Crafteo**: `craftea una pala de hierro` · `craftea 8 antorchas` · `craftea todas las tablas`. Usa lo que tenga en su inventario. Si los materiales están en el cofre: `coge 3 palos y 2 lingotes de hierro del cofre y craftea una pala de hierro` o `craftea una pala de hierro con lo del cofre`.

**Trabajar por su cuenta** (nunca el representante; lo que consigue va a su inventario y te avisa al terminar):
- `ve a picar diamante` · `mina 10 de hierro por tu cuenta`: pica despacio (un bloque cada `secondsPerBlock` s) cavando túneles hacia el mineral, en un radio de `workRadius` bloques.
- `ve a buscar madera` · `busca hierro por el mundo`: explora solo lo ya descubierto (zonas generadas y cargadas, hasta `exploreRadius` bloques) y recoge el material que está a la vista, sin cavar.
- Con «dime/busca hierro» a secas siguen funcionando los avisos instantáneos de siempre.

**Poder según tu Inocencia** (se puede desactivar con `levelPowers`; con `/mao estado` ves lo tuyo):

| Nivel | Daño de los Maos | Efectos únicos |
|---|---|---|
| 3-4 | 3 · 4 | Te curan si estás herido |
| 5-6 | 5 · 6 | Frenan a los enemigos al golpear · nv 6: +1 corazón extra para ti |
| 7 | 8 | Debilitan y marcan a los enemigos · +2 corazones · regeneración pasiva |
| 8 | 10 | +3 corazones · inmunidad a veneno, wither, hambre y náuseas |
| 9 | 13 | +4 corazones · regeneración II · inmunidad a TODAS las desventajas · daño sagrado contra no-muertos |
| 10 | 17 | +5 corazones · te curan al golpear · **revivir**: si vas a morir, un Mao te revive con media vida (cada `reviveCooldownMinutes` min) |

Los corazones extra, la regeneración y la inmunidad funcionan mientras tengas algún Mao a menos de 48 bloques.

Nuevos ajustes en la sección `mao` del `.toml`: `levelPowers`, `followTeleport`, `allowChests`, `allowAutonomousWork`, `workRadius`, `exploreRadius`, `secondsPerBlock`, `chestRadius`, `reviveCooldownMinutes`.

## Varios Maos: nombres y cómo hablarles (1.5.0)

- **Solo el primer Mao (el representante) se llama «Mao».** Los demás reciben un nombre divertido solo (Pipo, Chispa, Tofu, Mochi, Churro...). Los Maos de mundos anteriores que se llamaban «Mao 2», «Mao 3»... se renombran solos al cargarse.
- **«Mao, ven aquí»** (también «Mao, sígueme», «Mao, vuelve conmigo») **llama a TODOS** tus Maos, estén donde estén y hagan lo que hagan. Cualquier otra orden a «Mao» la atiende solo el representante.
- **Para hablar con uno concreto, escribe barra y su nombre:** `/Pipo ven`, `/Chispa protege esta zona`, `/Tofu ve a picar hierro`. Funciona aunque el nombre tenga varias palabras. No pisa a ningún comando real.
- Para cambiarle el nombre: `/Pipo llámate Luna`. El nombre «Mao» queda reservado para el representante.
- **«Todos, ...»** sigue mandando una orden a todos a la vez (`Todos, ponte rosa`).
- **Teletransporte:** los Maos que te siguen (siempre el representante) van contigo a cualquier distancia o dimensión. Si te vas lejos de golpe, el mod carga la zona donde se quedaron unos segundos para poder traerlos. No se teletransportan los que estén sentados («quédate») o con una tarea (proteger una zona, picar, explorar).
- **Cofres con nombre:** `guarda todo en el cofre de arriba del todo`, `...de abajo del todo`, `...de la derecha`, `...de la izquierda` (derecha e izquierda según hacia dónde mires), `...de delante`, `...de detrás`, `el segundo cofre de la izquierda`, `coge hierro del cofre de arriba a la derecha`. Sin decir cuál, usa todos los cercanos como antes.

## Los Maos 1.5.0: ¡muchísimas cosas nuevas!

Todo funciona por el chat, sin clave de IA (`Mao, ...`, `Mao 2, ...`, `Todos, ...` o `/mao ...`). Escribe **«ayuda 2»** para verlo en el juego.
Muchas habilidades piden un nivel de Inocencia mínimo (se desactiva con `levelPowers`).

| Grupo | Qué dices | Qué hace |
|---|---|---|
| Información | `qué hora es` · `dónde estoy` · `en qué bioma estoy` · `va a llover` · `qué día es` · `nivel de luz` · `mis estadísticas` | Hora, coordenadas, bioma, clima, luz y tus estadísticas |
| Recetas | `cómo se hace una pala de hierro` | Te dice ingredientes, si necesita mesa y si se hace en horno |
| Cuidarte | `aliméntame` | Te da comida de su inventario (o un bocadito mágico) |
| | `dame velocidad / salto / visión nocturna / prisa / respirar / fuerza / resistencia / regeneración / resistencia al fuego / suerte / caída de pluma` | Efectos de varios minutos (nivel 3 a 7) |
| | `bendíceme` · `protégeme` · `purifícame` | Pack de efectos · corazones dorados + resistencia · quita efectos negativos |
| | `repara mis cosas` | Repara un % de tus herramientas y armadura (cada 5 min, nivel 4) |
| Mascotas | `cura a mis mascotas` · `reúne a mis mascotas` | Cura a lobos, gatos, loros y caballos tuyos / los trae a tu lado |
| Lucha | `limpia la zona de monstruos` · `invoca un rayo` (nivel 9) | Golpea a los monstruos cercanos / rayo donde miras |
| Mundo | `pon día` · `pon noche` · `para la lluvia` · `que llueva` · `pon una tormenta` | Cambia el tiempo (nivel 6, `allowWorldMagic`) |
| Viajes | `llévame a mi cama` · `a donde morí` · `al spawn` · `vuelve al sitio anterior` | Te teletransporta (y vuelve atrás) |
| | `dame un mapa` | Te da un mapa de la zona (`grande` / `pequeño`) |
| Construir | `haz un refugio [de piedra]` · `cava un túnel de 20` · `cava una escalera de 15` · `haz un puente de 10` · `pon antorchas` | Usa los bloques/antorchas de su inventario infinito (`allowBuild`) |
| Campo | `planta árboles` · `abona los cultivos` · `cría a los animales` · `esquila las ovejas` · `ordeña las vacas` · `recoge los objetos del suelo` | Usa brotes, polvo de hueso, comida, cubos... de su inventario |
| Cocina | `funde el hierro` · `cocina la carne` · `cocina todo` | Usa el combustible de su inventario y te da la experiencia |
| Recordar | `avísame en 5 minutos para sacar el pan` · `apunta que tengo que ir a la mina` · `mis notas` · `borra las notas` · `cancela los avisos` | Avisos (hasta 8 por Mao) y libreta de 30 notas |
| Diversión | `cuéntame un chiste` · `dime un dato curioso` · `tira un dado de 20` · `cara o cruz` · `elige entre A o B` · `haz una fiesta` · `baila` · `ánimo` | Chistes, datos, fuegos artificiales y más |

**Habilidades automáticas** (`activa recoger`, `desactiva recoger`, `qué habilidades tienes`): cada Mao las hace solo mientras está a menos de 48 bloques de ti.

| Habilidad | Nivel | Qué hace |
|---|---|---|
| `recoger` | 2 | Recoge los objetos tirados lejos de ti en su inventario infinito |
| `comida` | 3 | Te da de comer cuando tienes hambre |
| `antorchas` | 3 | Pone antorchas si donde estás está oscuro |
| `alertas` | 3 | Te avisa de monstruos (resalta a los cercanos), creepers, la noche, poca vida, hambre y herramientas a punto de romperse |
| `salvavidas` | 5 | Anula el daño de caídas, te da resistencia al fuego si ardes y aire si te ahogas |

Nuevos ajustes en la sección `mao` del `.toml`: `allowWorldMagic`, `allowBuild`, `allowPerks`.
Con IA activada, Mao también puede usar todas estas acciones por su cuenta.

## Comandos

- `/inocencia` — muestra tu nivel.
- `/inocencia nivel <1-10>` y `/inocencia dar <xp>` — para probar (requieren OP).
- `/mao <mensaje>` — hablar con tu Mao representante. Para otro Mao pon su número o su nombre: `/mao 2 vuelve`, `/mao 3 ven`, `/mao Luna ven`, `/mao todos sígueme` (el 1 es el representante).

## Ajustes de dificultad

En el mismo `.toml`: `xpMultiplier`, `heartSpawnIntervalSeconds`, `heartSpawnChance`, `maxHeartsNearby`, `heartsGlow`, `maoSpawnChance`, `maoMaxNearby` y, en la sección `assistant`, `scanRadius`, `breakRadius`, `breakMaxBlocks`, `farmRadius`, `structureRadiusChunks`, `allowTeleport`, `allowBreakBlocks`, `announceStructures`.

## Texturas

Las texturas se generaron con `tools_gen_textures.py` (Pillow). Puedes reemplazar los PNG de `src/main/resources/assets/corazondemelon/textures/` por tu propio arte.
