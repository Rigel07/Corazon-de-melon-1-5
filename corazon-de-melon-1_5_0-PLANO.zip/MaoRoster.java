package com.corazondemelon.ai;

import com.corazondemelon.entity.MaoEntity;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * La «lista de Maos» de un jugador: el primero que domestica es el Mao REPRESENTANTE (se llama siempre «Mao»,
 * te sigue a todas partes y no se puede renombrar). Los demás reciben un nombre divertido (Pipo, Chispa, Tofu...) y se les
 * habla con barra: «/Pipo ven». Si dices «Mao, ven aquí» vienen todos; el resto de órdenes a «Mao» las atiende solo el representante.
 * Se guarda en los datos del jugador (la lista de UUID) y en cada Mao (su nombre).
 */
public final class MaoRoster {
    public static final String KEY_LIST = "corazondemelon_maos";
    public static final String KEY_REP = "corazondemelon_mao_rep";

    /** Mensaje dirigido a uno o a todos los Maos. */
    public record Target(List<MaoEntity> maos, String text, boolean all) {}

    private static final Pattern ALL = Pattern.compile("^@?(?:maos|todos(?:\\s+los\\s+maos)?)\\s*[\\s,:;!¡]+(.+)$",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern NUMBERED = Pattern.compile("^@?mao\\s*(\\d{1,2}|dos|tres|cuatro|cinco|seis)\\b\\s*[,:;!¡]*\\s*(.*)$",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Forma simple del comando: «/mao 2 vuelve», «/mao 3 ven». */
    private static final Pattern CMD_NUM = Pattern.compile("^(\\d{1,2}|uno|dos|tres|cuatro|cinco|seis)\\s+(.+)$",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern GENERIC = Pattern.compile("^@?mao[\\s,:;!¡]+(.+)$", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    private MaoRoster() {}

    private static ListTag list(ServerPlayer p) {
        return p.getPersistentData().getList(KEY_LIST, Tag.TAG_STRING);
    }

    public static String nameOf(MaoEntity m) {
        return m.getCustomName() != null ? m.getCustomName().getString() : "Mao";
    }

    /** Apunta un Mao recién domesticado (o descubierto) en la lista del jugador. */
    public static void register(ServerPlayer p, MaoEntity m) {
        ListTag l = list(p);
        String id = m.getUUID().toString();
        boolean known = false;
        for (int i = 0; i < l.size(); i++) {
            if (l.getString(i).equals(id)) {
                known = true;
                break;
            }
        }
        if (!known) {
            l.add(StringTag.valueOf(id));
            p.getPersistentData().put(KEY_LIST, l);
        }
        String rep = p.getPersistentData().getString(KEY_REP);
        if (rep.isEmpty()) {
            rep = id;
            p.getPersistentData().putString(KEY_REP, id);
        }
        if (rep.equals(id)) {
            m.makeRepresentative();
        } else {
            if (isDefaultName(m)) ensureName(m, owned(p, false));
            m.setCustomNameVisible(true);
        }
    }

    public static void forget(ServerPlayer p, MaoEntity m) {
        ListTag l = list(p);
        String id = m.getUUID().toString();
        ListTag out = new ListTag();
        for (int i = 0; i < l.size(); i++) if (!l.getString(i).equals(id)) out.add(StringTag.valueOf(l.getString(i)));
        p.getPersistentData().put(KEY_LIST, out);
        if (id.equals(p.getPersistentData().getString(KEY_REP))) p.getPersistentData().remove(KEY_REP);
    }

    /** Todos los Maos del jugador que estén cargados ahora mismo (en cualquier dimensión). */
    public static List<MaoEntity> owned(ServerPlayer p, boolean scanNearby) {
        LinkedHashMap<UUID, MaoEntity> out = new LinkedHashMap<>();
        ListTag l = list(p);
        for (int i = 0; i < l.size(); i++) {
            UUID id;
            try {
                id = UUID.fromString(l.getString(i));
            } catch (IllegalArgumentException e) {
                continue;
            }
            for (ServerLevel lv : p.server.getAllLevels()) {
                Entity e = lv.getEntity(id);
                if (e instanceof MaoEntity m && m.isAlive() && m.isOwnedByUuid(p)) {
                    out.put(id, m);
                    break;
                }
            }
        }
        if (scanNearby) {
            for (MaoEntity m : p.level().getEntitiesOfClass(MaoEntity.class, p.getBoundingBox().inflate(64),
                    x -> x.isAlive() && x.isOwnedByUuid(p))) {
                if (!out.containsKey(m.getUUID())) {
                    register(p, m);
                    out.put(m.getUUID(), m);
                }
            }
            if (out.isEmpty() && l.isEmpty()) {
                MaoEntity legacy = MaoEntity.scanOwned(p);
                if (legacy != null) {
                    register(p, legacy);
                    out.put(legacy.getUUID(), legacy);
                }
            }
        }
        for (MaoEntity m : new ArrayList<>(out.values())) {
            if (!m.isRepresentative() && isDefaultName(m)) {
                ensureName(m, out.values());
                m.setCustomNameVisible(true);
            }
        }
        return new ArrayList<>(out.values());
    }

    public static List<MaoEntity> owned(ServerPlayer p) {
        return owned(p, true);
    }

    // ------------------------------------------------------------------ nombres divertidos

    private static final String[] FUNNY = {"Pipo", "Chispa", "Bolita", "Tofu", "Fideo", "Nube", "Pelusa", "Cacahuete", "Mochi", "Croqueta",
            "Pompom", "Gominola", "Churro", "Bombón", "Tortilla", "Kiwi", "Canelo", "Miga", "Pixel", "Burbuja", "Cometa", "Garbanzo",
            "Patata", "Mermelada", "Bizcocho", "Calabacín", "Piruleta", "Fresita", "Albóndiga", "Turrón"};

    /** ¿Se llama «Mao», «Mao 2»... o no tiene nombre? Solo el representante debe llamarse así. */
    public static boolean isDefaultName(MaoEntity m) {
        if (m.getCustomName() == null) return true;
        return m.getCustomName().getString().trim().matches("(?i)mao(\\s*\\d+)?");
    }

    /** Le pone un nombre divertido que no use ningún otro de tus Maos. */
    public static void ensureName(MaoEntity m, Collection<MaoEntity> others) {
        Set<String> used = new HashSet<>();
        for (MaoEntity o : others) {
            if (o != m && !o.getUUID().equals(m.getUUID())) used.add(MaoPlaces.norm(nameOf(o)));
        }
        int start = Math.floorMod(m.getUUID().hashCode(), FUNNY.length);
        String pick = null;
        for (int i = 0; i < FUNNY.length && pick == null; i++) {
            String c = FUNNY[(start + i) % FUNNY.length];
            if (!used.contains(MaoPlaces.norm(c))) pick = c;
        }
        for (int k = 2; pick == null; k++) {
            String c = FUNNY[start] + " " + k;
            if (!used.contains(MaoPlaces.norm(c))) pick = c;
        }
        m.setCustomName(Component.literal(pick));
    }

    /** UUID de todos los Maos de la lista del jugador (estén cargados o no). */
    public static List<UUID> ids(ServerPlayer p) {
        List<UUID> out = new ArrayList<>();
        ListTag l = list(p);
        for (int i = 0; i < l.size(); i++) {
            try {
                out.add(UUID.fromString(l.getString(i)));
            } catch (IllegalArgumentException ignored) {
                // entrada rota: se ignora
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ «Mao, ven aquí» = vienen todos

    private static final Pattern RECALL1 = Pattern.compile("(?:ven|venid|vengan|venga|venir|acercate|acercaos|sigueme|seguidme|siguenos|siguenme|sigan|siganme"
            + "|a mi lado|juntaos|reunios|reuniros)(?: (?:aqui|aca|a mi|conmigo|a mi lado|ya|rapido|rapidito|todos|todas|por favor|porfa))*");
    private static final Pattern RECALL2 = Pattern.compile("(?:vuelve|volved|volver|vuelvan|vuelvete)(?: (?:aqui|aca|a mi|conmigo|a mi lado|ya|todos|todas))+");

    /** «ven», «ven aquí», «sígueme», «vuelve conmigo»...: una llamada para que se reúnan contigo. */
    public static boolean isRecall(String text) {
        String n = MaoPlaces.norm(text == null ? "" : text);
        return RECALL1.matcher(n).matches() || RECALL2.matcher(n).matches();
    }

    private static void hintNames(ServerPlayer p) {
        StringBuilder sb = new StringBuilder();
        for (MaoEntity m : owned(p, false)) {
            if (m.isRepresentative()) continue;
            if (sb.length() > 0) sb.append(", ");
            sb.append(nameOf(m));
        }
        MaoActions.say(p, "Ya no hay «Mao 2», «Mao 3»...: solo el representante se llama Mao. "
                + (sb.length() == 0 ? "Todavía no tienes más Maos." : "Los otros tienen nombre propio (" + sb + "): háblales con barra, por ejemplo «/"
                + sb.toString().split(", ")[0] + " ven». Y «Mao, ven aquí» llama a todos."));
    }

    /** «/Pipo ven aquí» (el mensaje sin la barra): habla con ese Mao por su nombre. null si no empieza por el nombre de ninguno. */
    public static Target resolveSlash(ServerPlayer p, String input) {
        if (input == null || input.isBlank()) return null;
        List<MaoEntity> maos = owned(p, false);
        if (maos.isEmpty()) return null;
        String ni = MaoPlaces.norm(input);
        List<MaoEntity> byLen = new ArrayList<>(maos);
        byLen.sort((a, b) -> nameOf(b).length() - nameOf(a).length());
        String[] words = input.trim().split("\\s+");
        for (MaoEntity m : byLen) {
            String nn = MaoPlaces.norm(nameOf(m));
            if (nn.isEmpty() || !(ni.equals(nn) || ni.startsWith(nn + " "))) continue;
            int n = nameOf(m).trim().split("\\s+").length;
            StringBuilder rest = new StringBuilder();
            for (int i = n; i < words.length; i++) rest.append(words[i]).append(' ');
            return new Target(List.of(m), rest.toString().trim(), false);
        }
        return null;
    }

    public static List<MaoEntity> followers(ServerPlayer p) {
        List<MaoEntity> out = new ArrayList<>();
        for (MaoEntity m : owned(p, false)) if (m.isFollowing()) out.add(m);
        return out;
    }

    /** El Mao representante si está cargado; si no, el más cercano. */
    public static MaoEntity primary(ServerPlayer p) {
        List<MaoEntity> all = owned(p);
        if (all.isEmpty()) return null;
        for (MaoEntity m : all) if (m.isRepresentative()) return m;
        return all.stream().min(Comparator.comparingDouble(m -> m.level() == p.level() ? m.distanceToSqr(p) : Double.MAX_VALUE)).orElse(null);
    }

    /** Busca un Mao del jugador por su nombre (ignora mayúsculas y tildes). */
    public static MaoEntity byName(ServerPlayer p, String name) {
        String key = MaoPlaces.norm(name);
        if (key.isEmpty()) return null;
        MaoEntity partial = null;
        for (MaoEntity m : owned(p)) {
            String n = MaoPlaces.norm(nameOf(m));
            if (n.equals(key)) return m;
            if (partial == null && (n.contains(key) || key.contains(n)) && !n.equals("mao")) partial = m;
        }
        return partial;
    }

    /** Si el mensaje empieza por el nombre de alguno de tus Maos («Mao 2, ven», «Luna: quédate», «Todos, venid»). */
    public static Target resolve(ServerPlayer p, String raw) {
        if (raw == null || raw.isBlank()) return null;
        String text = raw.trim();
        List<MaoEntity> maos = owned(p);
        if (maos.isEmpty()) return null;

        Matcher all = ALL.matcher(text);
        if (all.matches()) return new Target(maos, all.group(1).trim(), true);

        // «Mao 2, ven»: ya no se direcciona por número (confundía); se avisa de cómo hablarle a cada uno
        Matcher nm = NUMBERED.matcher(text);
        if (nm.matches() && !nm.group(2).isBlank()) {
            hintNames(p);
            return new Target(List.of(), "", false);
        }
        List<MaoEntity> byLen = new ArrayList<>(maos);
        byLen.sort((a, b) -> nameOf(b).length() - nameOf(a).length());
        for (MaoEntity m : byLen) {
            String name = nameOf(m);
            String q = Pattern.quote(name);
            Pattern pt;
            if (MaoPlaces.norm(name).startsWith("mao")) {
                pt = Pattern.compile("^@?" + q + "(?:\\s*[,:;!¡]+\\s*|\\s+)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
            } else {
                pt = Pattern.compile("^(?:@" + q + "(?:\\s*[,:;!¡]+\\s*|\\s+)|" + q + "\\s*[,:;]+\\s*)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
            }
            Matcher mt = pt.matcher(text);
            if (mt.find()) {
                String rest = text.substring(mt.end()).trim();
                if (!rest.isEmpty()) return new Target(List.of(m), rest, false);
            }
        }
        Matcher g = GENERIC.matcher(text);
        if (g.matches()) {
            String rest = g.group(1).trim();
            if (isRecall(rest)) return new Target(maos, rest, true);       // «Mao, ven aquí»: vienen todos
            MaoEntity near = primary(p);
            if (near != null) return new Target(List.of(near), rest, false);
        }
        return null;
    }

    /** Para /mao <mensaje>: igual que resolve, pero si no empieza por un nombre se lo dices al representante. */
    public static Target resolveOrDefault(ServerPlayer p, String raw) {
        String text = raw.trim();
        List<MaoEntity> maos = owned(p);
        if (maos.isEmpty()) return null;

        // /mao 2 vuelve: ya no se usan números
        Matcher cm = CMD_NUM.matcher(text);
        if (cm.matches()) {
            hintNames(p);
            return new Target(List.of(), "", false);
        }

        Target sl = resolveSlash(p, text);
        if (sl != null && !sl.text().isBlank()) return sl;

        Target t = resolve(p, text);
        if (t != null) return t;
        if (NUMBERED.matcher(text).matches()) return new Target(List.of(), "", false);   // «Mao 2 ...» ya avisó de que no lo encuentra

        // /mao Luna ven
        List<MaoEntity> byLen = new ArrayList<>(maos);
        byLen.sort((x, y) -> nameOf(y).length() - nameOf(x).length());
        for (MaoEntity m : byLen) {
            Matcher nmm = Pattern.compile("^" + Pattern.quote(nameOf(m)) + "\\s+(.+)$", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE).matcher(text);
            if (nmm.matches()) return new Target(List.of(m), nmm.group(1).trim(), false);
        }
        if (isRecall(text)) return new Target(maos, text, true);
        MaoEntity m = primary(p);
        return m == null ? null : new Target(List.of(m), text, false);
    }

    /** Cambia quién es el representante. */
    public static void setRepresentative(ServerPlayer p, MaoEntity mao) {
        List<MaoEntity> all = owned(p);
        for (MaoEntity o : all) {
            if (o != mao && o.isRepresentative()) {
                o.clearRepresentative();
                ensureName(o, all);
                o.setCustomNameVisible(true);
            }
        }
        p.getPersistentData().putString(KEY_REP, mao.getUUID().toString());
        mao.clearRepresentative();
        mao.makeRepresentative();
    }

    /** Se llama al domesticar un Mao. */
    public static void onTamed(MaoEntity mao, ServerPlayer player) {
        // primero apunta los Maos que ya tuvieras, para que el más antiguo sea el representante
        for (MaoEntity other : player.level().getEntitiesOfClass(MaoEntity.class, player.getBoundingBox().inflate(64),
                x -> x != mao && x.isAlive() && x.isOwnedByUuid(player))) {
            register(player, other);
        }
        register(player, mao);
        if (!mao.isRepresentative()) {
            player.displayClientMessage(Component.literal("¡Este se llama " + nameOf(mao) + "! Háblale con barra: «/" + nameOf(mao)
                    + " ven». Para cambiarle el nombre: «/" + nameOf(mao) + " llámate Luna». Solo el primer Mao se llama «Mao» (y «Mao, ven aquí» llama a todos)."), false);
        } else {
            player.displayClientMessage(Component.literal("Este es tu Mao representante: te seguirá a todas partes, siempre."), false);
        }
    }
}
