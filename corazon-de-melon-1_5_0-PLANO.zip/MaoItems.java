package com.corazondemelon.ai;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Entiende nombres de objetos en español («palos», «pala de hierro», «tablones de roble», «lingotes de oro»)
 * y los convierte en objetos del juego, sin necesitar la IA. También de otros mods si usan nombres en inglés
 * parecidos (se comparan las palabras del id: iron_shovel = iron + shovel).
 */
public final class MaoItems {
    public record Query(Set<Item> items, String label) {
        public boolean test(ItemStack s) {
            return items.contains(s.getItem());
        }
    }

    public record Amount(int n, boolean all, String rest) {}

    private static final Set<String> STOP = Set.of("de", "del", "la", "el", "los", "las", "un", "una", "unos", "unas", "mi", "mis",
            "tu", "tus", "algo", "cosas", "cosa", "por", "con", "y", "en", "que", "lo", "le", "hay", "al", "a", "me", "te");

    private static final Map<String, Integer> NUMBERS = new HashMap<>();
    private static final Map<String, String> DICT = new HashMap<>();
    private static final Map<String, String> EXACT = new HashMap<>();

    private static void n(int v, String... words) {
        for (String w : words) NUMBERS.put(w, v);
    }

    private static void d(String en, String... es) {
        for (String w : es) DICT.put(w, en);
    }

    static {
        n(1, "un", "una", "uno");
        n(2, "dos");
        n(3, "tres");
        n(4, "cuatro");
        n(5, "cinco");
        n(6, "seis");
        n(7, "siete");
        n(8, "ocho");
        n(9, "nueve");
        n(10, "diez");
        n(12, "doce");
        n(15, "quince");
        n(16, "dieciseis");
        n(20, "veinte");
        n(30, "treinta");
        n(32, "treintaydos");
        n(50, "cincuenta");
        n(64, "sesentaycuatro");
        n(100, "cien", "ciento");

        // materiales
        d("iron", "hierro", "hierros");
        d("gold", "oro", "dorado", "dorada", "dorados", "doradas");
        d("copper", "cobre");
        d("diamond", "diamante", "diamantes");
        d("emerald", "esmeralda", "esmeraldas");
        d("netherite", "netherita");
        d("stone", "piedra", "piedras");
        d("cobblestone", "adoquin", "adoquines", "cobblestone");
        d("log", "madera", "maderas", "tronco", "troncos", "leno", "lenos");
        d("planks", "tablon", "tablones", "tabla", "tablas");
        d("stick", "palo", "palos");
        d("coal", "carbon");
        d("lapis_lazuli", "lapislazuli", "lapis");
        d("redstone", "redstone");
        d("quartz", "cuarzo");
        d("obsidian", "obsidiana");
        d("sand", "arena");
        d("gravel", "grava");
        d("dirt", "tierra");
        d("clay", "arcilla");
        d("leather", "cuero");
        d("string", "hilo", "cuerda");
        d("feather", "pluma", "plumas");
        d("bone", "hueso", "huesos");
        d("gunpowder", "polvora");
        d("paper", "papel");
        d("book", "libro", "libros");
        d("slime", "slime");
        d("ball", "bola", "bolas");
        d("pearl", "perla", "perlas");
        d("ender", "ender");
        d("eye", "ojo", "ojos");
        d("blaze", "blaze");
        d("rod", "vara", "varas");
        d("glass", "cristal", "cristales", "vidrio");
        d("wool", "lana");
        d("carpet", "alfombra", "alfombras");
        d("brick", "ladrillo", "ladrillos");
        d("ingot", "lingote", "lingotes");
        d("nugget", "pepita", "pepitas");
        d("block", "bloque", "bloques");
        d("ore", "mineral", "minerales");
        d("raw", "crudo", "cruda", "crudos", "bruto");
        d("sugar", "azucar");
        d("egg", "huevo", "huevos");
        d("wheat", "trigo");
        d("seeds", "semilla", "semillas");
        d("apple", "manzana", "manzanas");
        d("carrot", "zanahoria", "zanahorias");
        d("potato", "patata", "patatas");
        d("bread", "pan");
        d("cake", "pastel", "tarta");
        d("cookie", "galleta", "galletas");
        d("pumpkin", "calabaza", "calabazas");
        d("melon", "melon", "sandia");
        d("milk", "leche");
        // herramientas y armaduras
        d("pickaxe", "pico", "picos");
        d("axe", "hacha", "hachas");
        d("shovel", "pala", "palas");
        d("hoe", "azada", "azadas");
        d("sword", "espada", "espadas");
        d("helmet", "casco", "cascos");
        d("chestplate", "peto", "petos", "pechera");
        d("leggings", "pantalones", "mallas");
        d("boots", "botas");
        d("shield", "escudo", "escudos");
        d("bow", "arco", "arcos");
        d("crossbow", "ballesta");
        d("arrow", "flecha", "flechas");
        d("trident", "tridente");
        d("shears", "tijeras");
        d("bucket", "cubo", "cubos");
        d("flint_and_steel", "mechero", "encendedor");
        d("fishing_rod", "cana");
        d("", "pescar", "pesca");
        d("compass", "brujula");
        d("clock", "reloj");
        d("map", "mapa");
        // bloques y utilidades
        d("table", "mesa");
        d("crafting", "crafteo", "fabricacion", "crafting");
        d("furnace", "horno", "hornos");
        d("chest", "cofre", "cofres");
        d("barrel", "barril", "barriles");
        d("torch", "antorcha", "antorchas");
        d("lantern", "linterna");
        d("bed", "cama", "camas");
        d("door", "puerta", "puertas");
        d("trapdoor", "trampilla");
        d("fence", "valla", "vallas");
        d("gate", "portillo");
        d("stairs", "escalera", "escaleras");
        d("ladder", "escalerilla");
        d("slab", "losa", "losas");
        d("wall", "muro");
        d("bookshelf", "estanteria");
        d("anvil", "yunque");
        d("hopper", "tolva", "embudo");
        d("rail", "carril", "carriles", "rail");
        d("minecart", "vagoneta");
        d("boat", "bote", "barco");
        d("piston", "piston");
        d("sticky", "pegajoso", "pegajosa");
        d("observer", "observador");
        d("repeater", "repetidor");
        d("comparator", "comparador");
        d("lever", "palanca");
        d("button", "boton");
        d("pressure_plate", "placa");
        d("", "presion");
        d("dispenser", "dispensador");
        d("dropper", "soltador");
        d("lamp", "lampara");
        d("bell", "campana");
        d("chain", "cadena");
        d("beacon", "faro");
        d("tnt", "tnt", "dinamita");
        // colores
        d("white", "blanco", "blanca");
        d("black", "negro", "negra");
        d("red", "rojo", "roja");
        d("blue", "azul");
        d("green", "verde");
        d("yellow", "amarillo", "amarilla");
        d("orange", "naranja");
        d("pink", "rosa");
        d("purple", "morado", "morada", "violeta");
        d("gray", "gris");
        d("brown", "marron");
        d("cyan", "cian");
        d("lime", "lima");
        d("light_blue", "celeste");
        // maderas
        d("oak", "roble");
        d("spruce", "abeto");
        d("birch", "abedul");
        d("jungle", "jungla");
        d("acacia", "acacia");
        d("dark", "oscuro", "oscura");
        d("mangrove", "manglar");
        d("cherry", "cerezo");
        d("bamboo", "bambu");
        d("crimson", "carmesi");
        d("warped", "distorsionado");

        // un solo material suelto -> su objeto más típico
        EXACT.put("hierro", "iron_ingot");
        EXACT.put("hierros", "iron_ingot");
        EXACT.put("oro", "gold_ingot");
        EXACT.put("cobre", "copper_ingot");
        EXACT.put("netherita", "netherite_ingot");
        EXACT.put("diamante", "diamond");
        EXACT.put("diamantes", "diamond");
        EXACT.put("esmeralda", "emerald");
        EXACT.put("esmeraldas", "emerald");
        EXACT.put("carbon", "coal");
        EXACT.put("cuarzo", "quartz");
        EXACT.put("lapis", "lapis_lazuli");
        EXACT.put("lapislazuli", "lapis_lazuli");
    }

    private MaoItems() {}

    private static List<String> tokens(String text) {
        List<String> t = new ArrayList<>(Arrays.asList(MaoPlaces.norm(text).split(" ")));
        t.removeIf(String::isEmpty);
        return t;
    }

    /** "3 palos" -> (3, false, "palos"); "todo el hierro" -> (0, true, "hierro"); "una pala de hierro" -> (1, false, "pala de hierro"). */
    public static Amount parseAmount(String text) {
        int amount = 0;
        boolean all = false;
        List<String> rest = new ArrayList<>();
        for (String w : tokens(text)) {
            if (w.matches("\\d{1,6}")) {
                if (amount == 0) amount = Integer.parseInt(w);
                continue;
            }
            if (Set.of("todo", "todos", "todas", "toda", "cuanto", "cuantos").contains(w)) {
                all = true;
                continue;
            }
            Integer v = NUMBERS.get(w);
            if (v != null && amount == 0 && rest.isEmpty()) {
                amount = v;
                continue;
            }
            rest.add(w);
        }
        return new Amount(amount, all, String.join(" ", rest));
    }

    private static String translate(String t) {
        String e = DICT.get(t);
        if (e != null) return e;
        if (t.endsWith("es") && DICT.containsKey(t.substring(0, t.length() - 2))) return DICT.get(t.substring(0, t.length() - 2));
        if (t.endsWith("s") && DICT.containsKey(t.substring(0, t.length() - 1))) return DICT.get(t.substring(0, t.length() - 1));
        return t;
    }

    private static boolean wordEq(String q, String w) {
        if (q.equals(w) || w.equals(q + "s") || q.equals(w + "s")) return true;
        return (q.equals("gold") && w.equals("golden")) || (q.equals("golden") && w.equals("gold"));
    }

    /** @return el objeto (o conjunto de objetos) que describe el texto, o null si no lo reconoce. */
    public static Query resolve(String phrase) {
        List<String> toks = new ArrayList<>();
        for (String w : tokens(phrase)) {
            if (STOP.contains(w) || w.matches("\\d+") || NUMBERS.containsKey(w)) continue;
            toks.add(w);
        }
        if (toks.isEmpty()) return null;

        if (toks.size() == 1 && EXACT.containsKey(toks.get(0))) {
            Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation("minecraft", EXACT.get(toks.get(0))));
            if (it != null) return new Query(Set.of(it), toks.get(0));
        }

        List<String> q = new ArrayList<>();
        for (String t : toks) {
            String en = translate(t);
            for (String part : en.split("_")) if (!part.isEmpty()) q.add(part);
        }
        if (q.isEmpty()) return null;

        int bestVanilla = Integer.MAX_VALUE;
        int bestOther = Integer.MAX_VALUE;
        Set<Item> vanilla = new HashSet<>();
        Set<Item> other = new HashSet<>();
        for (Item item : ForgeRegistries.ITEMS) {
            ResourceLocation id = ForgeRegistries.ITEMS.getKey(item);
            if (id == null) continue;
            String[] words = id.getPath().split("_");
            boolean ok = true;
            for (String qw : q) {
                boolean found = false;
                for (String w : words) {
                    if (wordEq(qw, w)) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    ok = false;
                    break;
                }
            }
            if (!ok) continue;
            int extra = words.length - q.size();
            if ("minecraft".equals(id.getNamespace())) {
                if (extra < bestVanilla) {
                    bestVanilla = extra;
                    vanilla.clear();
                }
                if (extra == bestVanilla) vanilla.add(item);
            } else {
                if (extra < bestOther) {
                    bestOther = extra;
                    other.clear();
                }
                if (extra == bestOther) other.add(item);
            }
        }
        Set<Item> result = !vanilla.isEmpty() ? vanilla : other;
        if (result.isEmpty() || result.size() > 400) return null;
        return new Query(result, String.join(" ", toks));
    }
}
