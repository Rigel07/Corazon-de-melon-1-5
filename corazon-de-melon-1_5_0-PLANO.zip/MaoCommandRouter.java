package com.corazondemelon.ai;

import com.corazondemelon.CorazonDeMelon;
import com.mojang.brigadier.ParseResults;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.CommandEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * «/Pipo ven aquí»: habla con uno de tus Maos escribiendo una barra y su nombre (el representante es «Mao»; los demás tienen
 * nombres divertidos). Solo actúa si lo que escribes NO es un comando real, así que nunca pisa a otros comandos.
 */
@Mod.EventBusSubscriber(modid = CorazonDeMelon.MOD_ID)
public final class MaoCommandRouter {
    private MaoCommandRouter() {}

    @SubscribeEvent
    public static void onCommand(CommandEvent event) {
        ParseResults<CommandSourceStack> pr = event.getParseResults();
        if (!(pr.getContext().getSource().getEntity() instanceof ServerPlayer p)) return;
        if (!pr.getContext().getNodes().isEmpty()) return;      // es un comando de verdad (o de otro mod): no se toca
        String input = pr.getReader().getString().trim();
        if (input.startsWith("/")) input = input.substring(1).trim();
        if (input.isEmpty()) return;
        MaoRoster.Target t = MaoRoster.resolveSlash(p, input);
        if (t == null || t.maos().isEmpty()) return;
        event.setCanceled(true);
        String name = MaoRoster.nameOf(t.maos().get(0));
        if (t.text().isBlank()) {
            p.sendSystemMessage(Component.literal("¿Qué le dices a " + name + "? Por ejemplo «/" + name + " ven».").withStyle(ChatFormatting.YELLOW));
            return;
        }
        p.sendSystemMessage(Component.literal("Tú → " + name + ": " + t.text()).withStyle(ChatFormatting.GRAY));
        MaoBrain.talk(p, t.maos().get(0), t.text());
    }
}
