package com.corazondemelon.client;

import com.corazondemelon.CorazonDeMelon;
import com.corazondemelon.entity.MaoEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class MaoRenderer extends MobRenderer<MaoEntity, MaoModel> {
    /** 0 = original, 1 = rosa, 2 = verde, 3 = azul, 4 = violeta */
    private static final ResourceLocation[] TEXTURES = {
            new ResourceLocation(CorazonDeMelon.MOD_ID, "textures/entity/mao.png"),
            new ResourceLocation(CorazonDeMelon.MOD_ID, "textures/entity/mao_rosa.png"),
            new ResourceLocation(CorazonDeMelon.MOD_ID, "textures/entity/mao_verde.png"),
            new ResourceLocation(CorazonDeMelon.MOD_ID, "textures/entity/mao_azul.png"),
            new ResourceLocation(CorazonDeMelon.MOD_ID, "textures/entity/mao_violeta.png")
    };

    public MaoRenderer(EntityRendererProvider.Context context) {
        super(context, new MaoModel(context.bakeLayer(MaoModel.LAYER)), 0.25F);
    }

    @Override
    public ResourceLocation getTextureLocation(MaoEntity entity) {
        int c = entity.getColor();
        return TEXTURES[c < 0 || c >= TEXTURES.length ? 0 : c];
    }
}
