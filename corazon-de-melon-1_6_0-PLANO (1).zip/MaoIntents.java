package com.corazondemelon.ai;

import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Entiende órdenes sencillas en español sin necesitar la IA ("Mao, quédate", "guarda este sitio como mi casa",
 * "teletranspórtame a casa", "dime los minerales cercanos", "cultiva"...). Así funcionan al instante y sin clave.
 * Si la IA está configurada, solo se usa para mensajes que empiezan como una orden; el resto va a la IA.
 */
public final class MaoIntents {
    public record Intent(String action, String param) {}

    private static final Set<String> FILLER = Set.of("por", "favor", "porfa", "porfavor", "oye", "mao", "ahora", "puedes",
            "podrias", "quiero", "que", "me", "necesito", "pues", "vale", "y", "hola", "ey");

    private static final Set<String> NOISE = Set.of("ese", "esa", "eso", "este", "esta", "esto", "esos", "esas", "estos", "estas",
            "el", "la", "los", "las", "un", "una", "unos", "unas", "todo", "todos", "todas", "me", "de", "del", "que", "hay",
            "cerca", "cercano", "cercanos", "cercana", "cercanas", "por", "aqui", "alli", "ahi", "favor", "bloque", "bloques",
            "al", "a", "en", "mira", "miro", "mirando", "estoy", "delante", "mas", "proximo", "proximos");

    private static final Pattern COMMAND_START = Pattern.compile("^(?:quedate|quieto|sientate|espera|esperame|sigueme|siguenos|"
            + "acompaname|ven|vamos|acercate|vuelve|guard\\w*|apunt\\w*|anot\\w*|marc\\w*|memoriz\\w*|recuerd\\w*|llev\\w*|"
            + "teletransport\\w*|teleport\\w*|tp|rompe|romper|rompeme|pica|picar|mina|minar|tala|talar|destruye|excava|extrae|"
            + "cultiv\\w*|cosech\\w*|siembr\\w*|sembr\\w*|busca|buscame|dime|muestrame|localiza|detecta|encuentra|borr\\w*|"
            + "elimin\\w*|olvid\\w*|cura\\w*|sana\\w*|lista|lugares|estructuras|minerales|"
            + "mods|mobs|criaturas|abraz\\w*|acarici\\w*|identific\\w*|analiz\\w*|inspeccion\\w*|"
            + "dame|damelo\\w*|entregame|entrega|devuelveme|sueltame|suelta|pasame|protege\\w*|proteger|vigila\\w*|patrulla\\w*|deambula\\w*|merodea\\w*|"
            + "custodia|defiende|defender|cuida|cuidar|ve|vete|sal|anda|coge\\w*|saca\\w*|toma|agarra|trae\\w*|recoge|recolecta|mete\\w*|deposita|almacena|"
            + "revisa\\w*|inventario|mochila|craft\\w*|fabrica\\w*|elabora\\w*|estado|ayuda|comandos|poderes|haz|hazme|crea|creame|construye|"
            + "explora\\w*|ponte|cambiate|pintate|maos|eres|seas|hazte|tu|"
            + "pon\\w*|coloca\\w*|ilumina\\w*|alumbra\\w*|cria|criar|crias|reproduce\\w*|esquila\\w*|trasquila\\w*|orde\\w+|cocina\\w*|"
            + "funde\\w*|fundir|hornea\\w*|bendice\\w*|bendicion\\w*|hora|clima|coordenadas|alimenta\\w*|puente|refugio|tengo|donde|tiempo|hambre|comer|"
            + "pesca\\w*|pescar|tala\\w*|talar|planta\\w*|siembra\\w*|abona\\w*|fertiliza\\w*|repara\\w*|arregla\\w*|restaura\\w*|chiste\\w*|cuentame|"
            + "baila\\w*|bailemos|dato\\w*|curiosidad\\w*|trivia|sacame|subeme|avisame|recuerdame|recordame|celebra\\w*|sabias)\\b");

    private static final Pattern SAVE = Pattern.compile(
            "\\b(?:guard\\w*|apunt\\w*|anot\\w*|marc\\w*|memoriz\\w*|record\\w*|recuerd\\w*)\\b.*?\\b(?:como|llamado|llamada|nombre|llama)\\b\\s*(?:de\\s+)?(.+)$");
    private static final Pattern GOTO = Pattern.compile(
            "\\b(?:llev\\w*|teletransport\\w*|teleport\\w*|tp)\\b\\s*(?:(?:a|al|hasta|hacia)\\s+)?(.+)$");
    private static final Pattern GOTO_SOFT = Pattern.compile(
            "\\b(?:vamos|vayamos|volvamos|volver|ir|iremos|regresemos|regresar)\\b\\s+(?:a|al|hasta)\\s+(.+)$");
    private static final Pattern WHERE = Pattern.compile("\\bdonde\\s+(?:esta|queda|tengo|guarde|estaba)\\s+(.+)$");
    private static final Pattern DELETE = Pattern.compile(
            "^(?:borr\\w*|elimin\\w*|olvid\\w*|quit\\w*)\\s+(?:el\\s+|la\\s+)?(?:lugar\\s+|sitio\\s+|punto\\s+)?(.+)$");
    private static final Pattern BREAK = Pattern.compile(
            "^(?:rompe|romper|rompes|rompeme|pica|picar|picas|mina|minar|minas|tala|talar|talas|destruye|destruir|excava|excavar|extrae|extraer)\\b\\s*(.*)$");
    private static final Pattern FARM = Pattern.compile(
            "^(?:cultiv\\w*|cosech\\w*|siembr\\w*|sembr\\w*)\\b|^(?:recolect\\w*|recog\\w*)\\b.*\\b(?:cultivos|cosecha|trigo|zanahorias|patatas|remolacha|huerto)\\b");

    private static final Pattern WHATIS = Pattern.compile("(?:^|\\s)(?:es|son)\\s+(?:esto|eso|ese|esa|este|esta|esos|estos)\\b"
            + "|\\bde\\s+que\\s+mod\\b|^(?:identific|analiz|inspeccion)\\w*\\s+(?:esto|eso|ese|esa|este|esta|lo|el|la)\\b");
    private static final Pattern HUG = Pattern.compile(
            "^(?:abraz\\w*|acarici\\w*)\\b\\s*(?:(?:a|al|con)\\s+)?(?:(?:la|las|el|los)\\s+)?(.*)$");
    private static final Set<String> MOD_WORDS = Set.of("instalados", "instalado", "tengo", "reconoces", "reconoce", "conoces",
            "conoce", "hay", "lista", "cuales", "ves", "detectas", "detecta", "sabes", "otros", "vemos", "usamos");
    private static final Set<String> MOB_WORDS = Set.of("mobs", "mob", "criaturas", "bichos", "amigos", "amiguitos",
            "animales", "seres", "entidades");
    private static final Set<String> NEAR_WORDS = Set.of("alrededor", "hay", "ves", "veo", "rededor", "aqui", "ahi", "vemos", "tenemos");

    private static final Set<String> ORE_GENERIC = Set.of("mineral", "minerales", "mena", "menas", "ore", "ores");
    private static final List<String> ORE_SPECIFIC = List.of("diamante", "hierro", "oro", "carbon", "cobre", "redstone",
            "lapislazuli", "lapis", "esmeralda", "cuarzo", "netherita", "escombros");
    private static final Set<String> STRUCT_WORDS = Set.of("estructura", "estructuras", "aldea", "aldeas", "templo", "templos",
            "mazmorra", "mazmorras", "fortaleza", "piramide", "puesto", "mansion", "monumento", "portal", "ciudad", "naufragio",
            "ruina", "ruinas", "bastion", "saqueadores", "igloo", "iglu", "cabana");

    private MaoIntents() {}

    /** Texto normalizado sin muletillas iniciales ("oye mao por favor ..."). */
    static String core(String message) {
        List<String> t = new ArrayList<>(Arrays.asList(MaoPlaces.norm(message).split(" ")));
        t.removeIf(String::isEmpty);
        while (!t.isEmpty() && FILLER.contains(t.get(0))) t.remove(0);
        return String.join(" ", t);
    }

    public static boolean looksLikeCommand(String message) {
        return COMMAND_START.matcher(core(message)).find();
    }

    private static String cleanParam(String raw) {
        List<String> t = new ArrayList<>(Arrays.asList(MaoPlaces.norm(raw).split(" ")));
        t.removeIf(w -> w.isEmpty() || NOISE.contains(w));
        return String.join(" ", t);
    }

    private static boolean hasAny(List<String> tokens, Set<String> words) {
        for (String w : tokens) if (words.contains(w)) return true;
        return false;
    }


    // ------------------------------------------------------------------ 1.4.0

    private static final Set<String> CHEST_WORDS = Set.of("cofre", "cofres", "barril", "barriles", "baul", "baules", "ender");
    private static final String CHEST_RE = "(?:cofres?|barriles?|baul(?:es)?|ender)";
    private static final Pattern COMBO = Pattern.compile("^(?:coge\\w*|saca\\w*|toma|agarra|trae\\w*)\\s+(.+?)\\s+(?:del|de\\s+los|de\\s+mis|de\\s+el|de\\s+la|de)\\s+"
            + CHEST_RE + "\\s*(?:y)?\\s*(?:luego\\s+|despues\\s+)?(?:craftea\\w*|crafte\\w*|fabrica\\w*|elabora\\w*|haz|hazme|crea|creame)\\s+(.+)$");
    private static final Pattern CHEST_TAKE = Pattern.compile("^(?:coge\\w*|saca\\w*|toma|agarra|trae\\w*|recoge|pasame)\\s+(.+?)\\s+(?:del|de\\s+los|de\\s+mis|de\\s+el|de\\s+la|de\\s+tus|de\\s+tu|de)\\s+"
            + CHEST_RE + "\\b.*$");
    private static final Pattern CHEST_PUT = Pattern.compile("^(?:mete\\w*|guarda\\w*|deja|deposita|pon|coloca|almacena)\\s+(.+?)\\s+(?:en|dentro\\s+de|al|a)\\s+(?:(?:el|los|mis|tus|tu|un)\\s+)?"
            + CHEST_RE + "\\b.*$");
    private static final Pattern CHEST_FIND = Pattern.compile("^(?:busca\\w*|cuant\\w+|hay)\\s+(.+?)\\s+(?:hay\\s+)?(?:en|de|dentro\\s+de)\\s+(?:(?:el|los|mis|tus|tu)\\s+)?" + CHEST_RE + "\\b.*$");
    private static final Set<String> CHEST_LOOK_WORDS = Set.of("revisa", "revisame", "revisar", "mira", "mirame", "abre", "inspecciona", "registra", "que",
            "cuantos", "cuantas", "cuanto", "hay", "busca", "buscame", "dime", "lista", "muestrame", "contenido");
    private static final Pattern INV_Q = Pattern.compile("^(?:que|cuanto|cuantos|cuantas)\\s+(.*?)\\s*(?:tienes|llevas|guardas|has\\s+(?:recogido|conseguido|picado|minado|encontrado)|encontraste|recogiste|tienes\\s+ya)\\b.*$");
    private static final Pattern GIVE = Pattern.compile("^(?:dame|damelo\\w*|entregame|entrega|devuelveme|sueltame|suelta|pasame|traeme)\\b\\s*(.*)$");
    private static final Pattern CRAFT_STRONG = Pattern.compile("^(?:craftea\\w*|crafte\\w*|fabrica\\w*|elabora\\w*)\\s+(.+)$");
    private static final Pattern CRAFT_WEAK = Pattern.compile("^(?:haz|hazme|crea|creame|construye)\\s+(.+)$");
    private static final Pattern GUARD = Pattern.compile("^(?:protege\\w*|proteger|vigila\\w*|patrulla\\w*|deambula\\w*|merodea\\w*|custodia|defiende|defender|cuida|cuidar|monta\\s+guardia)\\b\\s*(.*)$");
    private static final Pattern JOB_MINE_GO = Pattern.compile("^(?:ve|vete|sal|anda)\\s+a\\s+(?:minar|picar|excavar|cavar|extraer)\\s+(.*)$");
    private static final Pattern JOB_MINE_SOLO = Pattern.compile("^(?:mina|minar|pica|picar|excava|excavar|cava|cavar|extrae)\\s+(.*)$");
    private static final Pattern JOB_SEARCH_GO = Pattern.compile("^(?:ve|vete|sal|anda)\\s+a\\s+(?:buscar|encontrar|conseguir|recoger|recolectar|explorar|traer)\\s+(?:y\\s+(?:busca|recoge|trae)\\s+)?(.*)$");
    private static final Pattern JOB_SEARCH_EXPLORE = Pattern.compile("^(?:explora\\w*|deambula\\w*|merodea\\w*|patrulla\\w*)\\s+(?:y\\s+|buscando\\s+)?(?:busca\\w*|recoge|encuentra|consigue)?\\s*(.*)$");
    private static final Pattern JOB_SEARCH_FREE = Pattern.compile("^(?:busca\\w*|encuentra|consigue|recoge|recolecta)\\s+(.*?)\\s*(?:por\\s+el\\s+mundo|por\\s+ahi(?:\\s+fuera)?|por\\s+las\\s+zonas.*|explorando|por\\s+tu\\s+cuenta)$");
    private static final String SELF_WORDS = "\\b(?:por\\s+tu\\s+cuenta|solito|solita|lentamente|despacio|tranquilamente)\\b";
    private static final Set<String> SOLO_WORDS = Set.of("solito", "solita", "lentamente", "despacio", "tranquilamente");

    private static String chestSuffix(String core) {
        String s = "";
        if (core.contains("ender")) s += " ender";
        if (core.contains("miro") || core.contains("mirando") || core.contains("este cofre") || core.contains("ese cofre")) s += " miro";
        // qué cofre de una pared o fila: arriba / abajo / derecha / izquierda / delante / detrás / el segundo...
        if (core.matches(".*\\b(?:arriba|superior|mas\\s+alto|encima)\\b.*")) s += " @arriba";
        if (core.matches(".*\\b(?:abajo|inferior|mas\\s+bajo|debajo)\\b.*")) s += " @abajo";
        if (core.matches(".*\\b(?:derecha|derecho)\\b.*")) s += " @derecha";
        if (core.matches(".*\\b(?:izquierda|izquierdo)\\b.*")) s += " @izquierda";
        if (core.matches(".*\\b(?:enfrente|delante|frente)\\b.*")) s += " @frente";
        if (core.matches(".*\\b(?:detras|atras|espalda)\\b.*")) s += " @atras";
        Matcher om = Pattern.compile("\\b(primer[oa]?|segund[oa]|tercer[oa]?|cuart[oa]|quint[oa])\\b").matcher(core);
        if (om.find()) {
            String w = om.group(1);
            s += " @n" + (w.startsWith("primer") ? 1 : w.startsWith("segund") ? 2 : w.startsWith("tercer") ? 3 : w.startsWith("cuart") ? 4 : 5);
        }
        return s;
    }

    private static String stripSolo(String s) {
        return s.replaceAll(SELF_WORDS, " ").replaceAll("\\s+", " ").trim();
    }

    private static Intent parseExtra(String core, List<String> tokens, ServerPlayer player) {
        Matcher m;
        String first = tokens.get(0);

        // cambiar el representante
        if (core.contains("representante") && hasAny(tokens, Set.of("eres", "seas", "sera", "se", "hazte", "ponte", "nuevo"))) return new Intent("REPRESENTANTE", null);

        // ayuda / estado / lista de Maos
        if (first.equals("ayuda") || first.equals("comandos") || core.matches("^(?:que|como)\\s+(?:puedes|sabes|se)\\s+.*(?:hacer|usar).*")) return new Intent("AYUDA", null);
        if (Set.of("estado", "poderes", "nivel", "stats").contains(first) || core.matches("^como\\s+estas\\s+de\\s+nivel.*")) return new Intent("ESTADO", null);
        if (tokens.contains("maos") && hasAny(tokens, Set.of("lista", "mis", "cuantos", "donde", "cuales", "tengo", "estan"))) return new Intent("MAOS", null);

        // color
        boolean colorTrigger = hasAny(tokens, Set.of("color", "ponte", "cambiate", "pintate", "tinete", "vistete", "seas", "vuelve", "pasate"));
        if (colorTrigger) {
            if (core.contains("color original") || core.contains("a tu color") || core.contains("color de siempre")) return new Intent("COLOR", "original");
            String key = MaoWork.colorKey(core);
            if (key != null) return new Intent("COLOR", key);
        }

        // coger del cofre y craftear
        m = COMBO.matcher(core);
        if (m.find()) return new Intent("COGER_CRAFT", m.group(1).trim() + chestSuffix(core) + "|" + m.group(2).trim());

        boolean chest = hasAny(tokens, CHEST_WORDS);
        if (chest) {
            m = CHEST_TAKE.matcher(core);
            if (m.find()) return new Intent("COGER_COFRE", m.group(1).trim() + chestSuffix(core));
            m = CHEST_PUT.matcher(core);
            if (m.find()) return new Intent("METER_COFRE", m.group(1).trim() + chestSuffix(core));
            m = CHEST_FIND.matcher(core);
            if (m.find()) return new Intent("COFRES", m.group(1).replaceAll("\\bhay\\b", " ").trim() + chestSuffix(core));
            if (hasAny(tokens, CHEST_LOOK_WORDS)) return new Intent("COFRES", chestSuffix(core).trim().isEmpty() ? null : chestSuffix(core).trim());
        }

        // inventario del Mao
        if (first.equals("inventario") || first.equals("mochila")
                || (core.contains("tu inventario") || core.contains("tu mochila")) && hasAny(tokens, Set.of("muestrame", "ensename", "dime", "abre", "revisa", "mira"))) {
            return new Intent("INVENTARIO", null);
        }
        m = INV_Q.matcher(core);
        if (m.find()) {
            String g = m.group(1).trim();
            if (g.isEmpty() || Set.of("cosas", "objetos", "items", "cosa", "cosas ya").contains(g)) return new Intent("INVENTARIO", null);
            return new Intent("INVENTARIO", g);
        }

        // entregar lo que lleva
        m = GIVE.matcher(core);
        if (m.find()) {
            String rest = m.group(1).replaceAll("\\blo\\s+que\\s+(?:tengas|llevas|tienes|has\\s+\\w+)\\b", "todo").trim();
            if (rest.startsWith("vida") || rest.startsWith("salud") || rest.startsWith("un abrazo")) {
                // «dame vida» es curar: lo trata el final del método parse
            } else if (rest.isEmpty() || rest.contains("todo") && MaoItems.parseAmount(rest).rest().isEmpty()) {
                return new Intent("ENTREGAR", "todo");
            } else if (MaoItems.resolve(MaoItems.parseAmount(rest).rest()) != null) {
                return new Intent("ENTREGAR", rest);
            }
        }

        // craftear
        m = CRAFT_STRONG.matcher(core);
        if (m.find()) return new Intent("CRAFTEAR", m.group(1).trim());
        m = CRAFT_WEAK.matcher(core);
        if (m.find()) {
            String rest = m.group(1).trim();
            if (MaoItems.resolve(MaoItems.parseAmount(rest.replaceAll("\\b" + CHEST_RE + "\\b", " ")).rest()) != null) return new Intent("CRAFTEAR", rest);
        }

        // trabajos por su cuenta: picar y explorar
        m = JOB_MINE_GO.matcher(core);
        if (m.find() && !stripSolo(m.group(1)).isEmpty()) return new Intent("MINAR", stripSolo(m.group(1)));
        boolean solo = core.contains("por tu cuenta") || hasAny(tokens, SOLO_WORDS);
        if (solo) {
            m = JOB_MINE_SOLO.matcher(core);
            if (m.find() && !stripSolo(m.group(1)).isEmpty()) return new Intent("MINAR", stripSolo(m.group(1)));
        }
        m = JOB_SEARCH_GO.matcher(core);
        if (m.find() && !stripSolo(m.group(1)).isEmpty()) return new Intent("EXPLORAR", stripSolo(m.group(1)));
        m = JOB_SEARCH_FREE.matcher(core);
        if (m.find() && !stripSolo(m.group(1)).isEmpty()) return new Intent("EXPLORAR", stripSolo(m.group(1)));
        if (core.matches("^(?:explora\\w*|deambula\\w*|merodea\\w*|patrulla\\w*)\\s+.*(?:busca\\w*|recoge|encuentra|consigue).*")) {
            m = JOB_SEARCH_EXPLORE.matcher(core);
            if (m.find() && !stripSolo(m.group(1)).isEmpty()) return new Intent("EXPLORAR", stripSolo(m.group(1)));
        }

        // proteger una zona
        m = GUARD.matcher(core);
        if (m.find()) {
            String rest = m.group(1).trim();
            String radius = "";
            Matcher d = Pattern.compile("\\b(\\d{1,3})\\b").matcher(rest);
            if (d.find()) radius = d.group(1);
            boolean here = rest.isEmpty() || rest.matches(".*\\b(?:aqui|ahi|esta|este|alrededor)\\b.*") && !rest.matches(".*\\b(?:casa|base|mina|granja)\\b.*");
            String place = "";
            if (!here) {
                List<String> keep = new ArrayList<>();
                for (String w : rest.split(" ")) {
                    if (w.isEmpty() || w.matches("\\d+") || Set.of("zona", "area", "sitio", "lugar", "por", "favor", "bloques", "bloque", "radio", "de", "del",
                            "la", "el", "los", "las", "alrededor", "en", "a", "al", "ahi", "aqui", "esta", "este", "con").contains(w)) continue;
                    keep.add(w);
                }
                place = MaoPlaces.cleanName(String.join(" ", keep));
            }
            return new Intent("GUARDIA", place + "|" + radius);
        }
        return null;
    }

    // ------------------------------------------------------------------ 1.5.0

    private static final Set<String> GROUND_WORDS = Set.of("objetos", "objeto", "items", "item", "loot", "botin", "drops", "cosas",
            "tirado", "tirados", "tiradas", "caido", "caidos");

    /** Habilidades de la 1.5.0: recoger, antorchas, criar, esquilar, ordeñar, comer, puente, refugio, cocinar, bendición, info, cama y muerte. */
    private static Intent parseSkills(String core, List<String> tokens) {
        boolean chest = hasAny(tokens, CHEST_WORDS);

        if (!chest && core.matches("^(?:recoge\\w*|recolecta\\w*|junta|agarra|coge\\w*|aspira)\\b.*")
                && (core.contains("suelo") || hasAny(tokens, GROUND_WORDS))) {
            return new Intent("RECOGER", null);
        }
        if (core.matches("^(?:ilumina\\w*|alumbra\\w*)\\b.*")
                || (!chest && core.matches("^(?:pon\\w*|coloca\\w*|planta|deja|usa)\\b.*") && core.contains("antorcha"))) {
            Matcher d = Pattern.compile("\\b(\\d{1,2})\\b").matcher(core);
            return new Intent("ANTORCHAS", d.find() ? d.group(1) : null);
        }
        if (core.matches("^(?:cria|criar|criame|crias|crien|reproduce\\w*|aparea\\w*|empareja\\w*)\\b.*")
                || core.matches("^(?:alimenta\\w*|da\\s+de\\s+comer\\s+a)\\s+(?:a\\s+)?(?:los\\s+|las\\s+|mis\\s+)?"
                + "(?:animales|vacas?|ovejas?|cerdos?|gallinas?|conejos?|pollos?)\\b.*")) {
            return new Intent("CRIAR", core);
        }
        if (core.matches("^(?:esquila\\w*|trasquila\\w*)\\b.*")) return new Intent("ESQUILAR", null);
        if ((core.matches("^orde[nñ]\\w*\\b.*") && hasAny(tokens, Set.of("vaca", "vacas", "leche")))
                || core.matches("^(?:consigue|dame|saca|trae\\w*)\\b.*\\bleche\\b.*")) {
            return new Intent("ORDENAR", null);
        }
        if (core.matches("^(?:tengo\\s+hambre|hambre|alimentame|nutreme|comer|(?:dame|pasame|traeme|das)\\s+(?:algo\\s+)?(?:de\\s+)?(?:comer|comida))\\b.*")) {
            return new Intent("COMER", null);
        }
        if ((core.contains("puente") || core.contains("pasarela"))
                && core.matches("^(?:haz\\w*|crea\\w*|construye\\w*|pon\\w*|coloca\\w*|tiende|monta|un|una|el|puente)\\b.*")) {
            Matcher d = Pattern.compile("\\b(\\d{1,2})\\b").matcher(core);
            return new Intent("PUENTE", d.find() ? d.group(1) : null);
        }
        if ((core.contains("refugio") || core.contains("casita") || core.contains("cobijo"))
                && core.matches("^(?:haz\\w*|crea\\w*|construye\\w*|monta|levanta|un|una|necesito|refugio|casita|pon\\w*)\\b.*")) {
            return new Intent("REFUGIO", null);
        }
        if (core.matches("^(?:cocina\\w*|funde\\w*|fundir|hornea\\w*|asa|asar|tuesta)\\b.*")) {
            return new Intent("COCINAR", core.replaceFirst("^\\S+\\s*", "").trim());
        }
        if (core.matches("^(?:bendice\\w*|bendicion\\w*|(?:dame|dame\\s+una|dame\\s+tu)\\s+(?:bendicion|poderes|poder|fuerza|velocidad|suerte))\\b.*")) {
            return new Intent("BENDICION", null);
        }
        if (core.matches("^(?:que\\s+)?(?:hora|clima|coordenadas)\\b.*") || core.matches("^(?:que\\s+)?tiempo\\s+hace\\b.*")
                || core.matches("^(?:va\\s+a\\s+llover|esta\\s+lloviendo|donde\\s+estoy|mis\\s+coordenadas|en\\s+que\\s+(?:bioma|dimension)\\s+estoy"
                + "|(?:que|cual)\\s+(?:bioma|dia)\\b).*")) {
            return new Intent("INFO", null);
        }
        if (core.matches("^(?:llev\\w*|teletransport\\w*|teleport\\w*|tp|vamos|volver|vuelve|regresa\\w*)\\b.*\\b(?:cama|reaparicion|respawn|spawn)\\b.*")) {
            return new Intent("CAMA", null);
        }
        if (hasAny(tokens, Set.of("mori", "muerte", "tumba"))) {
            boolean go = core.matches("^(?:llev\\w*|teletransport\\w*|teleport\\w*|tp|vamos|volver|vuelve|ir|regresa\\w*)\\b.*");
            if (go || core.startsWith("donde")) return new Intent("MUERTE", go ? "ir" : "info");
        }
        return null;
    }

    // ------------------------------------------------------------------ 1.6.0

    private static int wordNum(String w) {
        return switch (w) {
            case "un", "una" -> 1;
            case "dos" -> 2;
            case "tres" -> 3;
            case "cuatro" -> 4;
            case "cinco" -> 5;
            case "seis" -> 6;
            case "siete" -> 7;
            case "ocho" -> 8;
            case "nueve" -> 9;
            case "diez" -> 10;
            case "quince" -> 15;
            case "veinte" -> 20;
            case "treinta" -> 30;
            case "cuarenta" -> 40;
            case "sesenta" -> 60;
            default -> w.matches("\\d+") ? Math.min(Integer.parseInt(w), 9999) : 0;
        };
    }

    /** Habilidades de la 1.6.0: pescar, talar, plantar, abonar, reparar, ordenar mochila, mascotas, chistes, datos, baile, superficie y recordatorios. */
    private static Intent parseSkillsPlus(String core, List<String> tokens) {
        Matcher d = Pattern.compile("\\b(\\d{1,2})\\b").matcher(core);
        String num = d.find() ? d.group(1) : null;

        if (core.matches("^(?:(?:ve|vamos|ponte|vete)\\s+a\\s+)?(?:pesca\\w*|pescar)\\b.*")) return new Intent("PESCAR", num);
        if (core.matches("^(?:tala\\w*|talar|(?:corta|cortame|derriba|derribame)\\w*\\s+(?:el\\s+|ese\\s+|este\\s+|los\\s+|esos\\s+|todos\\s+los\\s+|todo\\s+el\\s+)?(?:arbol\\w*|bosque)).*")) {
            return new Intent("TALAR", core);
        }
        if (core.matches("^(?:planta\\w*|siembra\\w*|reforesta\\w*|replanta\\w*)\\b.*")
                && (core.contains("arbol") || core.contains("brote") || core.contains("sapling") || core.contains("bosque") || core.contains("retono"))) {
            return new Intent("PLANTAR", num);
        }
        if (core.matches("^(?:abona\\w*|fertiliza\\w*)\\b.*") || core.matches("^(?:usa|echa|echale|pon|ponle|aplica)\\w*\\b.*harina\\s+de\\s+hueso.*")) {
            return new Intent("ABONAR", null);
        }
        if (core.matches("^(?:cura\\w*|sana\\w*|restaura\\w*|alimenta\\w*)\\b.*\\b(?:mascotas?|lobos?|perros?|gatos?|caballos?|loros?|domesticad\\w+)\\b.*")) {
            return new Intent("CURAR_MASCOTAS", null);
        }
        if (core.matches("^(?:repara\\w*|arregla\\w*|restaura\\w*)\\b.*")
                && hasAny(tokens, Set.of("herramienta", "herramientas", "armadura", "equipo", "pico", "espada", "hacha", "pala", "casco", "peto", "botas",
                "mochila", "todo", "cosas", "mi", "mis"))) {
            return new Intent("REPARAR", null);
        }
        if (core.matches("^(?:ordena\\w*|organiza\\w*|clasifica\\w*)\\b.*\\b(?:mochila|inventario|bolsillos)\\b.*")
                && !core.contains("tu inventario") && !core.contains("tu mochila")) {
            return new Intent("ORDENAR_MOCHILA", null);
        }
        if (hasAny(tokens, Set.of("chiste", "chistes", "chascarrillo")) || core.matches("^hazme\\s+reir.*")
                || core.matches("^(?:cuentame|dime|cuenta)\\s+(?:una\\s+)?broma.*")) {
            return new Intent("CHISTE", null);
        }
        if (hasAny(tokens, Set.of("dato", "datos", "curiosidad", "curiosidades", "trivia")) || core.startsWith("sabias que")) {
            return new Intent("DATO", null);
        }
        if (core.matches("^(?:baila\\w*|bailemos|haz\\s+(?:un\\s+)?baile|celebra\\w*|festeja\\w*)\\b.*")) return new Intent("BAILAR", null);
        if ((core.matches("^(?:sacame|subeme)\\b.*") && !hasAny(tokens, CHEST_WORDS)
                && (tokens.size() <= 2 || core.matches(".*\\b(?:aqui|aca|cueva|cuevas|mina|agujero|hoyo|abajo|fondo|superficie|afuera)\\b.*")))
                || core.matches("^(?:llevame|sube)\\b.*\\b(?:superficie|cueva|cuevas|afuera)\\b.*")
                || hasAny(tokens, Set.of("atrapado", "atascado", "atrapada", "atascada"))) {
            return new Intent("SUPERFICIE", null);
        }
        if (core.matches("^(?:avisame|recuerdame|recordame|ponme\\s+(?:un\\s+|una\\s+)?(?:temporizador|recordatorio|alarma))\\b.*")) {
            Matcher tm = Pattern.compile("\\ben\\s+(\\d+|un|una|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|quince|veinte|treinta|cuarenta|sesenta)\\s+(segundos?|minutos?|horas?)\\b").matcher(core);
            if (tm.find()) {
                long n = wordNum(tm.group(1));
                String unit = tm.group(2);
                long sec = n * (unit.startsWith("seg") ? 1L : unit.startsWith("min") ? 60L : 3600L);
                String rest = (core.substring(0, tm.start()) + " " + core.substring(tm.end())).trim();
                rest = rest.replaceFirst("^(?:avisame|recuerdame|recordame|ponme\\s+\\w+(?:\\s+\\w+)?)\\s*", "").replaceFirst("^(?:de|que|para|sobre)\\s+", "").trim();
                return new Intent("RECORDATORIO", sec + "|" + rest);
            }
            return new Intent("RECORDATORIO", "0|");
        }
        return null;
    }

    /** @return la acción detectada o null si no es una orden que entienda. */
    public static Intent parse(String message, ServerPlayer player) {
        String core = core(message);
        if (core.isEmpty()) return null;
        List<String> tokens = Arrays.asList(core.split(" "));
        Matcher m;

        // --- "qué es esto" va primero: puede contener palabras como "llevo" que se confundirían con "llévame" ---
        if (WHATIS.matcher(core).find()) {
            return new Intent("QUE_ES", core.contains("mano") || core.contains("llevo") ? "mano" : null);
        }

        // --- habilidades de la 1.5.0 (antes que lo demás, para que "pon antorchas" no se confunda con otras órdenes) ---
        Intent skill = parseSkills(core, tokens);
        if (skill == null) skill = parseSkillsPlus(core, tokens);
        if (skill != null) return skill;

        // --- lo nuevo: colores, inventario, cofres, crafteo, zonas, trabajos y estado ---
        Intent extra = parseExtra(core, tokens, player);
        if (extra != null) return extra;

        // --- lugares ---
        m = SAVE.matcher(core);
        if (m.find()) {
            String name = MaoPlaces.cleanName(m.group(1));
            if (!name.isEmpty()) return new Intent("GUARDAR", name);
        }
        m = GOTO.matcher(core);
        if (m.find()) {
            String name = MaoPlaces.cleanName(m.group(1));
            if (!name.isEmpty()) return new Intent("IR", name);
        }
        m = GOTO_SOFT.matcher(core);
        if (m.find()) {
            String name = MaoPlaces.cleanName(m.group(1));
            if (!name.isEmpty() && MaoPlaces.get(player, name) != null) return new Intent("IR", name);
        }
        if ((tokens.contains("lugares") || tokens.contains("sitios"))
                && (tokens.contains("guardados") || tokens.contains("guardado") || tokens.contains("tengo") || tokens.contains("cuales")
                || tokens.contains("lista") || tokens.contains("dime") || tokens.contains("muestrame") || tokens.contains("mis"))) {
            return new Intent("LUGARES", null);
        }
        m = WHERE.matcher(core);
        if (m.find()) {
            String name = MaoPlaces.cleanName(m.group(1));
            if (!name.isEmpty() && MaoPlaces.get(player, name) != null) return new Intent("LUGARES", name);
        }
        m = DELETE.matcher(core);
        if (m.find()) {
            String name = MaoPlaces.cleanName(m.group(1));
            if (!name.isEmpty()) return new Intent("BORRAR_LUGAR", name);
        }

        // --- otros mods y criaturas ---
        if ((tokens.contains("mods") || tokens.contains("mod")) && hasAny(tokens, MOD_WORDS)) return new Intent("MODS", null);
        m = HUG.matcher(core);
        if (m.find()) {
            String who = cleanParam(m.group(1));
            return new Intent("ABRAZAR", who.isEmpty() ? null : who);
        }
        if (hasAny(tokens, MOB_WORDS) && (hasAny(tokens, NEAR_WORDS) || tokens.stream().anyMatch(w -> w.startsWith("cerc")))) {
            return new Intent("MOBS", null);
        }

        // --- romper bloques ---
        m = BREAK.matcher(core);
        if (m.find() && !m.group(1).startsWith("abandonad")) {
            String p = cleanParam(m.group(1));
            return new Intent("ROMPER", p.isEmpty() ? null : p);
        }

        // --- cultivar ---
        if (FARM.matcher(core).find()) return new Intent("CULTIVAR", null);

        // --- estructuras / minerales ---
        if (hasAny(tokens, STRUCT_WORDS)) return new Intent("ESTRUCTURAS", null);
        boolean generic = hasAny(tokens, ORE_GENERIC);
        String specific = null;
        for (String w : tokens) {
            for (String ore : ORE_SPECIFIC) {
                if (w.startsWith(ore)) {
                    specific = ore;
                    break;
                }
            }
            if (specific != null) break;
        }
        if (generic || specific != null) return new Intent("MINERALES", specific);

        // --- movimiento ---
        if (hasAny(tokens, Set.of("quedate", "quieto", "quieta", "sientate", "espera", "esperame", "parate", "aguanta"))
                || core.contains("no te muevas")) {
            return new Intent("SENTAR", null);
        }
        String first = tokens.get(0);
        if (Set.of("ven", "venga", "acercate", "vuelve").contains(first)) return new Intent("VENIR", null);
        if (hasAny(tokens, Set.of("sigueme", "siguenos", "acompaname", "vamos", "sigue", "conmigo"))) return new Intent("SEGUIR", null);
        if (first.startsWith("cura") || first.startsWith("sana") || core.contains("dame vida") || core.contains("estoy herido")) {
            return new Intent("CURAR", null);
        }
        return null;
    }
}
