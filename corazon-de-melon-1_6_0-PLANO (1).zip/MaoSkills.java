package com.corazondemelon.ai;

import com.corazondemelon.MelonConfig;
import com.corazondemelon.entity.MaoEntity;
import com.corazondemelon.entity.MaoInventory;
import com.corazondemelon.innocence.Innocence;
import com.corazondemelon.item.HeartItem;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.Tags;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;

/**
 * Habilidades nuevas de los Maos (1.5.0): recoger objetos, poner antorchas, criar, esquilar, ordeñar,
 * dar de comer, tender puentes, hacer refugios, cocinar y fundir, bendiciones, información del mundo,
 * viajar a la cama o al sitio donde moriste, y avisos automáticos de peligro.
 */
public final class MaoSkills {
    private static final Map<String, Long> NEXT = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> BLESS = new ConcurrentHashMap<>();

    private MaoSkills() {}

    // ------------------------------------------------------------------ despachador

    public static void run(ServerPlayer p, MaoEntity mao, String action, String param, boolean announce) {
        if (action == null) return;
        switch (action) {
            case "RECOGER" -> pickUp(p, mao);
            case "ANTORCHAS" -> torches(p, mao, param);
            case "CRIAR" -> breed(p, mao, param);
            case "ESQUILAR" -> shear(p, mao);
            case "ORDENAR" -> milk(p, mao);
            case "COMER" -> feedPlayer(p, mao, true);
            case "PUENTE" -> bridge(p, mao, param);
            case "REFUGIO" -> shelter(p, mao);
            case "COCINAR" -> cook(p, mao, param);
            case "BENDICION" -> bless(p, mao);
            case "INFO" -> info(p);
            case "CAMA" -> goBed(p, mao);
            case "MUERTE" -> goDeath(p, mao, param);
            default -> MaoSkillsPlus.run(p, mao, action, param);
        }
    }

    // ------------------------------------------------------------------ utilidades

    static void say(ServerPlayer p, String t) {
        MaoActions.say(p, t);
    }

    static void bullet(ServerPlayer p, Component c) {
        p.sendSystemMessage(Component.literal(" • ").append(c).withStyle(ChatFormatting.YELLOW));
    }

    static int parseNum(String s, int def, int min, int max) {
        if (s == null) return def;
        String t = s.trim();
        if (!t.matches("\\d{1,4}")) return def;
        return Math.max(min, Math.min(max, Integer.parseInt(t)));
    }

    static long countAvail(ServerPlayer p, MaoEntity mao, Predicate<ItemStack> test) {
        long n = mao.inventory.count(test);
        for (ItemStack s : p.getInventory().items) {
            if (!s.isEmpty() && test.test(s)) n += s.getCount();
        }
        return n;
    }

    /** Saca un objeto del inventario infinito de Mao o, si no lo tiene, de la mochila del jugador. */
    static ItemStack takeOne(ServerPlayer p, MaoEntity mao, Predicate<ItemStack> test) {
        ItemStack s = mao.inventory.takeOne(test);
        if (s != null) return s;
        Inventory inv = p.getInventory();
        for (ItemStack st : inv.items) {
            if (st.isEmpty() || !test.test(st)) continue;
            ItemStack one = st.copy();
            one.setCount(1);
            if (!p.getAbilities().instabuild) st.shrink(1);
            return one;
        }
        return null;
    }

    private static String dimName(String dim) {
        return switch (dim) {
            case "minecraft:overworld" -> "Overworld";
            case "minecraft:the_nether" -> "Nether";
            case "minecraft:the_end" -> "End";
            default -> dim;
        };
    }

    private static boolean isFree(ServerLevel level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        return s.getCollisionShape(level, pos).isEmpty() && s.getFluidState().isEmpty();
    }

    static BlockPos safeSpot(ServerLevel level, BlockPos pos) {
        for (int dy = 0; dy <= 8; dy++) {
            BlockPos q = pos.above(dy);
            if (isFree(level, q) && isFree(level, q.above())) return q;
        }
        return pos;
    }

    private static boolean hasGround(ServerLevel level, BlockPos pos) {
        for (int dy = 1; dy <= 6; dy++) {
            BlockPos q = pos.below(dy);
            if (!level.getBlockState(q).getCollisionShape(level, q).isEmpty()) return true;
        }
        return false;
    }

    static void teleport(ServerPlayer p, MaoEntity mao, ServerLevel dest, BlockPos safe, String label) {
        ServerLevel from = p.serverLevel();
        from.sendParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1.0, p.getZ(), 30, 0.4, 0.8, 0.4, 0.2);
        from.playSound(null, p.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.0F);
        p.teleportTo(dest, safe.getX() + 0.5, safe.getY(), safe.getZ() + 0.5, p.getYRot(), p.getXRot());
        p.fallDistance = 0.0F;
        dest.sendParticles(ParticleTypes.PORTAL, safe.getX() + 0.5, safe.getY() + 1.0, safe.getZ() + 0.5, 30, 0.4, 0.8, 0.4, 0.2);
        dest.playSound(null, safe, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.0F);
        if (mao != null && mao.isAlive() && !mao.isOrderedToSit()) {
            mao.warpTo(dest, safe.getX() + 1.5, safe.getY() + 1.0, safe.getZ() + 0.5);
        }
        say(p, "¡Allá vamos! Te he llevado a " + label + ".");
    }

    // ------------------------------------------------------------------ recoger objetos del suelo

    private static void pickUp(ServerPlayer p, MaoEntity mao) {
        if (MaoActions.cooling(p)) return;
        ServerLevel level = p.serverLevel();
        List<ItemEntity> items = level.getEntitiesOfClass(ItemEntity.class, p.getBoundingBox().inflate(16.0D),
                e -> e.isAlive() && !e.getItem().isEmpty());
        Map<String, long[]> sum = new LinkedHashMap<>();
        Map<String, ItemStack> names = new LinkedHashMap<>();
        long total = 0;
        boolean hearts = false;
        for (ItemEntity ie : items) {
            if (ie.getItem().getItem() instanceof HeartItem) {
                hearts = true;
                continue;
            }
            ItemStack s = ie.getItem().copy();
            String k = s.getHoverName().getString();
            sum.computeIfAbsent(k, x -> new long[1])[0] += s.getCount();
            names.putIfAbsent(k, s);
            total += s.getCount();
            mao.inventory.add(s);
            ie.discard();
        }
        if (total == 0) {
            say(p, hearts ? "Solo veo corazones mágicos: ¡esos son para ti, cógelos tú!" : "No veo ningún objeto tirado a menos de 16 bloques.");
            return;
        }
        level.playSound(null, p.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.6F, 1.2F);
        say(p, "¡Recogido! Tengo " + total + " objetos nuevos en mi inventario (pídemelos con «dame todo»)"
                + (hearts ? ". Los corazones mágicos los dejé para ti." : "."));
        int shown = 0;
        for (Map.Entry<String, long[]> e : sum.entrySet()) {
            if (shown++ >= 10) break;
            bullet(p, Component.literal("").append(names.get(e.getKey()).getHoverName()).append(Component.literal(" ×" + e.getValue()[0])));
        }
    }

    // ------------------------------------------------------------------ antorchas

    private static void torches(ServerPlayer p, MaoEntity mao, String param) {
        if (!MelonConfig.ALLOW_BUILD.get()) {
            say(p, "En este mundo mis manitas no pueden construir.");
            return;
        }
        if (MaoActions.cooling(p)) return;
        int r = parseNum(param, 12, 4, 24);
        Predicate<ItemStack> isTorch = s -> s.is(Items.TORCH);
        if (countAvail(p, mao, isTorch) <= 0) {
            say(p, "No tengo antorchas. Dame algunas o pídeme «craftea 8 antorchas» (necesito palos y carbón).");
            return;
        }
        ServerLevel level = p.serverLevel();
        BlockPos o = p.blockPosition();
        BlockState torch = Blocks.TORCH.defaultBlockState();
        List<BlockPos> cand = new ArrayList<>();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        for (int x = o.getX() - r; x <= o.getX() + r; x++) {
            for (int z = o.getZ() - r; z <= o.getZ() + r; z++) {
                for (int y = o.getY() - 4; y <= o.getY() + 4; y++) {
                    mp.set(x, y, z);
                    if (!level.hasChunkAt(mp) || !level.getBlockState(mp).isAir()) continue;
                    if (!torch.canSurvive(level, mp)) continue;
                    if (level.getMaxLocalRawBrightness(mp) > 7) continue;
                    if (!level.mayInteract(p, mp)) continue;
                    cand.add(mp.immutable());
                }
            }
        }
        cand.sort(Comparator.comparingDouble(b -> o.distSqr(b)));
        List<BlockPos> placed = new ArrayList<>();
        for (BlockPos c : cand) {
            if (placed.size() >= 16) break;
            boolean near = false;
            for (BlockPos q : placed) {
                if (q.distSqr(c) < 36) {
                    near = true;
                    break;
                }
            }
            if (near) continue;
            ItemStack t = takeOne(p, mao, isTorch);
            if (t == null) break;
            level.setBlock(c, torch, 3);
            placed.add(c);
        }
        if (placed.isEmpty()) {
            say(p, "No veo zonas oscuras a menos de " + r + " bloques: ¡ya hay luz de sobra!");
            return;
        }
        level.playSound(null, o, SoundEvents.WOOD_PLACE, SoundSource.PLAYERS, 1.0F, 1.0F);
        say(p, "¡Hágase la luz! He puesto " + placed.size() + (placed.size() == 1 ? " antorcha." : " antorchas."));
    }

    // ------------------------------------------------------------------ granja: criar, esquilar, ordeñar

    private static final String[][] ANIMALS = {{"vaca", "cow"}, {"oveja", "sheep"}, {"cerd", "pig"}, {"gallina", "chicken"},
            {"pollo", "chicken"}, {"conejo", "rabbit"}};

    private static String animalFilter(String text) {
        String n = MaoPlaces.norm(text == null ? "" : text);
        for (String[] a : ANIMALS) {
            if (n.contains(a[0])) return a[1];
        }
        return null;
    }

    private static boolean matchesAnimal(Animal a, String filter) {
        if (filter == null) return true;
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(a.getType());
        return id != null && id.getPath().contains(filter);
    }

    private static void breed(ServerPlayer p, MaoEntity mao, String param) {
        if (MaoActions.cooling(p)) return;
        ServerLevel level = p.serverLevel();
        final String filter = animalFilter(param);
        List<Animal> list = level.getEntitiesOfClass(Animal.class, p.getBoundingBox().inflate(14.0D),
                a -> a.isAlive() && !(a instanceof MaoEntity) && !(a instanceof TamableAnimal) && a.getAge() == 0
                        && !a.isInLove() && a.canFallInLove() && matchesAnimal(a, filter));
        if (list.isEmpty()) {
            say(p, "No veo animales listos para criar a menos de 14 bloques (los bebés y los que ya están enamorados no cuentan).");
            return;
        }
        int fed = 0;
        Set<String> noFood = new HashSet<>();
        for (Animal a : list) {
            if (fed >= 20) break;
            String tk = String.valueOf(ForgeRegistries.ENTITY_TYPES.getKey(a.getType()));
            if (noFood.contains(tk)) continue;
            ItemStack food = takeOne(p, mao, s -> a.isFood(s));
            if (food == null) {
                noFood.add(tk);
                continue;
            }
            a.setInLove(p);
            fed++;
        }
        if (fed == 0) {
            say(p, "No tengo comida para ellos: trigo para vacas y ovejas, zanahorias para cerdos y conejos, semillas para gallinas.");
            return;
        }
        say(p, "¡Ñam! He dado de comer a " + fed + (fed == 1 ? " animal" : " animales") + ". ¡Pronto habrá bebés!");
    }

    private static void shear(ServerPlayer p, MaoEntity mao) {
        if (MaoActions.cooling(p)) return;
        ServerLevel level = p.serverLevel();
        List<Sheep> sheep = level.getEntitiesOfClass(Sheep.class, p.getBoundingBox().inflate(14.0D),
                s -> s.isAlive() && s.readyForShearing());
        if (sheep.isEmpty()) {
            say(p, "No veo ovejas con lana lista a menos de 14 bloques.");
            return;
        }
        for (Sheep s : sheep) s.shear(SoundSource.PLAYERS);
        long wool = 0;
        List<ItemEntity> drops = level.getEntitiesOfClass(ItemEntity.class, p.getBoundingBox().inflate(16.0D),
                e -> e.isAlive() && e.tickCount < 10 && e.getItem().is(ItemTags.WOOL));
        for (ItemEntity e : drops) {
            wool += e.getItem().getCount();
            mao.inventory.add(e.getItem().copy());
            e.discard();
        }
        say(p, "¡Trasquilé " + sheep.size() + (sheep.size() == 1 ? " oveja" : " ovejas") + "! Guardé " + wool + " de lana en mi inventario.");
    }

    private static void milk(ServerPlayer p, MaoEntity mao) {
        if (MaoActions.cooling(p)) return;
        ServerLevel level = p.serverLevel();
        List<Cow> cows = level.getEntitiesOfClass(Cow.class, p.getBoundingBox().inflate(14.0D), c -> c.isAlive() && !c.isBaby());
        if (cows.isEmpty()) {
            say(p, "No veo vacas a menos de 14 bloques.");
            return;
        }
        int n = 0;
        for (Cow c : cows) {
            ItemStack bucket = takeOne(p, mao, s -> s.is(Items.BUCKET));
            if (bucket == null) break;
            mao.inventory.add(new ItemStack(Items.MILK_BUCKET));
            level.playSound(null, c.blockPosition(), SoundEvents.COW_MILK, SoundSource.NEUTRAL, 1.0F, 1.0F);
            n++;
        }
        if (n == 0) {
            say(p, "Necesito cubos vacíos para ordeñar. Dame alguno.");
            return;
        }
        say(p, "¡Mu! He ordeñado " + n + (n == 1 ? " vaca" : " vacas") + ": tengo " + n + (n == 1 ? " cubo" : " cubos") + " de leche en mi inventario.");
    }

    // ------------------------------------------------------------------ dar de comer al jugador

    private static boolean goodFood(ItemStack s) {
        FoodProperties fp = s.getItem().getFoodProperties();
        if (fp == null || fp.canAlwaysEat()) return false;
        for (var pr : fp.getEffects()) {
            if (pr.getFirst().getEffect().getCategory() == MobEffectCategory.HARMFUL) return false;
        }
        return true;
    }

    /** @return true si le dio algo de comer. */
    static boolean feedPlayer(ServerPlayer p, MaoEntity mao, boolean manual) {
        int level0 = p.getFoodData().getFoodLevel();
        if (manual && level0 >= 20) {
            say(p, "¡Estás llenito, no te hace falta comer!");
            return false;
        }
        int eaten = 0;
        int cap = manual ? 8 : 4;
        int goal = manual ? 20 : 18;
        while (eaten < cap && p.getFoodData().getFoodLevel() < goal) {
            int missing = 20 - p.getFoodData().getFoodLevel();
            ItemStack best = null;
            int bestScore = Integer.MIN_VALUE;
            for (MaoInventory.Entry e : mao.inventory.entries()) {
                if (!goodFood(e.proto)) continue;
                int n = e.proto.getItem().getFoodProperties().getNutrition();
                int score = n <= missing ? 1000 + n : 1000 - n;
                if (score > bestScore) {
                    bestScore = score;
                    best = e.proto;
                }
            }
            if (best == null) break;
            final Item it = best.getItem();
            ItemStack one = mao.inventory.takeOne(s -> s.getItem() == it);
            if (one == null) break;
            ItemStack rem = one.hasCraftingRemainingItem() ? one.getCraftingRemainingItem() : ItemStack.EMPTY;
            p.eat(p.level(), one);
            if (!rem.isEmpty()) mao.inventory.add(rem);
            eaten++;
        }
        if (eaten == 0) {
            if (manual) say(p, "No tengo comida buena en mi inventario (no uso comida mala ni dorada). Dame manzanas, pan, carne cocinada...");
            return false;
        }
        say(p, manual ? "¡Toma, a comer! Te di " + eaten + (eaten == 1 ? " comida." : " comidas.")
                : "¡Tenías hambre! Te he dado de comer (" + eaten + (eaten == 1 ? " comida" : " comidas") + ").");
        return true;
    }

    // ------------------------------------------------------------------ construir: puente y refugio

    private static boolean isBuildBlock(ItemStack s) {
        if (!(s.getItem() instanceof BlockItem bi)) return false;
        BlockState st = bi.getBlock().defaultBlockState();
        return st.is(BlockTags.PLANKS) || st.is(Tags.Blocks.COBBLESTONE) || st.is(Tags.Blocks.STONE) || st.is(BlockTags.DIRT)
                || st.is(BlockTags.STONE_BRICKS) || st.is(Blocks.NETHERRACK);
    }

    private static Item pickBuildItem(ServerPlayer p, MaoEntity mao) {
        Map<Item, Long> counts = new HashMap<>();
        for (MaoInventory.Entry e : mao.inventory.entries()) {
            if (isBuildBlock(e.proto)) counts.merge(e.proto.getItem(), e.count, Long::sum);
        }
        for (ItemStack s : p.getInventory().items) {
            if (!s.isEmpty() && isBuildBlock(s)) counts.merge(s.getItem(), (long) s.getCount(), Long::sum);
        }
        Item best = null;
        long bn = 0;
        for (Map.Entry<Item, Long> e : counts.entrySet()) {
            if (e.getValue() > bn) {
                bn = e.getValue();
                best = e.getKey();
            }
        }
        return best;
    }

    /** @return 1 si colocó un bloque, 0 si lo saltó (ya había algo o no se puede), -1 si se quedó sin material. */
    private static int placeBlock(ServerPlayer p, MaoEntity mao, ServerLevel level, BlockPos pos, Item item) {
        if (pos.getY() < level.getMinBuildHeight() || pos.getY() >= level.getMaxBuildHeight()) return 0;
        BlockState cur = level.getBlockState(pos);
        if (!(cur.isAir() || cur.canBeReplaced())) return 0;
        if (!level.mayInteract(p, pos)) return 0;
        ItemStack s = takeOne(p, mao, st -> st.is(item));
        if (s == null) return -1;
        Block b = ((BlockItem) item).getBlock();
        level.setBlock(pos, b.defaultBlockState(), 3);
        return 1;
    }

    private static void bridge(ServerPlayer p, MaoEntity mao, String param) {
        if (!MelonConfig.ALLOW_BUILD.get()) {
            say(p, "En este mundo mis manitas no pueden construir.");
            return;
        }
        if (MaoActions.cooling(p)) return;
        int len = parseNum(param, 8, 1, 48);
        Item item = pickBuildItem(p, mao);
        if (item == null) {
            say(p, "No tengo bloques para construir (me valen piedra, adoquín, tablas o tierra). Dame algunos.");
            return;
        }
        ServerLevel level = p.serverLevel();
        Direction dir = p.getDirection();
        BlockPos base = p.blockPosition().below();
        int placed = 0;
        boolean out = false;
        for (int i = 1; i <= len; i++) {
            int r = placeBlock(p, mao, level, base.relative(dir, i), item);
            if (r < 0) {
                out = true;
                break;
            }
            placed += r;
        }
        if (placed == 0) {
            say(p, out ? "Me he quedado sin bloques." : "Ahí delante ya hay camino, no hace falta puente.");
            return;
        }
        level.playSound(null, p.blockPosition(), SoundEvents.STONE_PLACE, SoundSource.PLAYERS, 1.0F, 1.0F);
        say(p, "¡Puente listo! Coloqué " + placed + " bloques hacia delante" + (out ? " (me quedé sin material, pídeme más cuando tengas)." : "."));
    }

    private static void shelter(ServerPlayer p, MaoEntity mao) {
        if (!MelonConfig.ALLOW_BUILD.get()) {
            say(p, "En este mundo mis manitas no pueden construir.");
            return;
        }
        if (MaoActions.cooling(p)) return;
        Item item = pickBuildItem(p, mao);
        if (item == null) {
            say(p, "No tengo bloques para el refugio (me valen piedra, adoquín, tablas o tierra). Necesito unos 60.");
            return;
        }
        ServerLevel level = p.serverLevel();
        BlockPos c = p.blockPosition();
        Direction face = p.getDirection();
        BlockPos door = c.relative(face, 2);
        List<BlockPos> plan = new ArrayList<>();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) plan.add(c.offset(dx, -1, dz));
        }
        for (int h = 0; h <= 1; h++) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != 2) continue;
                    BlockPos w = c.offset(dx, h, dz);
                    if (w.equals(door) || w.equals(door.above())) continue;
                    plan.add(w);
                }
            }
        }
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) plan.add(c.offset(dx, 2, dz));
        }
        int placed = 0;
        boolean out = false;
        for (BlockPos pos : plan) {
            int r = placeBlock(p, mao, level, pos, item);
            if (r < 0) {
                out = true;
                break;
            }
            placed += r;
        }
        BlockState torch = Blocks.TORCH.defaultBlockState();
        BlockPos tp = c.offset(-1, 0, -1);
        if (level.getBlockState(tp).isAir() && torch.canSurvive(level, tp)) {
            ItemStack t = takeOne(p, mao, s -> s.is(Items.TORCH));
            if (t != null) level.setBlock(tp, torch, 3);
        }
        if (placed == 0) {
            say(p, out ? "Me he quedado sin bloques." : "Aquí ya hay paredes, no puedo construir nada nuevo.");
            return;
        }
        level.playSound(null, c, SoundEvents.STONE_PLACE, SoundSource.PLAYERS, 1.0F, 1.0F);
        say(p, "¡Refugio listo! Puse " + placed + " bloques: paredes, techo y suelo, con la puerta mirando hacia donde miras"
                + (out ? " (me quedé sin material, quizá falten huecos)." : "."));
    }

    // ------------------------------------------------------------------ cocinar y fundir

    private static boolean isFuel(ItemStack s) {
        Item i = s.getItem();
        return i == Items.COAL || i == Items.CHARCOAL || i == Items.COAL_BLOCK || i == Items.BLAZE_ROD || i == Items.DRIED_KELP_BLOCK;
    }

    private static int burn(Item i) {
        if (i == Items.COAL_BLOCK) return 16000;
        if (i == Items.DRIED_KELP_BLOCK) return 4000;
        if (i == Items.BLAZE_ROD) return 2400;
        return 1600;
    }

    private static final Set<String> RAW_FOOD = Set.of("beef", "porkchop", "mutton", "chicken", "rabbit", "cod", "salmon");

    private static boolean autoSmeltable(ItemStack s) {
        ResourceLocation id = ForgeRegistries.ITEMS.getKey(s.getItem());
        if (id == null) return false;
        String path = id.getPath();
        return path.startsWith("raw_") || path.contains("_ore") || path.equals("ancient_debris") || RAW_FOOD.contains(path);
    }

    private static void cook(ServerPlayer p, MaoEntity mao, String param) {
        if (MaoActions.cooling(p)) return;
        MaoItems.Amount a = MaoItems.parseAmount(param == null ? "" : param);
        Predicate<ItemStack> test;
        if (a.rest().isBlank()) {
            if (!a.all() && (param == null || param.isBlank() || !MaoPlaces.norm(param).contains("todo"))) {
                say(p, "¿Qué cocino o fundo? Dime por ejemplo «cocina la carne», «funde el hierro» o «cocina todo» (carne cruda y minerales).");
                return;
            }
            test = MaoSkills::autoSmeltable;
        } else {
            MaoItems.Query q = MaoItems.resolve(a.rest());
            if (q == null) {
                say(p, "No sé qué objeto es «" + a.rest() + "».");
                return;
            }
            test = q::test;
        }
        ServerLevel level = p.serverLevel();
        RegistryAccess ra = level.registryAccess();
        long max = a.n() > 0 ? a.n() : Long.MAX_VALUE;
        long credit = 0;
        long smelted = 0;
        boolean noFuel = false;
        Map<String, long[]> made = new LinkedHashMap<>();
        Map<String, ItemStack> names = new LinkedHashMap<>();

        for (MaoInventory.Entry e : new ArrayList<>(mao.inventory.entries())) {
            if (smelted >= max || noFuel) break;
            final ItemStack proto = e.proto.copy();
            if (!test.test(proto) || isFuel(proto)) continue;
            Optional<SmeltingRecipe> rec = level.getRecipeManager().getRecipeFor(RecipeType.SMELTING, new SimpleContainer(proto), level);
            if (rec.isEmpty()) continue;
            ItemStack result = rec.get().getResultItem(ra);
            if (result.isEmpty()) continue;
            int time = Math.max(20, rec.get().getCookingTime());
            long want = Math.min(e.count, max - smelted);
            long done = 0;
            while (done < want) {
                if (credit < time) {
                    ItemStack fuel = mao.inventory.takeOne(MaoSkills::isFuel);
                    if (fuel == null) {
                        noFuel = true;
                        break;
                    }
                    credit += burn(fuel.getItem());
                    if (fuel.hasCraftingRemainingItem()) mao.inventory.add(fuel.getCraftingRemainingItem());
                }
                credit -= time;
                done++;
            }
            if (done <= 0) continue;
            mao.inventory.take(s -> ItemStack.isSameItemSameTags(s, proto), done);
            long total = (long) result.getCount() * done;
            while (total > 0) {
                int c = (int) Math.min(64L, total);
                ItemStack out = result.copy();
                out.setCount(c);
                mao.inventory.add(out);
                total -= c;
            }
            String k = result.getHoverName().getString();
            made.computeIfAbsent(k, x -> new long[1])[0] += (long) result.getCount() * done;
            names.putIfAbsent(k, result);
            smelted += done;
        }
        if (smelted == 0) {
            say(p, noFuel ? "No tengo combustible: necesito carbón, carbón vegetal, un bloque de carbón o varas de blaze en mi inventario."
                    : "No tengo nada que pueda cocinar o fundir con eso en mi inventario.");
            return;
        }
        level.playSound(null, p.blockPosition(), SoundEvents.FURNACE_FIRE_CRACKLE, SoundSource.PLAYERS, 1.0F, 1.0F);
        MaoActions.sparkle(mao);
        say(p, "¡Listo! He cocinado/fundido " + smelted + (smelted == 1 ? " objeto" : " objetos") + (noFuel ? " (me quedé sin combustible)" : "") + ":");
        for (Map.Entry<String, long[]> e : made.entrySet()) {
            bullet(p, Component.literal("").append(names.get(e.getKey()).getHoverName()).append(Component.literal(" ×" + e.getValue()[0])));
        }
    }

    // ------------------------------------------------------------------ bendición

    private static void bless(ServerPlayer p, MaoEntity mao) {
        int lvl = Innocence.getLevel(p);
        if (lvl < 4) {
            say(p, "Todavía soy muy chiquitín para bendecirte... ¡sube tu Inocencia a nivel 4!");
            return;
        }
        long now = p.serverLevel().getGameTime();
        Long next = BLESS.get(p.getUUID());
        if (next != null && now < next) {
            say(p, "Mi bendición está recargándose, espera " + Math.max(1, (next - now) / 20L) + " segundos.");
            return;
        }
        BLESS.put(p.getUUID(), now + 3600L);
        List<String> got = new ArrayList<>();
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 4800, 0));
        got.add("velocidad");
        if (lvl >= 6) {
            p.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 4800, 0));
            got.add("prisa minera");
        }
        if (lvl >= 7) {
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 4800, 0));
            got.add("resistencia");
        }
        if (lvl >= 8) {
            p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 6000, 0));
            p.addEffect(new MobEffectInstance(MobEffects.JUMP, 4800, 0));
            got.add("visión nocturna");
            got.add("salto");
        }
        if (lvl >= 10) {
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 4800, 0));
            p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 4800, 1));
            got.add("fuerza");
            got.add("absorción");
        }
        p.serverLevel().sendParticles(ParticleTypes.HAPPY_VILLAGER, p.getX(), p.getY() + 1.0, p.getZ(), 20, 0.5, 0.8, 0.5, 0.0);
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.ALLAY_ITEM_GIVEN, SoundSource.NEUTRAL, 1.0F, 1.5F);
        MaoActions.sparkle(mao);
        say(p, "¡Mi bendición para ti! Tienes: " + String.join(", ", got) + ".");
    }

    // ------------------------------------------------------------------ información del mundo

    private static void info(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        BlockPos pos = p.blockPosition();
        String biome = level.getBiome(pos).unwrapKey().map(k -> k.location().getPath().replace('_', ' ')).orElse("desconocido");
        String dim = dimName(level.dimension().location().toString());
        String weather = level.isThundering() ? "tormenta" : level.isRaining() ? "lluvia" : "cielo despejado";
        say(p, "Estamos en " + pos.getX() + ", " + pos.getY() + ", " + pos.getZ() + " (" + dim + "), bioma: " + biome + ".");
        if (level.dimension() == Level.OVERWORLD) {
            long t = level.getDayTime() % 24000L;
            int hour = (int) ((t / 1000L + 6L) % 24L);
            int min = (int) ((t % 1000L) * 60L / 1000L);
            String clock = (hour < 10 ? "0" : "") + hour + ":" + (min < 10 ? "0" : "") + min;
            String next;
            if (t < 13000L) next = "faltan unos " + Math.max(1L, (13000L - t) / 1200L) + " min reales para que anochezca";
            else next = "faltan unos " + Math.max(1L, (24000L - t) / 1200L) + " min reales para que amanezca";
            say(p, "Son las " + clock + " del juego, " + (t < 13000L ? "es de día" : "es de noche") + " (" + next + "). Tiempo: " + weather + ".");
        } else {
            say(p, "Aquí no hay ciclo de día y noche. Tiempo: " + weather + ".");
        }
    }

    // ------------------------------------------------------------------ viajar a la cama y al sitio donde moriste

    private static void goBed(ServerPlayer p, MaoEntity mao) {
        if (!MelonConfig.ALLOW_TELEPORT.get()) {
            say(p, "Mi magia de teletransporte está desactivada en este mundo.");
            return;
        }
        BlockPos bed = p.getRespawnPosition();
        ServerLevel dest = bed == null ? p.server.overworld() : p.server.getLevel(p.getRespawnDimension());
        if (dest == null) dest = p.server.overworld();
        BlockPos target = bed == null ? dest.getSharedSpawnPos() : bed;
        teleport(p, mao, dest, safeSpot(dest, target), bed == null ? "el spawn del mundo (no tienes cama guardada)" : "tu cama");
    }

    private static void goDeath(ServerPlayer p, MaoEntity mao, String param) {
        Optional<GlobalPos> last = p.getLastDeathLocation();
        if (last.isEmpty()) {
            say(p, "No recuerdo que hayas muerto todavía... ¡y que siga así!");
            return;
        }
        GlobalPos gp = last.get();
        BlockPos pos = gp.pos();
        String where = pos.getX() + ", " + pos.getY() + ", " + pos.getZ() + " (" + dimName(gp.dimension().location().toString()) + ")";
        if (!"ir".equals(param)) {
            say(p, "Tu última muerte fue en " + where + ". Dime «llévame a donde morí» y te llevo (cuidado con lo que te mató).");
            return;
        }
        if (!MelonConfig.ALLOW_TELEPORT.get()) {
            say(p, "Mi magia de teletransporte está desactivada en este mundo.");
            return;
        }
        ServerLevel dest = p.server.getLevel(gp.dimension());
        if (dest == null) {
            say(p, "No consigo encontrar esa dimensión... ¿has quitado algún mod?");
            return;
        }
        BlockPos safe = safeSpot(dest, pos);
        if (dest.getFluidState(safe).is(FluidTags.LAVA) || dest.getFluidState(safe.below()).is(FluidTags.LAVA)
                || dest.getFluidState(pos).is(FluidTags.LAVA)) {
            say(p, "¡Allí hay lava! No te llevo, es demasiado peligroso. Estaba en " + where + ".");
            return;
        }
        if (safe.getY() < dest.getMinBuildHeight() + 2 || !hasGround(dest, safe)) {
            say(p, "Allí no hay suelo firme (¿el vacío?). No te llevo. Estaba en " + where + ".");
            return;
        }
        teleport(p, mao, dest, safe, "donde moriste (" + where + ")");
    }

    // ------------------------------------------------------------------ avisos automáticos y comida automática

    private static boolean ready(UUID id, String type, long now, long cooldown) {
        String k = id + type;
        Long n = NEXT.get(k);
        if (n != null && now < n) return false;
        NEXT.put(k, now + cooldown);
        return true;
    }

    private static boolean lead(MaoEntity mao, ServerPlayer owner) {
        return MaoRoster.primary(owner) == mao;
    }

    /** Se llama una vez por segundo desde cada Mao domesticado cuyo dueño está conectado. */
    public static void passiveTick(MaoEntity mao, ServerPlayer owner, long now) {
        MaoSkillsPlus.tickReminders(owner);
        if (mao.level() != owner.level() || mao.distanceToSqr(owner) > 900.0D || owner.isSpectator()) return;
        UUID id = owner.getUUID();

        if (MelonConfig.AUTO_FEED.get() && owner.getFoodData().getFoodLevel() <= 10 && !mao.inventory.isEmpty()
                && ready(id, "feed", now, 600L)) {
            MaoActions.setSpeaker(mao);
            feedPlayer(owner, mao, false);
        }

        if (!MelonConfig.DANGER_ALERTS.get() || !(mao.level() instanceof ServerLevel level)) return;
        if (!lead(mao, owner)) return;

        List<Creeper> creepers = level.getEntitiesOfClass(Creeper.class, owner.getBoundingBox().inflate(7.0D), c -> c.isAlive());
        if (!creepers.isEmpty() && ready(id, "creeper", now, 300L)) {
            MaoActions.setSpeaker(mao);
            say(owner, "¡Cuidado, hay un creeper muy cerca de ti!");
            return;
        }
        List<Monster> mobs = level.getEntitiesOfClass(Monster.class, owner.getBoundingBox().inflate(14.0D), m -> m.isAlive());
        if (owner.getHealth() <= 6.0F && !mobs.isEmpty() && ready(id, "lowhp", now, 600L)) {
            MaoActions.setSpeaker(mao);
            say(owner, "¡Te queda poca vida y hay monstruos cerca! Aléjate o dime «cúrame».");
            return;
        }
        if (mobs.size() >= 5 && ready(id, "horde", now, 600L)) {
            MaoActions.setSpeaker(mao);
            say(owner, "¡Vienen muchos monstruos (" + mobs.size() + ")! Prepárate.");
        }
    }
}
