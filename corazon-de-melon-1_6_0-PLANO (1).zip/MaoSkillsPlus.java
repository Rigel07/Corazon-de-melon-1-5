package com.corazondemelon.ai;

import com.corazondemelon.MelonConfig;
import com.corazondemelon.entity.MaoEntity;
import com.corazondemelon.innocence.Innocence;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.StemBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Predicate;

/**
 * Más habilidades de los Maos (1.6.0): pescar, talar árboles y replantar, plantar brotes, abonar cultivos con harina de hueso,
 * reparar tus herramientas, ordenar tu mochila, curar a tus mascotas, chistes, datos curiosos, bailar, salir a la superficie
 * y recordatorios («avísame en 5 minutos»).
 */
public final class MaoSkillsPlus {
    private record Reminder(UUID id, long due, String text) {}

    private static final List<Reminder> REMINDERS = new CopyOnWriteArrayList<>();
    private static final Map<UUID, Long> DANCE_XP = new ConcurrentHashMap<>();
    private static final Random RND = new Random();

    private MaoSkillsPlus() {}

    static void run(ServerPlayer p, MaoEntity mao, String action, String param) {
        if (action == null) return;
        switch (action) {
            case "PESCAR" -> fish(p, mao, param);
            case "TALAR" -> fell(p, mao, param);
            case "PLANTAR" -> plant(p, mao, param);
            case "ABONAR" -> bonemeal(p, mao);
            case "REPARAR" -> repair(p, mao);
            case "ORDENAR_MOCHILA" -> sortBackpack(p);
            case "CURAR_MASCOTAS" -> healPets(p);
            case "CHISTE" -> say(p, JOKES[RND.nextInt(JOKES.length)]);
            case "DATO" -> say(p, "¿Sabías que... " + FACTS[RND.nextInt(FACTS.length)]);
            case "BAILAR" -> dance(p, mao);
            case "SUPERFICIE" -> surface(p, mao);
            case "RECORDATORIO" -> remind(p, param);
            default -> { }
        }
    }

    private static void say(ServerPlayer p, String t) {
        MaoActions.say(p, t);
    }

    private static boolean buildOff(ServerPlayer p) {
        if (MelonConfig.ALLOW_BUILD.get()) return false;
        say(p, "En este mundo mis manitas no pueden construir ni talar.");
        return true;
    }

    // ------------------------------------------------------------------ pescar

    private static void fish(ServerPlayer p, MaoEntity mao, String param) {
        if (MaoActions.cooling(p)) return;
        int casts = MaoSkills.parseNum(param, 5, 1, 30);
        if (MaoSkills.countAvail(p, mao, s -> s.is(Items.FISHING_ROD)) <= 0) {
            say(p, "Necesito una caña de pescar. Dame una o pídeme «craftea una caña de pescar».");
            return;
        }
        ServerLevel level = p.serverLevel();
        BlockPos o = p.blockPosition();
        boolean water = false;
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        for (int x = -6; x <= 6 && !water; x++) {
            for (int z = -6; z <= 6 && !water; z++) {
                for (int y = -3; y <= 1; y++) {
                    mp.set(o.getX() + x, o.getY() + y, o.getZ() + z);
                    if (level.getFluidState(mp).is(FluidTags.WATER)) {
                        water = true;
                        break;
                    }
                }
            }
        }
        if (!water) {
            say(p, "No veo agua cerca para pescar. Llévame a un lago o al mar (a menos de 6 bloques).");
            return;
        }
        LootTable table = level.getServer().getLootData().getLootTable(BuiltInLootTables.FISHING);
        LootParams params = new LootParams.Builder(level)
                .withParameter(LootContextParams.ORIGIN, p.position())
                .withParameter(LootContextParams.TOOL, new ItemStack(Items.FISHING_ROD))
                .withLuck(p.getLuck())
                .create(LootContextParamSets.FISHING);
        Map<String, long[]> sum = new LinkedHashMap<>();
        Map<String, ItemStack> names = new LinkedHashMap<>();
        long total = 0;
        for (int i = 0; i < casts; i++) {
            for (ItemStack s : table.getRandomItems(params)) {
                if (s.isEmpty()) continue;
                String k = s.getHoverName().getString();
                sum.computeIfAbsent(k, x -> new long[1])[0] += s.getCount();
                names.putIfAbsent(k, s.copy());
                total += s.getCount();
                mao.inventory.add(s.copy());
            }
        }
        level.playSound(null, p.blockPosition(), SoundEvents.FISHING_BOBBER_SPLASH, SoundSource.NEUTRAL, 1.0F, 1.0F);
        if (total == 0) {
            say(p, "Eché la caña " + casts + " veces y no picó nada... ¡otra vez será!");
            return;
        }
        say(p, "¡A pescar! Tras " + casts + " lanzamientos he sacado " + total + " cosas (están en mi inventario):");
        int shown = 0;
        for (Map.Entry<String, long[]> e : sum.entrySet()) {
            if (shown++ >= 10) break;
            MaoSkills.bullet(p, Component.literal("").append(names.get(e.getKey()).getHoverName()).append(Component.literal(" ×" + e.getValue()[0])));
        }
    }

    // ------------------------------------------------------------------ talar árboles (y replantar)

    private static Set<BlockPos> collectLogs(ServerLevel level, BlockPos start) {
        Set<BlockPos> seen = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        seen.add(start);
        queue.add(start);
        while (!queue.isEmpty() && seen.size() < 300) {
            BlockPos c = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        BlockPos n = c.offset(dx, dy, dz);
                        if (seen.contains(n) || !level.getBlockState(n).is(BlockTags.LOGS)) continue;
                        seen.add(n);
                        queue.add(n);
                    }
                }
            }
        }
        return seen;
    }

    /** Un árbol «de verdad» tiene hojas naturales (no puestas por ti): así no se talan casas de madera. */
    private static boolean isNaturalTree(ServerLevel level, Set<BlockPos> logs) {
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        for (BlockPos b : logs) {
            minX = Math.min(minX, b.getX());
            minY = Math.min(minY, b.getY());
            minZ = Math.min(minZ, b.getZ());
            maxX = Math.max(maxX, b.getX());
            maxY = Math.max(maxY, b.getY());
            maxZ = Math.max(maxZ, b.getZ());
        }
        int leaves = 0;
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        for (int x = minX - 2; x <= maxX + 2; x++) {
            for (int y = minY; y <= maxY + 3; y++) {
                for (int z = minZ - 2; z <= maxZ + 2; z++) {
                    BlockState st = level.getBlockState(mp.set(x, y, z));
                    if (st.is(BlockTags.LEAVES) && st.hasProperty(LeavesBlock.PERSISTENT) && !st.getValue(LeavesBlock.PERSISTENT)) leaves++;
                }
            }
        }
        return leaves >= 4;
    }

    private static Set<BlockPos> findTree(ServerLevel level, BlockPos o, int r, Set<BlockPos> skip) {
        List<BlockPos> logs = new ArrayList<>();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        for (int x = o.getX() - r; x <= o.getX() + r; x++) {
            for (int z = o.getZ() - r; z <= o.getZ() + r; z++) {
                for (int y = o.getY() - 4; y <= o.getY() + 14; y++) {
                    mp.set(x, y, z);
                    if (!level.hasChunkAt(mp) || !level.getBlockState(mp).is(BlockTags.LOGS)) continue;
                    BlockPos im = mp.immutable();
                    if (!skip.contains(im)) logs.add(im);
                }
            }
        }
        logs.sort(Comparator.comparingDouble(b -> o.distSqr(b)));
        for (BlockPos lg : logs) {
            if (skip.contains(lg)) continue;
            Set<BlockPos> tree = collectLogs(level, lg);
            if (isNaturalTree(level, tree)) return tree;
            skip.addAll(tree);
        }
        return null;
    }

    private static void fell(ServerPlayer p, MaoEntity mao, String param) {
        if (buildOff(p) || MaoActions.cooling(p)) return;
        String np = MaoPlaces.norm(param == null ? "" : param);
        int trees = np.contains("todos") || np.contains("todas") ? 6 : MaoSkills.parseNum(np.replaceAll("[^0-9]", ""), 1, 1, 8);
        ServerLevel level = p.serverLevel();
        BlockPos o = p.blockPosition();
        Set<BlockPos> skip = new HashSet<>();
        int felled = 0, replanted = 0;
        long logs = 0;
        for (int t = 0; t < trees; t++) {
            Set<BlockPos> tree = findTree(level, o, 20, skip);
            if (tree == null) break;
            boolean allowed = true;
            for (BlockPos b : tree) {
                if (!level.mayInteract(p, b)) {
                    allowed = false;
                    break;
                }
            }
            if (!allowed) {
                skip.addAll(tree);
                t--;
                continue;
            }
            int minY = Integer.MAX_VALUE;
            for (BlockPos b : tree) minY = Math.min(minY, b.getY());
            Map<BlockPos, Block> bases = new HashMap<>();
            for (BlockPos b : tree) {
                if (b.getY() == minY && level.getBlockState(b.below()).is(BlockTags.DIRT)) bases.put(b, level.getBlockState(b).getBlock());
            }
            for (BlockPos b : tree) {
                BlockState st = level.getBlockState(b);
                if (!st.is(BlockTags.LOGS)) continue;
                List<ItemStack> drops = Block.getDrops(st, level, b, level.getBlockEntity(b), p, ItemStack.EMPTY);
                level.destroyBlock(b, false);
                for (ItemStack d : drops) mao.inventory.add(d);
                logs++;
            }
            felled++;
            skip.addAll(tree);
            for (Map.Entry<BlockPos, Block> e : bases.entrySet()) {
                ResourceLocation id = ForgeRegistries.BLOCKS.getKey(e.getValue());
                if (id == null) continue;
                String wood = id.getPath().replace("stripped_", "").replace("_log", "").replace("_wood", "");
                Item sap = ForgeRegistries.ITEMS.getValue(new ResourceLocation(id.getNamespace(), wood + "_sapling"));
                if (sap == null || sap == Items.AIR || !(sap instanceof BlockItem bi)) continue;
                BlockPos at = e.getKey();
                BlockState bs = bi.getBlock().defaultBlockState();
                if (!level.getBlockState(at).isAir() || !bs.canSurvive(level, at)) continue;
                ItemStack s = MaoSkills.takeOne(p, mao, st -> st.is(sap));
                if (s == null) continue;
                level.setBlock(at, bs, 3);
                replanted++;
            }
        }
        if (felled == 0) {
            say(p, "No veo ningún árbol natural a menos de 20 bloques (no toco las casas ni las cosas de madera que has construido).");
            return;
        }
        say(p, "¡Timber! Talé " + felled + (felled == 1 ? " árbol" : " árboles") + " (" + logs + " troncos en mi inventario)"
                + (replanted > 0 ? " y replanté " + replanted + (replanted == 1 ? " brote." : " brotes.") : ". Si me das brotes, los replanto.")
                + " Las hojas se caerán solas.");
    }

    // ------------------------------------------------------------------ plantar brotes

    private static void plant(ServerPlayer p, MaoEntity mao, String param) {
        if (buildOff(p) || MaoActions.cooling(p)) return;
        int n = MaoSkills.parseNum(param, 6, 1, 16);
        Predicate<ItemStack> isSap = s -> s.is(ItemTags.SAPLINGS) && s.getItem() instanceof BlockItem;
        if (MaoSkills.countAvail(p, mao, isSap) <= 0) {
            say(p, "No tengo brotes de árbol. Dame algunos (o tala árboles y recojo los que caigan).");
            return;
        }
        ServerLevel level = p.serverLevel();
        BlockPos o = p.blockPosition();
        List<BlockPos> cand = new ArrayList<>();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        BlockState probe = Blocks.OAK_SAPLING.defaultBlockState();
        for (int x = o.getX() - 10; x <= o.getX() + 10; x++) {
            for (int z = o.getZ() - 10; z <= o.getZ() + 10; z++) {
                for (int y = o.getY() - 3; y <= o.getY() + 3; y++) {
                    mp.set(x, y, z);
                    if (!level.hasChunkAt(mp) || !level.getBlockState(mp).isAir() || !level.getBlockState(mp.above()).isAir()) continue;
                    if (!level.getBlockState(mp.below()).is(BlockTags.DIRT) || !probe.canSurvive(level, mp)) continue;
                    if (level.getMaxLocalRawBrightness(mp) < 9 || !level.mayInteract(p, mp)) continue;
                    cand.add(mp.immutable());
                }
            }
        }
        cand.sort(Comparator.comparingDouble(b -> o.distSqr(b)));
        List<BlockPos> placed = new ArrayList<>();
        for (BlockPos c : cand) {
            if (placed.size() >= n) break;
            boolean near = false;
            for (BlockPos q : placed) {
                if (q.distSqr(c) < 9) {
                    near = true;
                    break;
                }
            }
            if (near) continue;
            ItemStack s = MaoSkills.takeOne(p, mao, isSap);
            if (s == null) break;
            BlockState bs = ((BlockItem) s.getItem()).getBlock().defaultBlockState();
            if (!bs.canSurvive(level, c)) {
                mao.inventory.add(s);
                continue;
            }
            level.setBlock(c, bs, 3);
            placed.add(c);
        }
        if (placed.isEmpty()) {
            say(p, "No encuentro sitio bueno para plantar (necesito tierra o hierba con luz y espacio libre alrededor).");
            return;
        }
        level.playSound(null, o, SoundEvents.GRASS_PLACE, SoundSource.PLAYERS, 1.0F, 1.0F);
        say(p, "¡Plantado! Puse " + placed.size() + (placed.size() == 1 ? " brote." : " brotes.") + " Con harina de hueso («abona») crecen antes.");
    }

    // ------------------------------------------------------------------ abonar con harina de hueso

    private static boolean growable(BlockState st) {
        Block b = st.getBlock();
        if (b instanceof CropBlock cb) return !cb.isMaxAge(st);
        if (b instanceof StemBlock) return st.getValue(StemBlock.AGE) < 7;
        return b instanceof SaplingBlock;
    }

    private static void bonemeal(ServerPlayer p, MaoEntity mao) {
        if (MaoActions.cooling(p)) return;
        if (MaoSkills.countAvail(p, mao, s -> s.is(Items.BONE_MEAL)) <= 0) {
            say(p, "No tengo harina de hueso. Dame o pídeme «craftea harina de hueso» (con huesos).");
            return;
        }
        ServerLevel level = p.serverLevel();
        BlockPos o = p.blockPosition();
        List<BlockPos> targets = new ArrayList<>();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        for (int x = o.getX() - 8; x <= o.getX() + 8; x++) {
            for (int z = o.getZ() - 8; z <= o.getZ() + 8; z++) {
                for (int y = o.getY() - 3; y <= o.getY() + 3; y++) {
                    mp.set(x, y, z);
                    if (level.hasChunkAt(mp) && growable(level.getBlockState(mp)) && level.mayInteract(p, mp)) targets.add(mp.immutable());
                }
            }
        }
        if (targets.isEmpty()) {
            say(p, "No veo cultivos ni brotes que necesiten crecer a menos de 8 bloques.");
            return;
        }
        targets.sort(Comparator.comparingDouble(b -> o.distSqr(b)));
        int used = 0;
        boolean out = false;
        for (BlockPos pos : targets) {
            for (int k = 0; k < 4 && used < 40 && !out; k++) {
                if (!growable(level.getBlockState(pos))) break;
                ItemStack bm = MaoSkills.takeOne(p, mao, s -> s.is(Items.BONE_MEAL));
                if (bm == null) {
                    out = true;
                    break;
                }
                if (BoneMealItem.growCrop(bm, level, pos)) {
                    used++;
                    level.levelEvent(1505, pos, 0);
                } else {
                    mao.inventory.add(bm);
                    break;
                }
            }
            if (out || used >= 40) break;
        }
        if (used == 0) {
            say(p, "No he podido abonar nada ahora mismo.");
            return;
        }
        say(p, "¡A crecer! Gasté " + used + " de harina de hueso" + (out ? " (se me acabó)." : "."));
    }

    // ------------------------------------------------------------------ reparar herramientas

    private static void repair(ServerPlayer p, MaoEntity mao) {
        Inventory inv = p.getInventory();
        List<ItemStack> damaged = new ArrayList<>();
        for (List<ItemStack> part : List.of(inv.items, inv.armor, inv.offhand)) {
            for (ItemStack s : part) {
                if (!s.isEmpty() && s.isDamaged()) damaged.add(s);
            }
        }
        if (damaged.isEmpty()) {
            say(p, "¡Todo lo que llevas está como nuevo!");
            return;
        }
        int mats = 0;
        List<String> fixed = new ArrayList<>();
        for (ItemStack tool : damaged) {
            int guard = 0;
            boolean any = false;
            while (tool.isDamaged() && guard++ < 8 && mats < 64) {
                final ItemStack t = tool;
                ItemStack mat = mao.inventory.takeOne(c -> t.getItem().isValidRepairItem(t, c));
                if (mat == null) break;
                int per = Math.max(1, tool.getMaxDamage() / 4);
                tool.setDamageValue(Math.max(0, tool.getDamageValue() - per));
                mats++;
                any = true;
            }
            if (any) fixed.add(tool.getHoverName().getString() + (tool.isDamaged() ? " (a medias)" : ""));
        }
        if (fixed.isEmpty()) {
            say(p, "No tengo materiales para repararlo: necesito lingotes de hierro, diamantes, cuero, tablas... en mi inventario.");
            return;
        }
        p.inventoryMenu.broadcastChanges();
        MaoActions.sparkle(mao);
        say(p, "¡Arreglado! Usé " + mats + " materiales en: " + String.join(", ", fixed) + ".");
    }

    // ------------------------------------------------------------------ ordenar la mochila

    private static int rank(ItemStack s) {
        if (s.isDamageableItem()) return 0;
        if (s.getItem() instanceof BlockItem) return 1;
        if (s.getItem().isEdible()) return 2;
        return 3;
    }

    private static void sortBackpack(ServerPlayer p) {
        Inventory inv = p.getInventory();
        List<ItemStack> stacks = new ArrayList<>();
        for (int i = 9; i < 36; i++) {
            ItemStack s = inv.items.get(i);
            if (!s.isEmpty()) stacks.add(s.copy());
        }
        if (stacks.isEmpty()) {
            say(p, "Tu mochila (sin la barra rápida) está vacía, no hay nada que ordenar.");
            return;
        }
        List<ItemStack> merged = new ArrayList<>();
        for (ItemStack s : stacks) {
            for (ItemStack m : merged) {
                if (s.isEmpty()) break;
                if (ItemStack.isSameItemSameTags(m, s) && m.getCount() < m.getMaxStackSize()) {
                    int mv = Math.min(s.getCount(), m.getMaxStackSize() - m.getCount());
                    m.grow(mv);
                    s.shrink(mv);
                }
            }
            if (!s.isEmpty()) merged.add(s);
        }
        merged.sort(Comparator.<ItemStack>comparingInt(MaoSkillsPlus::rank)
                .thenComparing(s -> String.valueOf(ForgeRegistries.ITEMS.getKey(s.getItem())))
                .thenComparingInt(s -> -s.getCount()));
        for (int i = 9; i < 36; i++) inv.items.set(i, ItemStack.EMPTY);
        for (int i = 0; i < merged.size() && i < 27; i++) inv.items.set(9 + i, merged.get(i));
        p.inventoryMenu.broadcastChanges();
        say(p, "¡Mochila ordenada! Herramientas primero, luego bloques, comida y lo demás (tu barra rápida no la toqué).");
    }

    // ------------------------------------------------------------------ curar mascotas

    private static void healPets(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        List<LivingEntity> pets = level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(24.0D),
                e -> e.isAlive() && !(e instanceof MaoEntity)
                        && ((e instanceof TamableAnimal t && t.isOwnedBy(p))
                        || (e instanceof AbstractHorse h && h.isTamed() && p.getUUID().equals(h.getOwnerUUID()))));
        if (pets.isEmpty()) {
            say(p, "No veo mascotas tuyas a menos de 24 bloques.");
            return;
        }
        int healed = 0;
        for (LivingEntity e : pets) {
            if (e.getHealth() < e.getMaxHealth()) {
                e.heal(e.getMaxHealth());
                healed++;
            }
            level.sendParticles(ParticleTypes.HEART, e.getX(), e.getY() + e.getBbHeight() + 0.3, e.getZ(), 5, 0.3, 0.2, 0.3, 0.0);
        }
        say(p, healed == 0 ? "Tus " + pets.size() + " mascotas están perfectas." : "¡Mimitos! He curado a " + healed + (healed == 1 ? " mascota." : " mascotas."));
    }

    // ------------------------------------------------------------------ chistes, datos y baile

    private static final String[] JOKES = {
            "¿Qué le dice un creeper a otro? «Qué ssssorpresa verte por aquí».",
            "¿Por qué los esqueletos no pelean entre ellos? Porque no tienen agallas.",
            "¿Qué hace un enderman en una biblioteca? ¡Mover los libros de sitio!",
            "¿Cómo se llama el mejor amigo del zombi? ¡Su cerebro de repuesto!",
            "¿Qué le dijo la vaca a la oveja? «Qué lanita tan bonita tienes».",
            "¿Por qué el aldeano no se baña? Porque siempre dice «hmmm» en vez de «glu glu».",
            "¿Qué le dice un bloque de tierra a otro? «Qué buen suelo tenemos hoy».",
            "¿Qué hace una gallina en el Nether? ¡Huevos duros!",
            "¿Cuál es el colmo de un minero? Tener un día de picos pardos y no encontrar diamantes.",
            "¿Por qué los lobos son tan buenos amigos? Porque siempre están en manada con su hueso.",
            "¿Qué le dice una antorcha a otra? «Brillas muchísimo hoy».",
            "¿Cómo saluda un fantasma en Minecraft? «¡Buuu-enos días!»",
            "¿Por qué el cerdo no juega al escondite? Porque siempre lo encuentran por el «oink».",
            "¿Qué hace un pez globo en una fiesta? ¡Inflar el ambiente!",
            "¿Cuál es el animal más antiguo? La cebra, porque está en blanco y negro.",
            "¿Qué le dice el 0 al 8? «Qué cinturón tan bonito».",
            "¿Por qué la gallina cruzó el puente que hizo Mao? Para llegar al otro lado, ¡claro!",
            "¿Qué le dijo un bloque de obsidiana al agua? «No me mojes, que soy duro».",
            "¿Cómo se despide un astronauta? «Hasta la vista, ¡luna!»",
            "¿Qué hace un panda en el desierto? ¡Echar de menos el bambú!",
            "¿Qué le dice un cofre a una llave? «Contigo me abro».",
            "¿Cuál es el café más peligroso del mundo? El ex-preso... ¡y el creeper con leche!",
            "¿Qué le dice una abeja a otra? «¡Zumba, que te zumba!»",
            "¿Por qué las ovejas son tan buenas en mates? Porque cuentan muy bien... ¡hasta dormirse!",
            "¿Qué hace un gato en un barco? ¡Miau-vegar!"
    };

    private static final String[] FACTS = {
            "los creepers nacieron de un error al programar un cerdo? Salió con el cuerpo demasiado alto y se quedaron con él.",
            "los gatos asustan a los creepers? Si hay un gato cerca, ¡se alejan!",
            "una gallina pone un huevo cada 5 a 10 minutos?",
            "puedes evitar que un enderman se enfade poniéndote una calabaza tallada en la cabeza?",
            "las abejas mueren después de picar?",
            "un día entero de Minecraft dura 20 minutos reales?",
            "los zorros pueden llevar objetos en la boca?",
            "los ajolotes se hacen los muertos para recuperarse cuando están heridos?",
            "las cabras pueden embestir contra troncos y piedras, y a veces sueltan su cuerno?",
            "si le das pescado a un delfín, te guía hasta estructuras escondidas?",
            "los gatos pueden regalarte cosas por la mañana si has dormido cerca de ellos?",
            "los loros imitan los sonidos de los monstruos cercanos?",
            "puedes sacar sopa de champiñones de una vaca champiñón usando un cuenco?",
            "las llamas escupen a quien las molesta?",
            "los pandas tienen personalidades: perezosos, juguetones, preocupados, agresivos...?",
            "un rayo que cae cerca de un creeper lo convierte en un creeper cargado?",
            "puedes teñir ovejas y que sus crías salgan con el color mezclado de sus padres?",
            "los peces globo envenenan si los tocas?",
            "los olfateadores desentierran semillas antiguas que dan plantas únicas?",
            "los lobos domesticados se curan comiendo carne?",
            "las arañas no te atacan de día, a no ser que las ataques tú primero?",
            "un ahumador cocina la comida el doble de rápido que un horno?",
            "los ocelotes se hacen amigos tuyos si les das pescado crudo con paciencia?"
    };

    private static void dance(ServerPlayer p, MaoEntity mao) {
        if (!(mao.level() instanceof ServerLevel level)) return;
        mao.setDeltaMovement(mao.getDeltaMovement().x, 0.5D, mao.getDeltaMovement().z);
        mao.hasImpulse = true;
        level.sendParticles(ParticleTypes.NOTE, mao.getX(), mao.getY() + 1.4D, mao.getZ(), 8, 0.4, 0.3, 0.4, 1.0);
        level.sendParticles(ParticleTypes.HEART, mao.getX(), mao.getY() + 1.2D, mao.getZ(), 4, 0.4, 0.3, 0.4, 0.0);
        for (float pitch : new float[]{0.8F, 1.0F, 1.26F}) {
            level.playSound(null, mao.blockPosition(), SoundEvents.ALLAY_ITEM_GIVEN, SoundSource.NEUTRAL, 1.0F, pitch);
        }
        long now = level.getGameTime();
        Long next = DANCE_XP.get(p.getUUID());
        boolean reward = next == null || now >= next;
        if (reward) {
            DANCE_XP.put(p.getUUID(), now + 6000L);
            Innocence.addXp(p, 0.3F);
        }
        say(p, "¡Bailo, bailo! ♪ ♫" + (reward ? " (¡qué felices somos! +Inocencia)" : ""));
    }

    // ------------------------------------------------------------------ salir a la superficie

    private static void surface(ServerPlayer p, MaoEntity mao) {
        if (!MelonConfig.ALLOW_TELEPORT.get()) {
            say(p, "Mi magia de teletransporte está desactivada en este mundo.");
            return;
        }
        ServerLevel level = p.serverLevel();
        if (level.dimension() != Level.OVERWORLD) {
            say(p, "Aquí no hay superficie a la que subir. Dime «llévame a mi cama» para salir de esta dimensión.");
            return;
        }
        int x = p.getBlockX(), z = p.getBlockZ();
        int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        if (p.getBlockY() >= top - 1) {
            say(p, "¡Ya estás en la superficie!");
            return;
        }
        BlockPos target = new BlockPos(x, top, z);
        if (level.getFluidState(target.below()).is(FluidTags.LAVA)) {
            say(p, "Arriba hay lava justo encima de ti, no es seguro. Cava un poco hacia un lado y vuelve a pedírmelo.");
            return;
        }
        MaoSkills.teleport(p, mao, level, MaoSkills.safeSpot(level, target), "la superficie");
    }

    // ------------------------------------------------------------------ recordatorios

    private static String fmt(long sec) {
        if (sec < 60) return sec + (sec == 1 ? " segundo" : " segundos");
        if (sec < 3600) return sec / 60 + (sec / 60 == 1 ? " minuto" : " minutos");
        return sec / 3600 + (sec / 3600 == 1 ? " hora" : " horas") + (sec % 3600 >= 60 ? " y " + (sec % 3600) / 60 + " min" : "");
    }

    private static void remind(ServerPlayer p, String param) {
        String[] parts = param == null ? new String[0] : param.split("\\|", 2);
        long sec = 0;
        if (parts.length > 0) {
            try {
                sec = Long.parseLong(parts[0].trim());
            } catch (NumberFormatException ignored) {
                sec = 0;
            }
        }
        if (sec <= 0) {
            say(p, "¿En cuánto tiempo? Por ejemplo «avísame en 5 minutos de sacar el pan».");
            return;
        }
        int mine = 0;
        for (Reminder r : REMINDERS) {
            if (r.id().equals(p.getUUID())) mine++;
        }
        if (mine >= 10) {
            say(p, "Ya tengo 10 avisos apuntados para ti, ¡espera a que suene alguno!");
            return;
        }
        sec = Math.min(sec, 7200L);
        String text = parts.length > 1 && !parts[1].isBlank() ? parts[1].trim() : "¡Ya ha pasado el tiempo!";
        REMINDERS.add(new Reminder(p.getUUID(), p.serverLevel().getGameTime() + sec * 20L, text));
        say(p, "¡Hecho! Te aviso en " + fmt(sec) + " (si cierras el mundo se olvida).");
    }

    /** Se llama cada segundo desde los Maos: avisa de los recordatorios que ya tocan. */
    static void tickReminders(ServerPlayer owner) {
        if (REMINDERS.isEmpty()) return;
        long now = owner.serverLevel().getGameTime();
        for (Reminder r : REMINDERS) {
            if (!r.id().equals(owner.getUUID()) || now < r.due()) continue;
            if (!REMINDERS.remove(r)) continue;
            owner.sendSystemMessage(Component.literal("⏰ ¡Aviso de Mao! " + r.text()).withStyle(ChatFormatting.GOLD));
            owner.serverLevel().playSound(null, owner.blockPosition(), SoundEvents.ALLAY_ITEM_GIVEN, SoundSource.NEUTRAL, 1.0F, 1.8F);
        }
    }
}
